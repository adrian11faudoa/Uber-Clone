# Contract 08 — Event Envelope and Event Taxonomy

Extends [15-cross-domain-integration.md](../15-cross-domain-integration.md) §10.

## 1. Canonical Event Envelope

```json
{
  "eventId": "018f0b40-1234-7abc-9def-0123456789ab",
  "eventType": "trip.completed",
  "eventVersion": 1,
  "producer": "trip-management-service",
  "occurredAt": "2026-09-17T14:22:03.104Z",
  "aggregateId": "018f0b30-...",
  "aggregateType": "Trip",
  "correlationId": "018f0a1e-...",
  "causationId": "018f0b3f-...",
  "traceContext": { "traceparent": "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01" },
  "payload": { "tripId": "018f0b30-...", "riderId": "...", "driverId": "...", "fareId": "...", "completedAt": "2026-09-17T14:22:03.000Z" },
  "metadata": { "region": "mx-chihuahua-1" }
}
```

Field notes: `eventId` unique per publication (distinct from `aggregateId`); `causationId` references the `eventId` or `correlationId` of whatever directly caused this event (a command, or another event) supporting causal-chain reconstruction; `aggregateType` supports polymorphic consumers/tooling; `metadata` is an open bag for non-payload operational context (e.g., region) and must never carry sensitive fields (§[18-privacy-and-security.md](../18-privacy-and-security.md) §14).

## 2. Canonical Event Taxonomy (Representative, Not Exhaustive)

| Event type | Producer domain | Payload highlights |
|---|---|---|
| `user.registered` | Identity & Accounts | `userId`, `accountCategory` |
| `driver.onboarding.submitted` | Driver Onboarding & Compliance | `driverId`, `verificationId` |
| `driver.verified` | Driver Onboarding & Compliance | `driverId`, `verifiedAt` |
| `vehicle.approved` | Vehicle Management | `vehicleId`, `driverId`, `categoryId` |
| `driver.availability.changed` | Driver Availability | `driverId`, `previousState`, `newState` |
| `trip.requested` | Trip Management | `tripRequestId`, `riderId`, `pickup`, `destination` |
| `trip.searching` | Trip Management | `tripRequestId` |
| `dispatch.initiated` | Dispatch | `tripRequestId` |
| `driver.offer.created` | Dispatch | `offerId`, `tripRequestId`, `driverId`, `expiresAt` |
| `driver.offer.accepted` | Dispatch | `offerId`, `driverId` |
| `trip.assigned` | Trip Management | `tripId`, `driverId`, `assignmentId` |
| `trip.driver_arrived` | Trip Management | `tripId` |
| `trip.started` | Trip Management | `tripId`, `startedAt` |
| `trip.completed` | Trip Management | `tripId`, `fareId`, `completedAt` |
| `trip.cancelled` | Trip Management | `tripId`, `cancelledBy`, `reasonCode` |
| `fare.calculated` | Pricing | `fareId`/`fareEstimateId`, `amountMinorUnits`, `currency`, `pricingRuleVersion` |
| `payment.authorized` | Payments | `paymentIntentId`, `amountMinorUnits` |
| `payment.captured` | Payments | `paymentIntentId`, `chargeId` |
| `payment.failed` | Payments | `paymentIntentId`, `failureCode` |
| `payment.refunded` | Payments | `refundId`, `chargeId`, `amountMinorUnits` |
| `earnings.recorded` | Driver Earnings & Payouts | `ledgerEntryId`, `driverId`, `tripId`, `amountMinorUnits` |
| `payout.initiated` | Driver Earnings & Payouts | `payoutId`, `driverId` |
| `payout.completed` | Driver Earnings & Payouts | `payoutId` |
| `payout.failed` | Driver Earnings & Payouts | `payoutId`, `failureCode` |
| `rating.created` | Ratings & Reviews | `ratingId`, `tripId`, `direction` |
| `notification.requested` | Any domain (producer varies) | `notificationType`, `recipientId`, `templateData` |
| `safety.incident.created` | Safety | `incidentId`, `tripId`, `severity` |
| `support.case.created` | Support | `caseId`, `userId` |

## 3. Event Design Principle

Events represent meaningful integration boundaries (state transitions or facts other domains genuinely need to react to) — not every internal method call. A useful test applied when adding a new event type: "does at least one other domain need to react to this asynchronously, or is this purely internal to one domain's own persistence?" If the latter, it is not published as a platform event.

## 4. Event Versioning

`eventVersion` is an integer on the envelope; `eventType` itself gains a version suffix only on a breaking payload change (e.g., `trip.completed.v2`), per [15-cross-domain-integration.md](../15-cross-domain-integration.md) §10. Additive payload changes (new optional field, new enum value per [06](../06-identifier-time-data-contract.md) §10) increment `eventVersion` without changing `eventType`.

## 5. Producer Field

`producer` identifies the deployable/service identity that published the event (§[04-service-module-boundaries.md](../04-service-module-boundaries.md)), supporting operational tracing independent of the business `aggregateType`.

## 6. Correlation and Causation

`correlationId` ties every event/log/trace back to the originating user-facing request (§[06](../06-identifier-time-data-contract.md) §4); `causationId` supports reconstructing "what directly triggered this" chains distinct from "what request eventually led to this," which matters when one request fans out into many causally-chained events (e.g., `trip.completed` causes `payment.captured` causes `earnings.recorded`).
