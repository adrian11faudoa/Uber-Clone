# Contract 13 — Driver Location Contract

Extends [10-location-architecture.md](../10-location-architecture.md) with the concrete payload shape and edge-case handling.

## 1. Location Payload

```json
{
  "sampleId": "018f0b60-...",
  "actorType": "DRIVER",
  "actorId": "018f0a20-...",
  "deviceId": "018f0a21-...",
  "tripId": "018f0b30-...",
  "lat": 28.63512,
  "lng": -106.06889,
  "altitudeMeters": 1420.5,
  "accuracyMeters": 8.2,
  "headingDegrees": 134.0,
  "speedMetersPerSecond": 11.3,
  "capturedAt": "2026-09-17T14:10:02.301Z",
  "receivedAt": "2026-09-17T14:10:02.612Z",
  "sequenceNumber": 4821,
  "provider": "fused",
  "appVersion": "3.4.1"
}
```

`tripId` is null when the driver is online-but-not-on-a-trip (still required for dispatch eligibility); `altitudeMeters`, `headingDegrees`, `speedMetersPerSecond` are optional (device/OS-dependent availability). `sequenceNumber` is a per-device monotonically increasing counter used for out-of-order detection (§7), independent of server timestamps.

## 2. Accepted Precision

Minimum 5 decimal degrees (§[06](../06-identifier-time-data-contract.md) §8); `accuracyMeters` above a configurable threshold (e.g., 100m) is still accepted and stored but flagged (`lowAccuracy: true` derived server-side) and deprioritized in dispatch candidate ranking (§[09-dispatch-matching.md](../09-dispatch-matching.md) §4) rather than rejected outright — a low-accuracy fix is still better than no fix for coarse eligibility purposes.

## 3. Freshness

`receivedAt` (server clock) is authoritative for all freshness/staleness decisions per [10](../10-location-architecture.md) §2; `capturedAt` (client clock) is retained for diagnostics only.

## 4. Clock-Skew Handling

If `capturedAt` differs from `receivedAt` by more than a generous bound (e.g., 5 minutes in either direction), the sample is still accepted and stored (for diagnostic value) but the server does not use `capturedAt` for any freshness/ordering decision in that case — it falls back to `receivedAt` and `sequenceNumber` exclusively, since a large skew indicates an untrustworthy device clock, not a business anomaly to reject.

## 5. Deduplication

Samples with an identical `(actorId, sequenceNumber)` are deduplicated at ingestion (idempotent upsert into the ephemeral Redis key), tolerating client-side retry of a single location push.

## 6. Stale Updates

A sample whose `sequenceNumber` is lower than the highest already-processed `sequenceNumber` for that `actorId` is accepted for historical/trip-record storage (§[10](../10-location-architecture.md) §1, if trip-scoped) but does **not** overwrite the current ephemeral "latest position" key — the ephemeral layer always reflects the highest-sequence sample seen, never regresses to an older one arriving late.

## 7. Out-of-Order Updates

Detected via `sequenceNumber` (§1, §6); handled per §6 for the ephemeral layer, and inserted in `capturedAt` order (not arrival order) into trip-scoped historical storage so route reconstruction remains chronologically correct regardless of network delivery order.

## 8. Malformed Coordinates

`lat` outside `[-90, 90]` or `lng` outside `[-180, 180]`, or either value `null`/non-numeric, is rejected at ingestion with `400 INVALID_LOCATION_PAYLOAD` and not stored — never silently clamped or coerced.

## 9. Impossible Movement

A sample implying a speed between consecutive samples exceeding a generous physically-plausible bound (e.g., >150 m/s ≈ 540 km/h) for the relevant vehicle category is flagged (`implausibleMovement: true`) rather than rejected outright, surfaced to Fraud & Risk (§[03](../03-domain-decomposition.md) domain 17) as a signal (potential location spoofing) without unilaterally blocking the driver — a single implausible sample is common (GPS jump/multipath); a sustained pattern is the fraud-relevant signal, evaluated by that domain, not by the ingestion contract itself.

## 10. Rate Limits

Per-`actorId`, per [10](../10-location-architecture.md) §10: a documented maximum update frequency (e.g., 1 update/second sustained, short bursts tolerated); excess updates beyond the limit are dropped (keeping the newest), not queued, consistent with the "only the latest value matters" nature of this data (§[13-realtime-architecture §10 backpressure principle](./12-realtime-contract.md) §13 mirrors this at the fan-out side).

## 11. Privacy Controls

Per [18-privacy-and-security.md](../18-privacy-and-security.md) §13: precise location in this payload is accessible only to Dispatch, Location, the owning actor, and authorized Realtime subscribers for an active trip; any export to Analytics is coarsened/aggregated (§[10](../10-location-architecture.md) §1 analytics category) before leaving the Location domain's authoritative boundary.

## 12. Distinguishing Driver Operational Location from Rider-Provided Optional Location

Driver location: continuous (while online), operationally required, higher frequency, drives dispatch. Rider location: point-in-time (pickup selection) or explicit-opt-in trip-sharing only, lower frequency, never drives dispatch matching for other riders, and is never persisted beyond the associated trip request/trip's own retention window (§[23-retention-deletion-contract](./23-retention-deletion-contract.md)) plus a short buffer.
