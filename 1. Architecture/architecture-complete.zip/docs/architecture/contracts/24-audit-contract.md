# Contract 24 — Audit and Administrative Action Contract

Implementation-ready extension of [18-privacy-and-security.md](../18-privacy-and-security.md) §6 and [06-authorization-contract](./06-authorization-contract.md) §6, §8.

## 1. Canonical Audit Record

```json
{
  "auditId": "018f0bd0-...",
  "occurredAt": "2026-09-17T16:00:00.000Z",
  "actorId": "018f0a99-...",
  "actorType": "STAFF",
  "actorRole": "finance_agent",
  "action": "REFUND_EXECUTE",
  "targetEntityType": "Charge",
  "targetEntityId": "018f0b9c-...",
  "outcome": "SUCCESS",
  "reasonCode": "RIDER_DISPUTE_RESOLVED",
  "sourceService": "payments-service",
  "requestId": "018f0bd1-...",
  "correlationId": "018f0a1e-...",
  "metadata": { "amountMinorUnits": 5000, "currency": "MXN", "impersonating": null }
}
```

`actorType` ∈ `RIDER`, `DRIVER`, `STAFF`, `SYSTEM`, `SERVICE`. `outcome` ∈ `SUCCESS`, `FAILURE`, `DENIED`. `metadata` carries action-specific structured detail but never raw sensitive content beyond what the action itself concerns (§5).

## 2. Actions Requiring Immutable Audit Records

Every action classified as "privileged" per [06-authorization-contract §6](./06-authorization-contract.md); every authentication event (§[05-auth-session-device-contract](./05-auth-session-device-contract.md)); every scoped cross-user data access under `:case-linked`/`:investigation-linked`/impersonation permissions (§[06](./06-authorization-contract.md) §7–8); every financial state transition (§[16-payment-contract](./16-payment-contract.md), §[17-earnings-payout-contract](./17-earnings-payout-contract.md)); every dynamic-configuration change (§[21-configuration-contract §6](./21-configuration-contract.md)); every RBAC/role-grant change; every safety-incident disposition change.

## 3. Immutability

Audit Events are append-only; no API or internal command ever updates or deletes an existing Audit Event (§[05](../05-domain-entity-inventory.md)) — a correction to an audit record's understanding (e.g., "this action was later found to be erroneous") is itself a new Audit Event referencing the original by id, never an edit.

## 4. Storage

A dedicated, write-optimized, access-restricted PostgreSQL table (or an append-only-oriented store) owned by Administration (§[03](../03-domain-decomposition.md) domain 19); every domain writes to it via a shared internal "record audit event" command/library (consistent interface) rather than each domain inventing its own audit-writing pattern, ensuring the schema in §1 is genuinely uniform platform-wide.

## 5. Sensitive Audit Data Access Control

Reading the Audit Event stream requires a dedicated `audit:read:*` permission (§[06-authorization-contract §2](./06-authorization-contract.md)), separate from and narrower than general administrator permissions; `metadata` fields that would themselves be sensitive (e.g., full card number — which should never occur per [16](./16-payment-contract.md) §13, but as a defensive principle) are never included even in the audit trail — audit records reference entity ids, not raw sensitive payloads, so investigators fetch full context from the authoritative domain (itself access-controlled) rather than the audit metadata being a secondary leak vector.

## 6. Meta-Audit

Reads of the Audit Event stream by the highest-sensitivity roles (Safety, Administrator) are themselves logged (who viewed which audit records, when) — per [21-web-admin-analytics-data-observability.md](../21-web-admin-analytics-data-observability.md) Part B §3 — creating a bounded recursion (meta-audit of audit access) that stops at one level (viewing the meta-audit log itself is a standard privileged action, logged normally, not recursively meta-meta-audited).

## 7. Query / Retrieval

`GET /v1/audit-events?actorId=&targetEntityId=&action=&occurredAfter=&occurredBefore=` — cursor-paginated (§[02-query-pagination-contract](./02-query-pagination-contract.md)), filterable by the fields in §1, permission-gated per §5.

## 8. Correlation with Broader Observability

`correlationId` and `requestId` on every Audit Event tie it into the same tracing fabric as logs/metrics/traces (§[21](../21-web-admin-analytics-data-observability.md) Part E §2) — an investigator can pivot from an audit record to the full request trace and vice versa.

## 9. Retention

Per [23-retention-deletion-contract §1](./23-retention-deletion-contract.md): long-term, never user-deletable, and exempt from the standard account-deletion anonymization workflow's identity-scrubbing for a documented minimum window (the audit trail's evidentiary value during that window outweighs the subject's erasure request; beyond that window, jurisdiction-specific policy governs whether/how identity fields are anonymized while the fact of the action is preserved).
