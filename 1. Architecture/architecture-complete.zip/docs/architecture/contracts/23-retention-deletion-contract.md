# Contract 23 — Data Retention and Deletion Contract

Extends the per-entity retention notes in [05-domain-entity-inventory.md](../05-domain-entity-inventory.md) with cross-cutting retention classes. Specific numeric retention periods below are **architectural defaults/placeholders that later, region-specific legal/policy review must confirm or override** — none is claimed as a verified legal requirement for any jurisdiction (Master Prompt constraint).

## 1. Retention Classes

| Class | Examples | Default retention (policy input, not a legal claim) | Deletion trigger |
|---|---|---|---|
| Account data | User, Rider Profile, Driver | Duration of active account + a configurable grace period (e.g., 30 days) after deletion request before anonymization | Explicit account-deletion request, or prolonged inactivity per policy |
| Driver onboarding documents | Driver Verification evidence, license/insurance images | Compliance-policy-driven (jurisdiction-specific; treated as configurable, not hardcoded) | Document expiry + compliance-window elapse, or account deletion (subject to any legal-hold override) |
| Trip records | Trip, Trip Request, Fare | Long-term (financial/legal record; default 7 years pending jurisdiction-specific confirmation) | Not typically user-deletable; anonymized (PII-scrubbed, financial facts retained) on account-deletion request where legally permissible |
| Realtime locations (ephemeral) | Location Sample (non-trip-scoped) | Minutes–hours (§[10-location-architecture.md](../10-location-architecture.md) §1) | Automatic TTL expiry |
| Historical locations (trip-scoped) | Location Sample (trip-scoped route) | Aligned with Trip retention above | Aligned with Trip retention |
| Financial records | Charge, Refund, Payout, Ledger Entry | Long-term (default 7 years pending jurisdiction confirmation) | Never user-deletable; immutable by design (§[05](../05-domain-entity-inventory.md)) |
| Support cases | Support Case, attachments | Medium-term (default 3 years) | Retention-window elapse; earlier deletion only via legal-hold-cleared account-deletion |
| Safety incidents | Safety Incident | Long-term, legally-driven (default 7 years, likely to be superseded by jurisdiction-specific legal minimums) | Rarely user-deletable given legal/safety-investigation value; explicit policy required before any deletion |
| Audit logs | Audit Event | Long-term (default 7 years) | Never user-deletable |
| Analytics data | Derived aggregates | Short-to-medium (raw event-level detail expires quickly per [10-location-architecture.md](../10-location-architecture.md) §1 analytics category; aggregates retained longer) | Automatic per pipeline policy, no user-initiated deletion trigger since data is already de-identified/aggregated |
| Application logs | Structured logs (excluding audit) | Short (default 30–90 days) | Automatic log-retention-policy expiry |

## 2. Deletion Triggers

(a) explicit user-initiated account-deletion/erasure request, (b) regulatory erasure request processed through the same workflow, (c) automatic retention-window expiry (background `cleanup` jobs, §[11-job-contract](./11-job-contract.md)), (d) legal-hold-driven **suspension** of an otherwise-due deletion (§4).

## 3. Deletion Workflow

A single, centrally-orchestrated "delete/anonymize everything referencing `user_id` X" workflow (owned by Identity & Accounts in coordination with Administration) walks every domain's documented retention class above: PII-bearing, non-financial, non-legally-mandated-retention data is hard-deleted or irreversibly anonymized; financial/audit/legally-retained data has its **directly-identifying** fields anonymized where legally permissible while the underlying financial/audit facts are preserved (e.g., a Trip record retains its fare/route/timestamps but its rider-identifying fields are replaced with an anonymized reference) — this workflow is only possible because every entity's relationship to `user_id` is explicit and traceable (§[18-privacy-and-security.md](../18-privacy-and-security.md) §12).

## 4. Legal Hold

A Legal-Hold flag (Administration-managed, itself audited) on a `user_id` or specific entity suspends any pending/future automatic deletion for that subject until the hold is lifted — implemented as a check the deletion workflow (§3) and every automatic `cleanup` job consult before acting, never as an assumption that "deletion requests always proceed."

## 5. Archival

Data past its "hot" operational-access need but not yet past retention (per §1) is moved to a colder storage class (S3 Infrequent Access/Glacier for documents per [19-media-document-contract §9](./19-media-document-contract.md); PostgreSQL table partitioning/archival schema for old Trip/Location rows) — archival is a storage-cost optimization, not a retention-policy change; archived data remains subject to the same deletion trigger and legal-hold rules.

## 6. Anonymization

Where a legal/business need exists to retain the *fact* (a completed trip occurred, a fare was charged) without retaining *identity*, anonymization replaces direct identifiers (name, exact location beyond a coarsened region, contact info) with an irreversible reference while preserving aggregate/statistical value — applied per entity's documented sensitivity classification (§[18-privacy-and-security.md](../18-privacy-and-security.md) §3).

## 7. Derived-Data Deletion

Any deletion/anonymization of a source entity triggers corresponding cleanup of its derived representations: Search index documents (§[20-search-contract §8](./20-search-contract.md)), Analytics aggregates where individually attributable (aggregate statistics that no longer resolve to an individual are not required to be purged, since they are not personal data once properly aggregated), and any cached/denormalized read model.

## 8. Backup Implications

Backups (database snapshots, S3 versioning) are retained per their own operational backup-retention policy (e.g., 35-day point-in-time-recovery window), which may transiently retain deleted data within backup media beyond its logical deletion — documented explicitly as an accepted, time-bounded exception (data is not recoverable from backups by any operational process except full-system disaster recovery, and backup-retention itself expires the copy within a bounded window) rather than silently ignored.

## 9. Explicit Non-Claim

No specific number in this document is asserted as a verified legal minimum/maximum for any jurisdiction; every numeric value is a configurable architectural default pending region-specific legal/compliance review, consistent with the Master Prompt's prohibition on fabricating compliance certifications.
