# Contract 27 — Schema Evolution and Compatibility Contract

## 1. PostgreSQL Schema Evolution

- **Additive changes** (new nullable column, new table, new index) are safe to deploy ahead of application code that uses them and require no special coordination beyond standard migration tooling (e.g., a NestJS/TypeORM or Prisma migration run as a deploy step before the new application version rolls out).
- **Destructive changes** (dropping a column/table, renaming, changing a column's type incompatibly, adding a `NOT NULL` constraint to an existing column without a backfill) are never deployed in the same release as the application code that assumes their absence. Renames are modeled as add-new-column → dual-write → backfill → switch-reads → remove-old-column, across multiple releases.
- Every migration is forward-only in production (no down-migrations run against production data); a mistaken migration is corrected by a new forward migration, never a rollback of the schema itself (though the *application version* may be rolled back independently, per §5).

## 2. API Schema Evolution

Per [01-api-contract §12–13](./01-api-contract.md): additive within a major version (new optional request field, new optional response field, new enum value per [06](../06-identifier-time-data-contract.md) §10); breaking changes require a new major version path prefix, with both versions served concurrently during the deprecation window (§[01](./01-api-contract.md) §13).

## 3. Event Schema Evolution

Per [08-event-contract §4](./08-event-contract.md) and [09-event-delivery-contract §12](./09-event-delivery-contract.md): additive changes bump `eventVersion`; breaking changes introduce a new `eventType` version suffix, published alongside the prior version for a documented migration window until all consumers have moved to the new type.

## 4. Job Payload Evolution

Same additive/breaking split as events (§3), keyed by `jobVersion` (§[11-job-contract §2](./11-job-contract.md)); a worker deployment must be able to process both the previous and current job-payload version during a rolling deploy, since already-enqueued jobs from the pre-deploy version may still be processed by post-deploy worker code.

## 5. Realtime Message Evolution

Per [12-realtime-contract §5](./12-realtime-contract.md): additive via `messageVersion`; clients tolerate unrecognized fields/message types gracefully, which is what makes additive realtime evolution safe without a client-version-gating mechanism.

## 6. Search Document Schema Evolution

Per [20-search-contract §10](./20-search-contract.md): a mapping change is deployed as a new index version behind an alias swap, never an in-place destructive mapping change to a live index.

## 7. Configuration Schema Evolution

Per [21-configuration-contract §7](./21-configuration-contract.md): dynamic configuration schema changes are validated server-side before acceptance; a configuration schema's breaking change (removing a previously-required field) follows the same additive-then-deprecate pattern as APIs.

## 8. Deployment Ordering (Rolling-Deployment Safety)

The general rule across every category above: **expand, migrate, contract** — (1) expand the schema/contract additively and deploy consumers that can handle both old and new shapes, (2) migrate/backfill data and traffic to the new shape, (3) only once no component depends on the old shape, contract by removing it. No deployment step assumes all instances of a service are running the same code version simultaneously (standard rolling-deployment assumption for Kubernetes, §[17-infrastructure-and-multiregion.md](../17-infrastructure-and-multiregion.md) §1).

## 9. Backward Compatibility Preference

Backward compatibility is preferred wherever practical (Master Prompt directive); a breaking change is justified only when the expand/migrate/contract path is genuinely infeasible (rare, and requires a documented ADR explaining why, per the ADR pattern established in Volume 1).

## 10. Rollback

Application-code rollback (reverting to the previous deployed version) must remain safe as long as the database/event/job schema is still in an "expand" state that the previous code version already understood — this is precisely why destructive "contract" steps are deferred to their own release, only after confidence in the new version is established (§1, §8).

## 11. Versioning Summary Table

| Contract type | Versioning mechanism | Breaking-change signal |
|---|---|---|
| PostgreSQL schema | Migration history, expand/contract | N/A (schema itself has no version field; process-level discipline) |
| API | Path-prefixed major version | New `/v2` prefix |
| Event | `eventVersion` (additive) / `eventType` suffix (breaking) | New `eventType` string |
| Job payload | `jobVersion` | New `jobVersion` integer, dual-handled during rollout |
| Realtime message | `messageVersion` | New `messageType` or major `messageVersion` bump, tolerated gracefully by clients |
| Search index | Aliased index version (`_v2`, `_v3`) | New index version + alias swap |
| Configuration | Per-value versioning where reproducibility matters (Pricing Rules); simple current-value for feature flags | New version record activated |
