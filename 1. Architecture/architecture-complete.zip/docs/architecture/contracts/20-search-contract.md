# Contract 20 — Search Contract

Implementation-ready extension of [04-service-module-boundaries.md](../04-service-module-boundaries.md) §10.

## 1. Eligible Data

Operational/support search only at this architecture stage: Users (by name/email/phone for support lookup), Trips (by id, rider/driver, date range), Drivers (by name/status), Support Cases, Safety Incidents (heavily access-restricted, §6). No customer-facing full-text "search for a place/promotion" feature is in scope for this volume (maps/geocoding search is a provider-abstraction concern, §[10-location-architecture.md](../10-location-architecture.md), not this OpenSearch-backed contract).

## 2. Index Ownership

Search Indexing Service (§[04](../04-service-module-boundaries.md)) owns every index; each index has exactly one designated source-of-truth domain whose events populate it (Users index ← Identity events; Trips index ← Trip Management events; etc.) — no index is populated from more than one authoritative producer, avoiding write-conflict ambiguity in the derived store.

## 3. Source of Truth

OpenSearch is never authoritative (§[04](../04-service-module-boundaries.md) §10, [21](../21-web-admin-analytics-data-observability.md) Part D.1); any operational decision or authorization check reads the owning domain's PostgreSQL record, never the search index, even when the index technically holds equivalent fields.

## 4. Indexing Triggers

Asynchronous, event-driven: each owning domain's outbox-published events (§[10-outbox-contract](./10-outbox-contract.md)) are consumed by the Search Indexing Service to upsert/delete documents — no synchronous dual-write from the owning domain's transaction into OpenSearch (avoids coupling the domain's transaction success to search-cluster availability, per [04](../04-service-module-boundaries.md) §10).

## 5. Eventual Consistency

A newly created Trip may take up to the platform's documented event-propagation SLA (§[15-cross-domain-integration.md](../15-cross-domain-integration.md) §7, typically seconds) before appearing in support search — acceptable and documented; no support workflow depends on sub-second search freshness.

## 6. Document IDs / Sensitive-Field Filtering / Authorization-Aware Search

Document `_id` matches the source entity's canonical id (§[06](../06-identifier-time-data-contract.md) §1). Indexed documents include only fields necessary for the documented search/filter use case — precise location, payment credentials, and full safety-incident narrative content are never indexed in a generally-queryable index (§[18-privacy-and-security.md](../18-privacy-and-security.md) §3); a Safety Incident's existence may be indexed for a narrowly-scoped Safety-role-only index with its own stricter access control, separate from the general operational-search index Support uses. Every search query is executed with the requesting staff member's permission scope applied as a mandatory filter (mirroring §[06-authorization-contract §4](./06-authorization-contract.md)'s data-access-layer-level enforcement) — search results are never authorization-bypassing, and a staff member cannot discover the existence of a record via search that their role could not otherwise access via the normal API.

## 7. Versioning

Each document carries a `sourceVersion` (matching the owning entity's `version`/`updatedAt`, §[04-concurrency-state-contract §2](./04-concurrency-state-contract.md)) so a delayed/out-of-order indexing event can be detected and discarded if it would regress the document to stale content (compare-and-only-apply-if-newer, mirroring the realtime client pattern in [12-realtime-contract §10](./12-realtime-contract.md)).

## 8. Deletion

A source entity's soft-delete/deactivation (§[02-query-pagination-contract §9](./02-query-pagination-contract.md)) triggers a corresponding document deletion or a `status: deleted` field update (index-design choice), never leaving a stale, now-inaccessible-in-the-source-of-truth record silently discoverable via search.

## 9. Reindexing

Because every index is fully derived and rebuildable from the owning domain's event history/database (§[04](../04-service-module-boundaries.md) §10), a full reindex is always a supported, safe operational recovery action — implemented via replaying the owning domain's event topic from the beginning (§[09-event-delivery-contract §9](./09-event-delivery-contract.md)) or a bulk export-and-index job for domains where topic retention doesn't cover the full history.

## 10. Aliasing

Index names are versioned (`trips_v3`) behind a stable alias (`trips`) so a reindex-with-mapping-change can build the new version in the background and atomically swap the alias, with zero read downtime.

## 11. Operational vs. Customer-Facing Search Boundary

Not applicable at this architecture stage per §1; if a future customer-facing search feature (e.g., searching promotions or saved places) is introduced, it requires its own dedicated index and trust-boundary documentation, since its authorization model (self-service, broader/lower-sensitivity access) differs materially from the staff-only operational search this contract defines.
