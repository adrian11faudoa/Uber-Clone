# Contract 10 — Transactional Outbox and Event Publication Contract

Extends [08-trip-lifecycle-contract.md §4](../08-trip-lifecycle-contract.md) and ADR-0004.

## 1. When Outbox Is Required

Required for any state change whose resulting event publication must not be lost even if the message broker is temporarily unavailable at the moment of the change — concretely: all Trip Management lifecycle transitions, all Payment/Earnings/Payout state transitions, Driver Onboarding approval/rejection, Safety Incident creation, and any other event a downstream domain depends on for correctness (not merely convenience). **Not required** for: high-frequency, latest-value-only signals with no correctness dependency on individual message delivery (Location fan-out, Driver Availability changes — a missed availability-changed event is self-healing on the next update), and purely informational/analytics-only events where an occasional dropped message under a true broker outage is an acceptable, documented risk.

## 2. Transaction Boundary

The outbox record is written in the **same local database transaction** as the business state change it announces (e.g., the Trip row update and the `trip.completed` outbox row are one transaction) — this is the entire point of the pattern: the event's existence is exactly as durable as the state change itself.

## 3. Outbox Record Shape

```sql
outbox_events (
  id UUID PRIMARY KEY,               -- becomes eventId
  aggregate_type TEXT NOT NULL,
  aggregate_id UUID NOT NULL,
  event_type TEXT NOT NULL,
  event_version INT NOT NULL,
  payload JSONB NOT NULL,
  correlation_id UUID NOT NULL,
  causation_id UUID,
  created_at TIMESTAMPTZ NOT NULL,
  published_at TIMESTAMPTZ,          -- NULL until relayed to the broker
  publish_attempts INT NOT NULL DEFAULT 0
)
```

## 4. Publication Status

A relay process (a lightweight poller or a change-data-capture connector such as Debezium reading the PostgreSQL WAL) reads unpublished rows (`published_at IS NULL`), publishes them to Kafka/Redpanda with the envelope shape from [08-event-contract](./08-event-contract.md), and marks `published_at` on confirmed broker acknowledgment.

## 5. Retry

Publication failure (broker unreachable) increments `publish_attempts` and is retried with backoff by the relay process; the business transaction that created the outbox row is already committed and unaffected by publication retry — publication failure never rolls back or blocks the originating business operation.

## 6. Deduplication

Because the outbox row's `id` becomes the event's `eventId`, a relay process that crashes after publishing but before marking `published_at` will republish the same `eventId` on restart — consumers already handle this via the standard idempotency mechanism in [09-event-delivery-contract §3](./09-event-delivery-contract.md), so outbox-level "exactly-once relay" is unnecessary complexity; at-least-once relay + idempotent consumers is sufficient and consistent with the platform-wide pattern.

## 7. Ordering Considerations

Where the corresponding event family requires ordering (§[09-event-delivery-contract §4](./09-event-delivery-contract.md)), the relay process publishes outbox rows for a given `aggregate_id` in `created_at` order and to the same partition key, preserving the order in which the business transactions actually committed.

## 8. Cleanup

Published outbox rows are purged on a rolling window (e.g., 7 days) via a scheduled job — the outbox table is a relay buffer, not a long-term record (Kafka retention and/or the domain's own entity tables are the durable history, per [09-event-delivery-contract §10](./09-event-delivery-contract.md)).

## 9. Monitoring

Required signals: unpublished-row age (oldest `created_at` where `published_at IS NULL` — a growing value indicates relay failure), publish-attempt distribution, relay-process health/lag.

## 10. Failure Recovery

If the relay process itself is down for an extended period, outbox rows simply accumulate (bounded by table growth, monitored per §9) and are published in full once the relay resumes — no business-transaction-level impact, since the pattern's entire purpose is decoupling business-transaction success from broker/relay availability.
