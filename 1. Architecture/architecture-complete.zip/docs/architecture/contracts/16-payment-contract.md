# Contract 16 — Payment Provider and Webhook Contract

Implementation-ready extension of [12-payment-financial-architecture.md](../12-payment-financial-architecture.md).

## 1. Payment Intent Lifecycle

`created` → `requires_authorization` → `authorized` → `capture_pending` → `captured` | `capture_failed` → (`refund_pending` → `refunded` | `partially_refunded`)\*, with `failed`/`cancelled` reachable from any pre-`captured` state. Terminal: `captured` (may still receive a subsequent refund, which is a new Refund record, not a lifecycle re-entry), `failed`, `cancelled`, `refunded`.

## 2. Authorization

`POST` (internal, `service`-authorized) to the `PaymentProviderPort.authorize({ paymentMethodId, amountMinorUnits, currency, idempotencyKey })`; on provider success, Payment Intent → `authorized` with `providerAuthorizationId` stored.

## 3. Capture

`PaymentProviderPort.capture({ paymentIntentId, finalAmountMinorUnits, idempotencyKey })`, invoked by Trip Management's `trip.completed` outbox-triggered flow (§[07-domain-command-contract](./07-domain-command-contract.md) #13); `finalAmountMinorUnits` comes from Pricing's `Fare.finalTotal` (§[15-pricing-contract §9](./15-pricing-contract.md)) and may differ from the originally authorized amount within provider-supported variance — amounts exceeding the provider's supported over-capture variance require a supplemental authorization, handled as a documented edge case by the provider port rather than silently failing.

## 4. Failure

Provider decline/failure at authorization time blocks trip dispatch initiation (§[07-domain-command-contract](./07-domain-command-contract.md) #1) with a rider-facing reason mapped from the provider's error taxonomy to the platform's stable internal taxonomy (§[12](../12-payment-financial-architecture.md) §2) — raw provider error codes/messages are never surfaced directly to clients.

## 5. Refund / Partial Refund

`PaymentProviderPort.refund({ chargeId, amountMinorUnits, reasonCode, idempotencyKey })`; partial refunds are supported (amount less than the original Charge) and produce their own immutable Refund record; multiple partial refunds against one Charge are permitted up to the Charge's remaining refundable balance, enforced server-side before calling the provider (never relying solely on the provider to reject an over-refund).

## 6. Dispute

Provider-reported disputes/chargebacks arrive via webhook (§9) and are recorded as a `Dispute` sub-record linked to the Charge, routed to Finance for response, and reflected in reconciliation (§10) — the platform does not attempt to auto-contest disputes.

## 7. Provider Webhook

Dedicated endpoint `POST /webhooks/payments/{provider}` (e.g., `/webhooks/payments/stripe`), not behind the standard `/v1` authenticated-API surface — authenticated instead by signature verification (§9).

## 8. Webhook Verification

Every inbound webhook's signature is verified against the provider's documented signing-secret mechanism (e.g., HMAC-SHA256 over the raw request body using a secret held in the secrets boundary, §[18-privacy-and-security.md](../18-privacy-and-security.md) §4) **before** the payload is parsed/trusted for any business effect; verification failure returns `401` and the payload is discarded, logged only at the metadata level (no payload content logged for an unverified request).

## 9. Provider Idempotency

Every outbound provider call includes an idempotency key derived from the internal entity id (§[12](../12-payment-financial-architecture.md) §3); every inbound webhook is deduplicated by the provider's own event id (`(provider, provider_event_id)`, §[03-idempotency-contract §1](./03-idempotency-contract.md)) before any effect is applied — a redelivered webhook (providers commonly retry until acknowledged) is a guaranteed no-op on second delivery.

## 10. Provider Request Identifiers / Provider Object Identifiers

Every internal record with a provider-side counterpart stores `providerRequestId` (the idempotency key/request id sent) and `providerObjectId` (e.g., `providerChargeId`, `providerPayoutId`) for traceability (§[12](../12-payment-financial-architecture.md) §4).

## 11. Reconciliation

A scheduled `payment-reconciliation` job (§[11-job-contract](./11-job-contract.md)) fetches the provider's settlement report for the period and compares it line-by-line against internal Charge/Refund/Payout records by `providerObjectId`; discrepancies are recorded as `ReconciliationException` rows (not silently corrected) and routed to Finance.

## 12. Example — Verified Capture Webhook

```json
POST /webhooks/payments/stripe
Headers: { "Stripe-Signature": "t=...,v1=..." }
{
  "id": "evt_1P...",
  "type": "charge.succeeded",
  "data": { "object": { "id": "ch_3P...", "amount": 10160, "currency": "mxn", "metadata": { "paymentIntentId": "018f0b8e-..." } } }
}
```
On verified receipt: look up internal Payment Intent via `metadata.paymentIntentId`, confirm/finalize `captured` state if not already applied via the synchronous capture-call response, record `providerObjectId = ch_3P...`, respond `200` immediately (heavy processing, if any, is deferred to an async job — webhook handlers must be fast to avoid provider-side retry storms).

## 13. No Raw Credential Exposure

Restated from [12](../12-payment-financial-architecture.md) §12: this contract never includes, logs, or transmits raw card/bank details anywhere in request, response, event, or webhook payloads — only provider tokens/object ids.
