# Contract 18 — Notification Contract

Implementation-ready extension of [03-domain-decomposition.md](../03-domain-decomposition.md) domain 14.

## 1. Notification Request Shape

```json
{
  "notificationType": "TRIP_DRIVER_ARRIVED",
  "recipientId": "018f0a1e-...",
  "channelPreferenceOverride": null,
  "localizationKey": "notification.trip.driver_arrived",
  "templateData": { "driverFirstName": "Alex", "vehiclePlateSuffix": "4471" },
  "priority": "high",
  "dedupKey": "trip:018f0b30-...:driver_arrived",
  "sourceEventId": "018f0bb0-..."
}
```

## 2. Channels

`push`, `sms`, `email`, `in_app`, `operational` (internal ops/staff-facing alerts, distinct delivery path from consumer notifications). A `notificationType` maps to a default channel set (e.g., safety alerts → push + SMS; marketing → push + email only), overridable per-user via stored preferences (§4) except for a documented set of non-optional operational/safety/security notifications (session-revocation alert, safety-incident updates), which always deliver on at least one channel regardless of preference.

## 3. Recipient

Always a `userId` (§[06-authorization-contract §1](./06-authorization-contract.md) identity anchor); the Notifications domain resolves current contact details (device tokens, phone, email) from Identity/Rider-Profile/Driver at delivery time rather than the producer embedding contact details directly, so a stale producer-side cache of contact info can never cause misdelivery.

## 4. Channel Preference

Per-user, per-`notificationType`-category preference stored by Notifications (`marketing: {push: true, email: false}`, etc.); read at delivery time.

## 5. Localization Key / Template Data

`localizationKey` maps to a maintained translation catalog; `templateData` is a flat, documented-per-`notificationType` key-value bag — never free-form HTML/script content, and never containing more sensitive detail than the minimum needed for the message (§8).

## 6. Deduplication

`dedupKey` (producer-supplied, semantically meaningful, e.g., `trip:{tripId}:driver_arrived`) combined with the processed-event-id ledger pattern (§[09-event-delivery-contract §3](./09-event-delivery-contract.md)) ensures a redelivered source event never sends a duplicate notification to the same recipient.

## 7. Priority

`high` (safety, security, time-critical trip state) bypasses batching/throttling and uses the `high` BullMQ priority (§[11-job-contract](./11-job-contract.md)); `normal`/`low` (marketing, digest-style) may be batched/rate-limited per recipient to avoid notification fatigue.

## 8. Sensitive Information Minimization

Per [18-privacy-and-security.md](../18-privacy-and-security.md) §14: notification payloads never include full payment details, precise addresses beyond what's necessary (e.g., "driver arrived" omits exact GPS coordinates), full names of other parties beyond first name/initial where a full name isn't necessary, or safety-incident content details — a safety notification says "we've received your report and are reviewing it," not incident specifics.

## 9. Retry

Bounded retry with backoff per [11-job-contract](./11-job-contract.md) §3 (`notifications` queue); after exhaustion, marked `failed` and dead-lettered — no user-visible operational impact per [19-failure-model.md](../19-failure-model.md) "Notification-provider failure."

## 10. Provider

Provider abstraction (`NotificationProviderPort`) per channel (FCM/APNs for push, an SMS gateway, an email provider), matching the pattern in [12-payment-financial-architecture.md](../12-payment-financial-architecture.md) §2 applied to notifications — domain logic never references a provider-specific type.

## 11. Delivery Status

`queued` → `sent` → `delivered` (where the channel/provider supports delivery confirmation, e.g., push receipt) | `failed` | `bounced` (email-specific). Delivery status is queryable via an internal API for support troubleshooting ("did the rider actually get notified?").

## 12. Failure Handling

Per §9; additionally, a channel-specific permanent failure (e.g., invalid/unregistered push token, bounced email) triggers a cleanup signal back to the owning domain (Identity/session for stale push tokens) so the platform doesn't keep retrying against a known-dead endpoint.
