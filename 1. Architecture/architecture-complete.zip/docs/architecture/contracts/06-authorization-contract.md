# Contract 06 — Authorization and Permission Contract

Extends [07-authentication-authorization.md](../07-authentication-authorization.md) §7 with a concrete permission catalog and enforcement pattern.

## 1. Permission Model

Permissions are `resource:action:scope` strings (e.g., `trip:read:own`, `trip:read:any`, `payment:refund:execute`, `driver:document:review`). Roles (§[07](../07-authentication-authorization.md) §7) are named bundles of permissions; authorization checks are always against permissions, never against role names directly, so role composition can change without touching enforcement code.

## 2. Canonical Role → Permission Bundles (Representative)

| Role | Representative permissions |
|---|---|
| `rider` | `trip:create:own`, `trip:read:own`, `trip:cancel:own`, `rating:create:own`, `payment-method:manage:own` |
| `driver` | `driver-offer:respond:own`, `trip:read:assigned`, `availability:update:own`, `earnings:read:own`, `payout:read:own` |
| `support_agent` | `trip:read:case-linked`, `payment:read:case-linked`, `support-case:manage:assigned`, `refund:propose:case-linked` (execution requires `finance_agent` approval per §7) |
| `ops_agent` | `service-area:manage:any`, `dispatch-policy:manage:any`, `incident:read:any` |
| `safety_agent` | `safety-incident:manage:any`, `trip:read:investigation-linked`, `location:read:investigation-linked` |
| `finance_agent` | `payment:read:any`, `refund:execute:any`, `payout:manage:any`, `earnings-ledger:read:any` |
| `administrator` | `rbac:manage:any`, `pricing-rule:activate:any`, `*:read:any` (broad read, narrow write outside explicit grants) |
| `service` (per identity) | Narrow, explicitly declared per calling service (e.g., Dispatch's service identity holds `trip-assignment:claim:execute` only) |

## 3. Resource-Level Authorization Requirements

Every resource-scoped permission (`:own`, `:assigned`, `:case-linked`, `:investigation-linked`) requires the authorization check to verify the specific resource instance's ownership/linkage against the authenticated principal — a permission name alone never authorizes access to an arbitrary resource id (this is the core IDOR defense, §6).

## 4. Ownership Checks

Implemented as a mandatory query-time filter (e.g., `WHERE rider_id = :authenticatedUserId`) for `:own`-scoped permissions, never as a post-fetch, application-layer "check and maybe deny" over an unfiltered query — the data access layer itself is constrained, so a coding mistake cannot accidentally return another user's resource before the check runs.

## 5. Service-to-Service Authorization

Each service identity (§[07](../07-authentication-authorization.md) §10) holds an explicit, minimal permission set matching only the internal commands it legitimately calls (§[04-service-module-boundaries §1](../04-service-module-boundaries.md)); a least-privilege matrix is maintained centrally (owned by Administration/Security) and reviewed whenever a new internal call is introduced.

## 6. Privileged Operations

Defined as any operation matching `*:execute:any`, `*:manage:any`, or any RBAC/pricing/refund/payout/safety-disposition action; all require the staff step-up re-authentication in [05-auth-session-device-contract §13](./05-auth-session-device-contract.md) and produce an Audit Event synchronously (§[24-audit-contract](./24-audit-contract.md)).

## 7. Administrative Impersonation / Delegated Access

Support "view as user" (read-only impersonation for troubleshooting) is supported only as an explicitly-scoped, time-boxed, fully audited session attribute (`actingOnBehalfOf: user_id`, `expiresInMinutes: 15`) that never grants write permissions beyond the support agent's own role — impersonation never silently elevates privilege, and every read performed under impersonation is tagged in the audit trail with both the staff actor and the impersonated subject.

## 8. Audit Requirements

Every permission check that denies access to a resource the principal attempted to access is logged at a lower-sensitivity operational-log level (not necessarily a full Audit Event, to avoid audit-log flooding from routine `403`s); every check that **grants** access under a `:case-linked`/`:investigation-linked`/impersonation scope **is** a full Audit Event (§[24-audit-contract](./24-audit-contract.md)), since these are the higher-risk cross-user access patterns.

## 9. Deny-by-Default Behavior

Absence of an explicit permission grant is always a denial (`403`); there is no implicit allow based on role hierarchy assumptions (e.g., `administrator` does not implicitly gain every permission via inheritance — broad admin permissions are explicitly enumerated, per §2's `*:read:any` note, precisely so the permission set remains auditable rather than "whatever administrator conventionally means").

## 10. IDOR Prevention (Explicit)

1. Every endpoint accepting a resource id in the path/body performs the ownership/scope check described in §3–4 before returning or mutating data — never relies on the id being "hard to guess" (UUIDs are not a security boundary, they are an addressing scheme).
2. `404` is returned uniformly for "resource does not exist" and "resource exists but caller is not authorized to know that" (Volume 1 §14 §3) to prevent existence-enumeration.
3. Bulk/list endpoints apply the same ownership filter at the query level (§4), never filter a fully-fetched result set in application code after the fact.
4. Any endpoint accepting a foreign-key-style reference in a request body (e.g., `fareEstimateId` on trip creation) validates that the referenced resource itself belongs to/was issued for the requesting principal before use.
