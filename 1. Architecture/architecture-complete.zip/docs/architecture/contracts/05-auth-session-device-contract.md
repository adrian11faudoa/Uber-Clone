# Contract 05 — Authentication, Sessions, and Device Contract

Extends [07-authentication-authorization.md](../07-authentication-authorization.md) with concrete lifecycle values and payload shapes.

## 1. Account Identity

`user_id` (UUIDv7) is the single identity anchor across rider, driver, and staff roles (§[03](../03-domain-decomposition.md) domain 1); a person with both rider and driver roles on the platform holds one `User` with multiple role grants, not two identities.

## 2. Access Tokens

JWT, ES256-signed, **15-minute** expiry for consumer roles, **15-minute** expiry for staff roles (short expiry is uniform; staff distinction is in refresh lifetime, §4). Claims: `sub` (`user_id`), `roles`, `tokenVersion`, `iat`, `exp`, `sessionId`. No PII beyond `user_id` and role names in the token payload.

## 3. Refresh Tokens

Opaque (not JWT), 256-bit random value, hashed (SHA-256) before storage; **rotating** — every refresh call issues a new refresh token and immediately invalidates the presented one. Reuse of an already-rotated token revokes the entire session family (§[07](../07-authentication-authorization.md) §5) and is logged as a `AUTH_SESSION_REUSE_DETECTED` audit/security event.

## 4. Session Identifiers and Lifetimes

| Category | Access token TTL | Refresh token TTL | MFA |
|---|---|---|---|
| Rider / Driver | 15 min | 30 days (rolling on use) | Optional (recommended, not mandatory) |
| Support / Ops / Safety / Finance | 15 min | 8 hours (fixed, not rolling) | Mandatory |
| Administrator | 15 min | 4 hours (fixed) | Mandatory, step-up re-auth required for destructive actions |
| Service identity | 5 min (short-lived service JWT) | N/A (re-issued via mTLS-authenticated identity, not refresh flow) | N/A |

## 5. Device Identifiers

Each login registers a `device_id` (client-generated, persisted client-side) and a `session_id` (server-generated) pair; push tokens (§[20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §6) are associated with `device_id`, not `user_id` directly, so multiple accounts on one device (rare, e.g., a shared tablet) can each have distinct push routing.

## 6. Session Revocation / Sign-Out

`POST /v1/auth/sessions/{sessionId}/revoke` (self or admin-on-behalf-of, audited); sign-out revokes the current session's refresh token immediately and blacklists remaining access-token lifetime via the `tokenVersion` bump scoped to that session (not a global bump, so other devices remain logged in) unless the user explicitly chooses "sign out everywhere," which bumps the user's global `tokenVersion`.

## 7. Credential Rotation

Password change: invalidates all other sessions by default (global `tokenVersion` bump), current session retained; a confirmation notification is sent (§[18-notification-contract](./18-notification-contract.md)).

## 8. Suspicious-Session Handling

Refresh-token-reuse detection (§3) and a documented set of anomaly signals (new device + new geography + sensitive-action attempt within a short window — the exact scoring is a Fraud & Risk domain concern, §[03](../03-domain-decomposition.md) domain 17, not this contract) can force a step-up re-authentication or full session revocation; any forced revocation is user-notified.

## 9. Password / Passwordless Flows

Both supported behind the same `Credential` abstraction (§[03](../03-domain-decomposition.md) domain 1): password+account-identifier, or OTP-to-phone/email. OTP codes are 6-digit, single-use, 5-minute expiry, rate-limited (max 5 attempts per code, max 3 codes issued per 15-minute window per identifier).

## 10. Multi-Device Behavior

A single `user_id` may hold many concurrent sessions (one per device/browser); each is independently listed and revocable (§6); no platform-enforced device limit exists at this architecture stage.

## 11. Mobile Secure-Storage Expectations

Restated from [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §1: refresh tokens in Keychain/Keystore-backed secure storage; access tokens may be held in memory only (not required to be persisted, since they're cheaply re-derived via refresh on app relaunch).

## 12. Web Session Expectations

Restated from [21-web-admin-analytics-data-observability.md](../21-web-admin-analytics-data-observability.md) Part A: refresh token in an httpOnly, secure, sameSite=strict cookie; access token never placed in a cookie or exposed to page JS where the server-rendering architecture allows proxying instead.

## 13. Administrative Session Controls

Step-up re-authentication (re-enter password/MFA within the last 5 minutes) required immediately before: RBAC changes, pricing-rule activation, refund/payout overrides, safety-incident disposition changes — enforced server-side by checking a `lastReauthAt` claim/session attribute, not merely a client-side prompt.

## 14. Client Communication of Auth State Without Client Authority

Clients present the current access token on every request; the server is always the sole arbiter of whether that token/session is still valid (checked against `tokenVersion` and session-revocation state on every request, not only at token-issuance time) — a client's local belief that "I'm logged in" is never sufficient, consistent with [07](../07-authentication-authorization.md) §8.

## 15. Example — Token Refresh

```json
POST /v1/auth/refresh
{ "refreshToken": "3f9a...opaque..." }
```
```json
201
{ "accessToken": "eyJhbGciOi...", "refreshToken": "8b1c...opaque-new...", "expiresIn": 900 }
```
