# Contract 19 — Media and Document Contract

Implementation-ready extension of [18-privacy-and-security.md](../18-privacy-and-security.md) §7.

## 1. Covered Content

Driver compliance documents (license, insurance, background-check-adjacent evidence), support attachments (screenshots, files), safety evidence (incident-related uploads), profile media (avatar photos), and generated artifacts (receipts, PDF exports) the platform itself produces.

## 2. Upload Authorization

Per [06-authorization-contract §3–4](./06-authorization-contract.md): a driver may upload only to their own onboarding record; a rider/driver may attach only to their own support case; Support/Safety staff may upload only case/incident-linked evidence, always attributed to the staff actor.

## 3. Presigned Upload Flow

1. Client calls `POST /v1/uploads/presign` with `{ "purpose": "DRIVER_LICENSE", "contentType": "image/jpeg", "sizeBytes": 2_400_000 }`.
2. Server validates purpose-specific constraints (§4–5), generates an S3 object key following the naming convention (§9), and returns a short-lived (e.g., 5-minute) presigned `PUT` URL plus the resulting `mediaId`.
3. Client uploads directly to S3 using the presigned URL — **the platform backend never proxies the file bytes**, and the client never receives broad S3 credentials, only the single-use presigned URL (Master Prompt requirement).
4. Client confirms completion: `POST /v1/uploads/{mediaId}/complete`, triggering the `document-processing` job (§[11-job-contract](./11-job-contract.md)) for validation/scanning (§6).

## 4. Content-Type Validation

Server-side allow-list per `purpose` (e.g., `DRIVER_LICENSE`: `image/jpeg`, `image/png`, `application/pdf`); the presigned URL is scoped (via S3 policy condition) to only accept the declared `Content-Type`, and the completion step re-verifies the actual uploaded object's content-type/magic-bytes server-side (never trusting the client-declared type alone).

## 5. File Size Limits

Per-`purpose` maximum (e.g., 10MB for document images, 2MB for profile photos), enforced both in the presigned policy (S3-side rejection of oversized uploads) and re-validated at completion.

## 6. Malware Scanning Boundary

The completion step enqueues a scan job (via the environment's available scanning capability — e.g., an AWS-native or third-party scanning service integration); the object is not marked `available`/visible to any downstream consumer (onboarding review UI, support case view) until scanning completes with a clean result — a `quarantined` object is neither servable nor auto-deleted, pending manual review, per operational policy set at implementation time.

## 7. Metadata

```json
{ "mediaId": "018f0bc0-...", "purpose": "DRIVER_LICENSE", "ownerUserId": "018f0a20-...", "linkedEntityId": "018f0a25-...", "contentType": "image/jpeg", "sizeBytes": 2400000, "status": "SCANNING", "uploadedAt": "2026-09-17T10:00:00.000Z" }
```

`status` ∈ `PENDING_UPLOAD`, `SCANNING`, `AVAILABLE`, `QUARANTINED`, `REJECTED`, `DELETED`.

## 8. Object Naming

`s3://<bucket>/<purpose>/<ownerUserId>/<mediaId>.<ext>` — predictable enough for lifecycle-policy scoping (e.g., different retention per `purpose` prefix, §[23-retention-deletion-contract](./23-retention-deletion-contract.md)), never guessable in a way that matters since access is always via signed URLs/authorization checks, not by path secrecy.

## 9. Storage Classes

Standard S3 for actively-referenced documents (onboarding under review, open support cases); lifecycle-transitioned to Infrequent Access or Glacier-class storage once retention policy (§[23-retention-deletion-contract](./23-retention-deletion-contract.md)) indicates long-term-archival-only status, prior to eventual deletion.

## 10. Access Control

Private bucket, no public ACLs, ever. All reads are via short-lived (e.g., 5–15 minute) presigned `GET` URLs issued only after the same authorization check as any other resource access (§[06-authorization-contract](./06-authorization-contract.md)).

## 11. Signed Download Behavior

`GET /v1/media/{mediaId}/download-url` returns `{ "url": "https://...presigned...", "expiresAt": "..." }`; the URL itself carries no additional authorization semantics beyond time-limited object access — the authorization decision happens before the URL is issued, not at S3-fetch time.

## 12. Retention / Deletion

Per [23-retention-deletion-contract](./23-retention-deletion-contract.md): driver documents retained per compliance-policy window then deleted/anonymized; support/safety attachments retained per their case's retention class; profile media deleted on account deletion.

## 13. Processing Status

Exposed via `status` (§7) so onboarding/support UIs can reflect "scanning," "ready for review," "rejected" states without polling S3 directly — S3 is never queried by clients except via the presigned URLs this contract issues.
