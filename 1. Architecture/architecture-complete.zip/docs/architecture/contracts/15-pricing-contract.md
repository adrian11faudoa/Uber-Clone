# Contract 15 — Fare and Pricing Contract

Implementation-ready extension of [11-pricing-architecture.md](../11-pricing-architecture.md).

## 1. Currency and Amount Representation

Per [06](../06-identifier-time-data-contract.md) §7: integer minor units + explicit ISO-4217 currency; every amount-bearing object in this contract uses the shape `{ "amountMinorUnits": <int>, "currency": "<ISO-4217>" }`.

## 2. Fare Estimate

```json
{
  "fareEstimateId": "018f0b2c-...",
  "pricingRuleVersion": "018f0a90-...#v3",
  "vehicleCategoryId": "018f0b2a-...",
  "serviceAreaId": "018f0a80-...",
  "components": {
    "base": { "amountMinorUnits": 3000, "currency": "MXN" },
    "distance": { "amountMinorUnits": 4200, "currency": "MXN" },
    "time": { "amountMinorUnits": 1800, "currency": "MXN" },
    "bookingFee": { "amountMinorUnits": 500, "currency": "MXN" },
    "surgeMultiplier": 1.0
  },
  "estimatedTotal": { "amountMinorUnits": 9500, "currency": "MXN" },
  "estimatedDistanceMeters": 6200,
  "estimatedDurationSeconds": 900,
  "generatedAt": "2026-09-17T14:02:50.000Z",
  "expiresAt": "2026-09-17T14:07:50.000Z"
}
```

## 3. Authorized Price

At `ACCEPTED` (§[08](../08-trip-lifecycle-contract.md)), the referenced Fare Estimate's `estimatedTotal` and `pricingRuleVersion` become the "authorized price" context for the trip — a locked reference point against which the final fare's reasonableness/variance is later checked (§[11](../11-pricing-architecture.md) §9), not a separately persisted new object.

## 4. Final Fare

```json
{
  "fareId": "018f0b9a-...",
  "tripId": "018f0b30-...",
  "pricingRuleVersion": "018f0a90-...#v3",
  "components": {
    "base": { "amountMinorUnits": 3000, "currency": "MXN" },
    "distance": { "amountMinorUnits": 4380, "currency": "MXN" },
    "time": { "amountMinorUnits": 1920, "currency": "MXN" },
    "bookingFee": { "amountMinorUnits": 500, "currency": "MXN" },
    "surgeMultiplier": 1.0,
    "promotionDiscount": { "amountMinorUnits": -1000, "currency": "MXN" },
    "tolls": { "amountMinorUnits": 0, "currency": "MXN" },
    "taxes": { "amountMinorUnits": 1360, "currency": "MXN" }
  },
  "finalTotal": { "amountMinorUnits": 10160, "currency": "MXN" },
  "actualDistanceMeters": 6410,
  "actualDurationSeconds": 940,
  "finalizedAt": "2026-09-17T14:22:03.000Z",
  "varianceFromEstimatePercent": 6.9
}
```

Every line item present in the final Fare is individually persisted (not just the total), satisfying reproducibility (§[11](../11-pricing-architecture.md) §5).

## 5. Difference Between Estimate, Authorized Price, and Final Fare

- **Estimate**: non-binding, generated pre-trip, time-boxed (§2).
- **Authorized price**: the estimate's total as it stood at the moment of driver assignment — the rider's expectation baseline, used for variance-checking, not a new calculation.
- **Final fare**: binding, computed at completion from actual distance/time against the same locked `pricingRuleVersion` (§[11](../11-pricing-architecture.md) §9).

## 6. Rounding

Round-half-up to minor unit, applied once at `finalTotal`/`estimatedTotal` computation (§[06](../06-identifier-time-data-contract.md) §7); individual components may be computed with higher internal precision but are themselves stored rounded, so the sum of stored components always equals the stored total (no "phantom rounding remainder" ever appears to the rider).

## 7. Adjustment

A post-completion Fare correction (e.g., a disputed toll) is modeled as a distinct, linked `Fare Adjustment` record (`fareId` reference, `amountMinorUnits` delta, `reasonCode`, `approvedBy`) — the original Fare record is never mutated (§[11](../11-pricing-architecture.md) §9, §[05](../05-domain-entity-inventory.md) immutability rule).

## 8. Audit Metadata

Every Fare/Fare Estimate stores `pricingRuleVersion`, the exact input snapshot used (§[11](../11-pricing-architecture.md) §2, §5), and `correlationId` — sufficient for independent recomputation during a dispute without needing to trust the stored total alone.

## 9. Downstream Payment Non-Recalculation Guarantee

Payments consumes `Fare.finalTotal` and `Fare.currency` verbatim from Pricing's finalize-fare response as the amount to authorize/capture (§[12-payment-financial-architecture.md](../12-payment-financial-architecture.md) §5); Payments never independently recalculates or rounds a business fare amount — its only arithmetic is provider-fee/currency-conversion bookkeeping distinct from the fare itself, kept in separate fields, never blended into the fare total.
