# Contract 02 — Pagination, Filtering, and Query Contract

## 1. Cursor Pagination (Default and Required for Unbounded Collections)

All collections that can grow unbounded (Trips, Ledger Entries, Notifications, Audit Events, Location history, Support Cases) use cursor pagination exclusively — never offset/page-number pagination (Volume 1 §14 §6).

Request: `GET /v1/trips?limit=25&cursor=<opaque>`
Response:
```json
{ "data": [ /* ... */ ], "page": { "nextCursor": "eyJvIjoiMjAyNi0wOS0xN1QxNDowMzoyMS40ODJaIiwiaWQiOiIwMThmMGIzMC0uLi4ifQ", "limit": 25 } }
```

## 2. Cursor Encoding Principles

A cursor is an opaque, base64url-encoded token containing the last-seen sort-key tuple (e.g., `{ sortValue, id }`) — never the raw offset. Clients must not construct, parse, or persist cursor internals across API versions; a cursor's internal shape may change between major API versions without notice (it is not a public contract, only its opacity and round-trip behavior are).

## 3. Deterministic Ordering / Stable Sort Keys

Every paginated endpoint's default and explicit sort orders include the entity's identifier as a tiebreaker (e.g., `ORDER BY createdAt DESC, id DESC`) so that rows with identical primary sort values still produce a stable, non-duplicating, non-skipping traversal across pages.

## 4. Page Size Limits

Default `limit=25`; maximum `limit=100` for consumer-facing endpoints, `limit=500` for internal/admin bulk-query endpoints. Requests exceeding the maximum are clamped, not rejected, with the clamped value reflected in the response's `page.limit`.

## 5. Filtering Conventions

Query-parameter based, explicit per-endpoint allow-list (Volume 1 §14 §8): `?status=COMPLETED&createdAfter=2026-09-01T00:00:00.000Z`. Multi-value filters use repeated params (`?status=COMPLETED&status=CANCELLED`) or comma-separated values (documented per endpoint, consistent within one API version). No arbitrary free-form query-language pass-through to the database.

## 6. Sorting Conventions

`?sort=-createdAt` (`-` prefix = descending); only fields in the endpoint's documented allow-list are sortable; unsupported sort fields return `400` with canonical error `code: UNSUPPORTED_SORT_FIELD`.

## 7. Date/Time Filtering

All date/time filter values are UTC ISO-8601 (§[06](../06-identifier-time-data-contract.md) §5); range filters use `<field>After`/`<field>Before` naming, both inclusive unless documented otherwise per endpoint.

## 8. Geographic Filtering

Where applicable (e.g., "trips near this point" for ops tooling): `?near=lat,lng&radiusMeters=5000`, bounded to a documented maximum radius per endpoint to prevent unbounded geo-scans (consistent with [09-dispatch-matching.md](../09-dispatch-matching.md) §4's bounded-search principle).

## 9. Handling of Deleted/Hidden Records

Soft-deleted/deactivated records (§[05](../05-domain-entity-inventory.md)) are excluded from default listing results; an explicit `?includeDeleted=true` (permission-gated, typically admin-only) is required to include them, and such records are marked with their status field rather than physically absent from the payload shape.

## 10. Consistency Expectations

Cursor pagination provides **read-committed, no-duplicate, no-skip traversal for rows that do not change between page fetches**; rows inserted or deleted between page fetches may or may not appear depending on their position relative to the cursor (standard keyset-pagination semantics) — this is documented as acceptable for all current use cases (no endpoint requires a frozen point-in-time snapshot across pages).

## 11. Invalid Cursors

A malformed or unparseable cursor returns `400` with canonical error `code: INVALID_CURSOR`; the client must restart pagination from the beginning (no partial-recovery attempt is made server-side).

## 12. Expired Cursors

Cursors do not expire by design (they encode sort-key values, not a session or offset); however, if the underlying sort-key row has since been hard-deleted/archived beyond retention (§[23-retention-deletion-contract](./23-retention-deletion-contract.md)), the next page simply resumes correctly from the encoded sort-key value with no error — deletion of the referenced row does not invalidate the cursor.

## 13. Records Changing Between Requests

A record updated between page fetches such that its sort-key value changes (e.g., `updatedAt`-sorted list, and the record is updated) may appear again on a later page or be skipped, consistent with §10; endpoints for which this would be operationally unacceptable (none currently identified) would require an explicit point-in-time snapshot mechanism, not the default cursor contract.

## 14. Duplicate Records Across Pages

Given the identifier-tiebreaker rule (§3), duplicates across pages do not occur for records whose sort key is stable between fetches; §13 covers the one case where a record's sort key itself changes.
