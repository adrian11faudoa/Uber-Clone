# Contract 29 — Operations and Support Contract

Implementation-ready extension of [21-web-admin-analytics-data-observability.md](../21-web-admin-analytics-data-observability.md) Part B.

## 1. Support Case Management

`Support Case` (§[05-domain-entity-inventory.md](../05-domain-entity-inventory.md)) is the unit of work for support agents; every investigation type below (user, trip, driver, payment, safety, fraud) is either conducted *within* a Support Case (for routine investigations) or escalated to its own domain-owned record (Safety Incident, Fraud Signal) when it exceeds support's scope (§6).

## 2. Investigation Types and Required Access

| Investigation | Primary role | Data accessed | Access pattern |
|---|---|---|---|
| User investigation | `support_agent` | Identity, Rider/Driver profile (read) | `:case-linked` scoped read (§[06-authorization-contract](./06-authorization-contract.md) §3) |
| Trip investigation | `support_agent` | Trip, Fare, Location (trip-scoped route) | `:case-linked` scoped read |
| Driver investigation | `support_agent`, escalates to `ops_agent` for compliance actions | Driver, Vehicle, Driver Verification | `:case-linked` scoped read; compliance-status changes require `ops_agent`/`administrator` |
| Payment investigation | `support_agent` (read/propose), `finance_agent` (execute) | Payment Intent, Charge, Refund | `:case-linked` read for support; refund execution requires `finance_agent` (§[06](./06-authorization-contract.md) §2) |
| Safety investigation | `safety_agent` exclusively | Safety Incident, trip/location scoped to the incident | `:investigation-linked` scoped read (§[06](./06-authorization-contract.md) §3), highest confidentiality |
| Fraud investigation | `fraud`-scoped role (a sub-scope of `ops_agent`/`finance_agent` per deployment choice) | Fraud Signal, linked Payment/Trip/User records | `:case-linked` scoped read |
| Manual corrective actions | Role matching the domain (Finance for refunds/payout corrections, Ops for dispatch-policy overrides) | The specific domain's own write API | Full authorization + audit per §5 |

## 3. Privileged Access

Every row in §2 beyond a support agent's own baseline permissions requires the case-linked/investigation-linked scoping mechanism (§[06](./06-authorization-contract.md) §3, §7) — a staff member's role alone never grants blanket access to an arbitrary rider/driver's data absent an active case/incident reference.

## 4. Reason Codes

Every privileged read or corrective write action includes a `reasonCode` (from a documented, extensible enum per [06](../06-identifier-time-data-contract.md) §10) captured at the point of action — e.g., `RIDER_DISPUTE_RESOLVED`, `DRIVER_DOCUMENT_REVIEW`, `FRAUD_REVIEW_ESCALATION` — never a free-text-only justification for actions that feed the audit trail (free text is allowed as a *supplement* to, not a replacement for, a structured reason code, so audit queries remain filterable).

## 5. Approval Requirements

Refund execution above a documented monetary threshold, payout manual overrides, and RBAC changes require a second-actor approval step (the initiating agent's proposal is a distinct pending record until a different, authorized approver confirms it) — this is a policy documented per action type at implementation time, not universally mandated for every action in §2 (per the Master Prompt's guidance to avoid over-engineering trivial cases).

## 6. Escalation Boundaries

A Support Case escalates to a dedicated Safety Incident when it involves an emergency, threat, or safety-relevant allegation (handled thereafter exclusively by `safety_agent`, per [03-domain-decomposition.md](../03-domain-decomposition.md) domain 16's confidentiality requirements — a general support agent loses visibility into the escalated record beyond a "this was escalated" marker); it escalates to a Fraud Signal when it involves suspected payment/promotion/account abuse (handled thereafter by the Fraud & Risk workflow, §[03](../03-domain-decomposition.md) domain 17).

## 7. Auditability

Every action in §2's "Access pattern" and every corrective action is an Audit Event per [24-audit-contract §2](./24-audit-contract.md); support/ops tooling has no code path that writes to a domain's authoritative data without producing the corresponding audit record in the same logical operation.

## 8. Sensitive-Data Masking

Support agents viewing payment details see masked representations by default (e.g., "card ending 4471," never the provider token or full number, consistent with [16-payment-contract §13](./16-payment-contract.md)); full precise location is masked/coarsened in general support views and only shown unmasked to `safety_agent` under an active investigation (§[18-privacy-and-security.md](../18-privacy-and-security.md) §13).

## 9. Support Visibility Boundaries

A support agent's default queue/search (§[20-search-contract §6](./20-search-contract.md)) surfaces only cases assigned to them or their team, not a platform-wide unrestricted view; broader visibility (e.g., an `ops_agent` reviewing regional trends) uses aggregate/de-identified views wherever the specific individual-level detail isn't required for the task.

## 10. Operational Convenience Never Bypasses Authorization/Audit

Restated as an explicit invariant: no "quick fix"/"just this once" code path exists anywhere in the admin/support tooling that skips the ownership/scope check (§[06](./06-authorization-contract.md)) or the audit-event requirement (§[24](./24-audit-contract.md)) — any future request to add such a path is itself a security-review-requiring change, not a routine feature addition.
