# Contract 14 — Trip and Dispatch Contract

Implementation-ready extension of [08-trip-lifecycle-contract.md](../08-trip-lifecycle-contract.md) and [09-dispatch-matching.md](../09-dispatch-matching.md).

## 1. Trip Request Inputs

```json
{
  "pickup": { "lat": 28.63500, "lng": -106.06900, "address": "Optional human-readable string" },
  "destination": { "lat": 28.65900, "lng": -106.08800, "address": "..." },
  "vehicleCategoryId": "018f0b2a-...",
  "requestedOptions": { "petFriendly": false, "wheelchairAccessible": false },
  "fareEstimateId": "018f0b2c-...",
  "scheduledFor": null,
  "promotionCode": null
}
```

`fareEstimateId` is required and validated as owned-by-and-unexpired-for the requesting rider (§[06-authorization-contract §10.4](./06-authorization-contract.md)). `scheduledFor` (UTC timestamp) is null for immediate trips; when set, the Trip Request enters a `SCHEDULED` pre-state (not part of the core state machine in [08](../08-trip-lifecycle-contract.md), handled by the `scheduled-trip-processing` job, §[11-job-contract](./11-job-contract.md)) until it converts to `REQUESTED` at the scheduled time minus a lead window.

## 2. Entity Relationships and Authoritative Ownership

| Entity | Owner | Cardinality relative to Trip |
|---|---|---|
| Trip Request | Trip Management | 1:1 with the resulting Trip (if successful); 1:0 if it expires/fails before assignment |
| Trip | Trip Management | The canonical lifecycle record from `ACCEPTED` onward (a Trip Request that never gets assigned never becomes a Trip) |
| Driver Offer | Dispatch | N:1 with Trip Request (many offers may be issued across the search process; exactly one is accepted) |
| Trip Assignment | Trip Management | 1:1 with Trip once `ACCEPTED`; may be superseded by a new Assignment on reassignment (§[09](../09-dispatch-matching.md) §6), with the prior Assignment marked terminal, never deleted |

Clarifying the Request-vs-Trip split: a `Trip Request` exists from the moment the rider submits it; it is promoted conceptually to a full `Trip` record upon successful `ACCEPTED` assignment. Implementations may choose either a single unified table with a lifecycle including pre-assignment states, or two linked tables — this contract requires only that the **state machine in [08](../08-trip-lifecycle-contract.md) is preserved** and that pre-assignment states (`REQUESTED`, `SEARCHING`, `OFFERED`) are unambiguously distinguishable from post-assignment states in queries and events.

## 3. Candidate-Dispatch Lifecycle (Concrete Sequence)

1. `POST /v1/trips` creates Trip Request, returns `202`-style response (`state: SEARCHING`) — the endpoint does not block until a driver is found.
2. Dispatch begins candidate search (§[09](../09-dispatch-matching.md) §4) asynchronously relative to the API response.
3. Rider subscribes to `trip:{tripRequestId}` realtime channel (§[12-realtime-contract](./12-realtime-contract.md)) immediately after creation to receive the eventual `trip.state_changed` → `ACCEPTED` push, while polling `GET /v1/trips/{id}` remains available as the authoritative fallback.

## 4. Driver Offer

```json
{ "offerId": "018f0b6a-...", "tripRequestId": "018f0b30-...", "driverId": "018f0a20-...", "expiresAt": "2026-09-17T14:03:36.482Z", "estimatedPickupEtaSeconds": 240 }
```

## 5. Offer Expiration

Enforced server-side (§[09](../09-dispatch-matching.md) §6) via a Redis key TTL matching `expiresAt` plus a reconciling sweep; a driver's late "accept" arriving after `expiresAt` is rejected `409 OFFER_EXPIRED`, distinct from `409 OFFER_NO_LONGER_VALID` (claimed by another driver) — both are terminal-offer rejections but with distinguishable causes for client messaging and analytics.

## 6. Acceptance

`POST /v1/driver-offers/{offerId}/accept` (Idempotency-Key required, scoped per [03](./03-idempotency-contract.md)); success promotes the Trip Request to a Trip with an active Assignment (§2) in one transaction (§[04-concurrency-state-contract](./04-concurrency-state-contract.md) §1).

## 7. Assignment

Created atomically with acceptance (§6); carries `tripId`, `driverId`, `offerId` (the winning offer), `assignedAt`.

## 8. Reassignment

`POST /v1/trips/{id}/reassign` (system/Dispatch-internal call, not client-facing) — used when an already-`ACCEPTED` driver cancels before pickup; creates a new Driver Offer cycle and, on a new acceptance, a new Assignment record superseding the prior one (§2), while the Trip's own `tripId` remains stable throughout.

## 9. Cancellation

`POST /v1/trips/{id}/cancel` with `{ "reasonCode": "RIDER_CHANGED_PLANS" }` (`reasonCode` from a documented enum, extensible per [06](../06-identifier-time-data-contract.md) §10); triggers conditional cancellation-fee evaluation via a synchronous Pricing call when cancellation occurs after driver assignment, per policy owned by Pricing (§[11-pricing-architecture.md](../11-pricing-architecture.md)).

## 10. Timeout Behavior

Overall Trip Request search-timeout (§[09](../09-dispatch-matching.md) §5) is a configurable Geographic-Configuration-owned value per Service Area (typically on the order of 2–5 minutes); exceeding it transitions the Trip Request to `EXPIRED` per [08](../08-trip-lifecycle-contract.md).

## 11. Example — Full Offer/Accept Sequence

```
POST /v1/trips                      -> 201 { id, state: SEARCHING }
[async] driver.offer_created (WS)   -> driver app renders offer
POST /v1/driver-offers/{id}/accept  -> 200 { offerId, status: accepted }
[async] trip.state_changed (WS)     -> rider app renders ACCEPTED + driver ETA
```
