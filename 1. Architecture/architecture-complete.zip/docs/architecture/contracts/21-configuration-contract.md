# Contract 21 — Configuration and Feature-Configuration Contract

## 1. Configuration Categories

| Category | Examples | Mutability | Owner |
|---|---|---|---|
| Environment configuration | Database host, Kafka brokers, log level | Immutable per-deployment (set at deploy time) | Infrastructure/DevOps |
| Service configuration | Per-service timeout budgets, connection-pool sizes | Immutable per-deployment, versioned in code/IaC | Owning service team |
| Regional configuration | Service Area boundaries, regional tax rules | Dynamic, admin-editable, versioned | Geographic Configuration (§[03](../03-domain-decomposition.md) domain 20) |
| Pricing configuration | Pricing Rule versions, surge bounds | Dynamic, admin-editable, versioned (never in-place edited) | Pricing |
| Service-area configuration | Active/inactive areas, vehicle-category availability per area | Dynamic, admin-editable | Geographic Configuration |
| Feature flags | Gradual rollout toggles, kill switches | Dynamic, low-latency-read, no version history required beyond current value + audit | Owning domain, managed via Administration tooling |
| Operational thresholds | Dispatch radius-expansion steps, offer TTL, location staleness threshold | Dynamic, admin-editable, versioned where the value affects reproducibility (e.g., offer TTL affects dispute review) | Owning domain |
| Rate limits | Per-endpoint-class limits (§[01-api-contract §14](./01-api-contract.md)) | Dynamic, admin-editable | Security/Platform |
| External-provider settings | Which maps/payment/notification provider is active per region, provider-specific non-secret config (timeouts, endpoints) | Dynamic for provider selection, immutable per-deployment for endpoints | Owning domain (Payments, Location, Notifications) |

## 2. Distinguishing Immutable Deployment Configuration from Dynamic Operational Configuration

Immutable: baked into the deployment (environment variables, config files delivered via CI/CD) — changing it requires a new deployment. Dynamic: stored in PostgreSQL (with the same versioning discipline as Pricing Rules, §[11-pricing-architecture.md](../11-pricing-architecture.md) §4, where the value affects a reproducible business calculation) or a fast-read config store (Redis-cached), changeable at runtime via an Administration-audited workflow without a redeploy.

## 3. Distinguishing Configuration from Secrets

Configuration (this contract) is non-sensitive and may appear in logs/version control (for immutable config) or an admin UI (for dynamic config). Secrets (§[22-environment-secrets-contract](./22-environment-secrets-contract.md)) are never configuration-category data, never appear in the same store, and are never editable via the same Administration UI used for feature flags/pricing rules.

## 4. Feature Flags

Boolean or multi-variant, evaluated per-request against a targeting context (`{ userId, region, accountCategory }`); flag evaluation is cached client-side-of-the-flag-service (short TTL, e.g., 30–60 seconds) to bound propagation delay for a flag flip without requiring a redeploy, and every flag change is an Audit Event (§[24-audit-contract](./24-audit-contract.md)).

## 5. Ownership

Each configuration value has exactly one owning domain (mirroring the Master Prompt's data-ownership principle applied to configuration); a domain's own operational thresholds are never editable by another domain's tooling, only by Administration acting through that domain's own configuration API.

## 6. Change Auditing

Every dynamic configuration change (pricing rule activation, service-area edit, feature-flag flip, rate-limit adjustment) is an Audit Event with before/after values (§[24-audit-contract](./24-audit-contract.md)) — configuration is administrative-action-adjacent and held to the same audit bar as other privileged operations (§[06-authorization-contract §6](./06-authorization-contract.md)).

## 7. Validation

Every dynamic configuration write is schema-validated server-side before acceptance (e.g., a surge multiplier cap enforced per [11-pricing-architecture.md](../11-pricing-architecture.md) §10) — never accepted as free-form unvalidated JSON.

## 8. Caching

Dynamic configuration is cached (Redis, short TTL or pub/sub-invalidated-on-change) at the consuming service to avoid a database round-trip on every request for hot-path values (e.g., dispatch radius-expansion steps); cache invalidation on write is push-based (publish a `config.changed` event, consumers refresh) rather than relying solely on TTL expiry, to bound propagation delay for operationally urgent changes (e.g., disabling a malfunctioning Service Area).

## 9. Rollback

Versioned configuration (Pricing Rules, Service Area definitions) supports rollback by activating a prior version (never by "undoing" — activation of a new version pointing at the old value, preserving full history, consistent with [11-pricing-architecture.md](../11-pricing-architecture.md) §4). Non-versioned configuration (simple feature flags, rate limits) rolls back by a new write reverting the value, with the prior value visible in the audit trail (§6) even though not modeled as a first-class "version."
