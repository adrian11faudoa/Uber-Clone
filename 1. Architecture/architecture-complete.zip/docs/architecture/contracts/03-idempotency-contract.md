# Contract 03 — Idempotency and Duplicate-Request Contract

Extends [06-identifier-time-data-contract §3](../06-identifier-time-data-contract.md).

## 1. Operations Requiring Idempotency

| Operation | Key source | Scope |
|---|---|---|
| Trip creation | Client-generated | `(rider_id, idempotency_key)` |
| Driver acceptance | Client-generated (driver app) | `(driver_id, offer_id, idempotency_key)` |
| Cancellation | Client-generated | `(trip_id, actor_id, idempotency_key)` |
| Payment intent creation | Client- or server-generated (backend-initiated at trip completion uses server-generated) | `(trip_id, idempotency_key)` |
| Payment capture | Server-generated, derived from `payment_intent_id` | `(payment_intent_id)` |
| Refund | Staff/system-generated | `(charge_id, idempotency_key)` |
| Payout initiation | System-generated (scheduled job run id) | `(driver_id, payout_period, idempotency_key)` |
| Promotion redemption | Client-generated | `(rider_id, promotion_id, idempotency_key)` |
| Notification submission | Producer-generated (event id as key) | `(notification_type, recipient_id, dedup_key)` |
| Administrative actions (destructive/state-changing) | Staff-client-generated | `(admin_id, action_type, target_id, idempotency_key)` |
| External webhook processing | Provider-generated event id | `(provider, provider_event_id)` |

## 2. Idempotency Key Format

Client-generated keys are UUIDs (any version acceptable client-side; server does not require UUIDv7 for client-supplied keys, only for entity ids per [06](../06-identifier-time-data-contract.md) §1). Provider webhook idempotency uses the provider's own event id verbatim, not a platform-generated key.

## 3. Scope

An idempotency key is scoped to `(actor_or_producer, endpoint_or_operation, key)` — the same key value used by two different actors or against two different operations is not treated as a collision.

## 4. Retention

Idempotency records (key → response mapping) are retained a minimum of 24 hours and a maximum of 7 days, after which a repeated key is treated as a new request (this window is chosen to comfortably exceed realistic client retry/backoff windows including offline-resume scenarios per [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §9, while bounding storage growth).

## 5. Storage

Redis (primary, with TTL matching the retention window) for high-volume, short-lived keys (trip creation, offer acceptance); a dedicated PostgreSQL table for financial operations (payment capture, refund, payout) where durability beyond a Redis TTL and auditability are required — financial idempotency records are never allowed to be evicted before their business operation's own audit-retention window.

## 6. Request-Hash Handling

Alongside the idempotency key, the server stores a hash of the semantically-relevant request payload. On key reuse, the server compares the new request's hash to the stored hash.

## 7. Same-Key/Different-Payload Behavior

If a reused idempotency key arrives with a payload hash that differs from the original, the server rejects the request with `422` and canonical error `code: IDEMPOTENCY_KEY_PAYLOAD_MISMATCH` — it never silently executes the new payload nor silently returns the old response, since either would be a correctness hazard.

## 8. Replay Behavior

If the key and payload hash match a stored record, the server returns the original response verbatim (same status code and body) without re-executing any side effect, including for responses that were themselves error responses (a duplicate submission of a request that previously failed validation returns that same validation error, not a fresh re-validation).

## 9. Concurrency

If two requests with the same idempotency key arrive concurrently before the first has completed, the second is held (bounded wait, e.g., a few seconds, via a short-lived processing lock keyed by the idempotency key) or immediately rejected with `409`/`retryable: true` and canonical error `code: IDEMPOTENCY_KEY_IN_PROGRESS` if the wait would exceed the caller's reasonable timeout budget — it is never allowed to double-execute the underlying operation.

## 10. Failure Cleanup

If the underlying operation fails with a retryable infrastructure error (not a business-logic error) before producing a durable result, the idempotency record is not persisted as a terminal success/failure — the key remains available for a genuine retry to execute the operation fresh, rather than being permanently poisoned by a transient failure.

## 11. Observability

Metrics: idempotency-key-reuse rate (replay hits), payload-mismatch rejection rate, in-progress-collision rate, per operation type — elevated mismatch rates are a signal of a client-side bug (key reuse across logically different requests) worth alerting on.

## 12. Client-Generated vs. Server-Generated Identifiers

Client-generated: idempotency keys themselves, and any client-side "draft" identifiers used before submission (§[20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §11). Server-generated: all canonical entity identifiers (§[06](../06-identifier-time-data-contract.md) §1) — a client never dictates the `id` of a created resource; the idempotency key and the resulting resource id are always distinct values.

## 13. Example — Idempotent Command

```json
POST /v1/trips
Idempotency-Key: 3fae9d2e-7a1b-4c9d-8e2f-1a2b3c4d5e6f
{ "pickup": {...}, "destination": {...}, "vehicleCategoryId": "...", "fareEstimateId": "..." }
```
A retried identical request with the same header returns the original `201` body unchanged; the same header with a different `pickup` value returns `422 IDEMPOTENCY_KEY_PAYLOAD_MISMATCH`.
