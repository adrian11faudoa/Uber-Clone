# Contract 11 — Queue and Background-Job Contract

## 1. Canonical Job Envelope

```json
{
  "jobName": "payout.process",
  "jobVersion": 1,
  "jobId": "018f0b50-...",
  "producer": "earnings-payouts-service",
  "queue": "payouts",
  "priority": "normal",
  "payload": { "payoutId": "018f0b4e-...", "driverId": "..." },
  "correlationId": "018f0b4d-...",
  "enqueuedAt": "2026-09-17T15:00:00.000Z",
  "idempotencyKey": "payout:018f0b4e-...:2026-09-17"
}
```

## 2. Job Contract Fields

`jobName`/`jobVersion`: identifies the handler and payload shape, versioned like events (§[08-event-contract §4](./08-event-contract.md)). `queue`: the BullMQ queue name, one per domain concern (§3). `priority`: `high`/`normal`/`low`, mapped to BullMQ priority values, used sparingly (e.g., safety-related notification jobs are `high`). `idempotencyKey`: required for every job whose effect is not naturally idempotent (per §[03-idempotency-contract](./03-idempotency-contract.md) principles applied to jobs).

## 3. Canonical Job Categories

| Queue | Producer domain | Purpose | Retry policy | Concurrency |
|---|---|---|---|---|
| `notifications` | Notifications (consuming domain events) | Deliver push/SMS/email | 5 attempts, exponential backoff (1s→30s), then DLQ | High (per-provider rate-limit bounded) |
| `payment-reconciliation` | Payments | Periodic settlement matching | 3 attempts, 5-minute backoff | Low (1 concurrent run per period) |
| `document-processing` | Driver Onboarding & Compliance | Post-upload validation/virus-scan trigger, expiry sweep | 5 attempts, exponential | Medium |
| `search-indexing` | Search Indexing Service (consuming domain events) | Build/update OpenSearch documents | 5 attempts, exponential, then DLQ (rebuildable, so DLQ loss is non-critical) | High |
| `analytics-export` | Analytics | Batch export of aggregated events to warehouse/reporting store | 3 attempts | Low |
| `maintenance` | Various (scheduled) | Idempotency-key table cleanup, outbox cleanup, session/token cleanup | 3 attempts | Low |
| `fraud-analysis` | Fraud & Risk | Async batch scoring of signals | 3 attempts | Medium |
| `scheduled-trip-processing` | Trip Management | Convert a scheduled future trip into an active dispatch cycle at its scheduled time | 5 attempts, short backoff (time-sensitive) | Medium |
| `payout-workflows` | Driver Earnings & Payouts | Scheduled payout batch runs, individual payout provider calls | 5 attempts, exponential, then Finance-alerted `requires_attention` | Low (rate-limit bounded by payout provider) |
| `cleanup` | Various | Retention-driven deletion/anonymization sweeps (§[23-retention-deletion-contract](./23-retention-deletion-contract.md)) | 3 attempts | Low |

## 4. Timeout

Every job declares a processing timeout appropriate to its work (e.g., `notifications`: 10s per job; `payment-reconciliation`: 10 minutes per run); a job exceeding its timeout is treated as failed and retried per its policy, not left to run indefinitely.

## 5. Backoff

Exponential with jitter for all retryable job types (per [26-reliability-failure-contract](./26-reliability-failure-contract.md)); fixed-interval only for strictly periodic scheduled jobs (e.g., a nightly reconciliation run) where "exponential" has no meaning.

## 6. Deduplication

BullMQ's job-id-based deduplication is used wherever a natural job identity exists (e.g., `payout.process` deduplicated by `payoutId` + period, preventing two enqueues of the same payout from both running); combined with idempotency-key handling for the job's actual side effects (§2) as defense in depth.

## 7. Dead-Letter Handling

Jobs exhausting retries move to a queue-specific DLQ (BullMQ's failed-job list, monitored) with full context (payload, error, attempt count); DLQ jobs for financial queues (`payout-workflows`, `payment-reconciliation`) trigger an immediate Finance-facing alert (§[19-failure-model.md](../19-failure-model.md)); DLQ jobs for non-critical queues (`search-indexing`) are reviewed on a routine operational cadence.

## 8. Observability

Per-queue metrics: depth (waiting count), age of oldest waiting job, processing latency distribution, failure rate, DLQ size — all required (§[21](../21-web-admin-analytics-data-observability.md) Part E).

## 9. Cancellation

Jobs supporting cancellation (e.g., a scheduled-trip-processing job for a trip the rider cancelled before its scheduled time) check a cancellation flag on the referenced entity (read from PostgreSQL, the authoritative source, not from job payload state) at the start of processing and no-op if cancelled — the job queue itself has no built-in "cancel a specific enqueued job" requirement beyond BullMQ's native remove-by-id capability, used opportunistically where straightforward.

## 10. Graceful Shutdown Behavior

Worker processes handle `SIGTERM` by ceasing to pull new jobs, allowing in-flight jobs up to their timeout to complete, and cleanly releasing their BullMQ lock on any job not completed in time (so it becomes available for another worker) — required for safe Kubernetes rolling deployments (§[27-schema-evolution-contract](./27-schema-evolution-contract.md) §"deployment ordering").
