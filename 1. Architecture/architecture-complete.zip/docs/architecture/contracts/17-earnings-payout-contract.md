# Contract 17 — Earnings and Payout Contract

Implementation-ready extension of [12-payment-financial-architecture.md](../12-payment-financial-architecture.md) and [03-domain-decomposition.md](../03-domain-decomposition.md) domain 12.

## 1. Driver Earnings Ledger Entry

```json
{
  "ledgerEntryId": "018f0ba0-...",
  "driverId": "018f0a20-...",
  "tripId": "018f0b30-...",
  "entryType": "TRIP_FARE_SHARE",
  "amountMinorUnits": 7620,
  "currency": "MXN",
  "commissionAmountMinorUnits": 2540,
  "recordedAt": "2026-09-17T14:22:05.000Z",
  "sourceEventId": "018f0b95-..."
}
```

`entryType` enum (extensible, §[06](../06-identifier-time-data-contract.md) §10): `TRIP_FARE_SHARE`, `TIP`, `ADJUSTMENT_CREDIT`, `ADJUSTMENT_DEBIT`, `REFUND_CLAWBACK`, `PROMOTIONAL_BONUS`. Every entry is immutable and append-only (§[05](../05-domain-entity-inventory.md)); a correction is always a new offsetting entry (`ADJUSTMENT_CREDIT`/`ADJUSTMENT_DEBIT`), never an edit.

## 2. Commission / Service Fees

Recorded as an explicit `commissionAmountMinorUnits` field on the `TRIP_FARE_SHARE` entry (the platform's cut, derived from the Fare at a documented commission-rate version — commission rate versioning follows the same versioned-configuration pattern as Pricing Rules, §[11](../11-pricing-architecture.md) §4) rather than as a silent deduction with no ledger visibility.

## 3. Tips

Captured via Payments (§[07-domain-command-contract](./07-domain-command-contract.md) #15) and ledgered as a distinct `TIP` entry, 100% credited to the driver (no commission), linked to the same `tripId`.

## 4. Adjustments

`ADJUSTMENT_CREDIT`/`ADJUSTMENT_DEBIT` entries require a `reasonCode` and `approvedBy` (staff actor id) for any Finance-agent-initiated adjustment — system-generated adjustments (e.g., automated promotional bonus payout) use a `service` actor identity instead, still logged.

## 5. Refunds Affecting Earnings

A rider refund that reduces the trip's net revenue below what was already credited to the driver produces a `REFUND_CLAWBACK` entry (negative) linked to the originating Refund — the platform does not attempt to claw back funds already paid out to a driver's bank account retroactively; instead, the clawback nets against the driver's *future* payout balance (§7), and if a driver's balance goes negative, it carries forward rather than triggering an immediate reverse-transfer attempt.

## 6. Payout Eligibility

A driver becomes eligible for a payout run when their accumulated, un-paid-out ledger balance exceeds a configurable minimum threshold (Geographic-Configuration-owned, per Service Area/currency) and their account/compliance status is in good standing (no active Fraud Signal hold, no expired required documents per [03](../03-domain-decomposition.md) domain 2).

## 7. Payout States

`scheduled` → `processing` → `paid` | `failed`; a `failed` payout is retried on the next scheduled run (or manually by Finance) rather than silently dropped, and its underlying ledger balance remains un-paid-out (not marked paid) until an actual `paid` confirmation is received from the provider.

## 8. Payout Provider References

Every Payout stores `providerPayoutId` once initiated (§[16-payment-contract §10](./16-payment-contract.md) pattern applied to payouts).

## 9. Reconciliation

Included in the same `payment-reconciliation` job family (§[11-job-contract](./11-job-contract.md)) — payout settlement confirmation from the provider is matched against internal `Payout` records by `providerPayoutId`; unmatched/discrepant payouts become `ReconciliationException` rows routed to Finance (§[16](./16-payment-contract.md) §11).

## 10. Reversals / Corrections

A payout that the provider later reports as reversed/returned (e.g., invalid bank account) creates a new `ADJUSTMENT_DEBIT` ledger entry equal to the reversed amount and flips the Payout's own state to `failed` retroactively-annotated (never deleted) — the driver's balance is corrected forward, and Support/Finance is notified to collect updated payout details from the driver.

## 11. Distinguishing Concepts

| Concept | Nature |
|---|---|
| Ledger Entry | Immutable fact — "this amount became owed/adjusted at this time for this reason" |
| Current calculated balance | A derived, real-time sum over a driver's ledger entries not yet included in a `paid` Payout — never itself stored as an independently-mutable authoritative field; always recomputed or maintained as a cached projection that is rebuildable from the ledger |
| Payout instruction | The platform's record of "we intend to pay this driver this amount via this method" |
| Provider payout state | The provider's own truth about whether money actually moved (§[12](../12-payment-financial-architecture.md) §11 principle, applied here) |

## 12. Non-Goal

This contract does not replace a full accounting/general-ledger system (multi-currency consolidated books, tax-jurisdiction-aware reporting); it defines the operational boundary sufficient for driver-facing earnings transparency and platform-to-provider payout execution. Broader accounting integration is a later, explicitly separate concern.
