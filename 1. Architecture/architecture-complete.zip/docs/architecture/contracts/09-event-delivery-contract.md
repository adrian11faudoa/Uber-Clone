# Contract 09 — Event Delivery and Consumer Contract

## 1. Delivery Semantics

**At-least-once, by default, for every event type**, per Kafka/Redpanda's standard guarantee and [15-cross-domain-integration.md](../15-cross-domain-integration.md) §6. No event type in this platform currently requires or is designed around exactly-once delivery; exactly-once *processing effect* is instead achieved at the consumer via idempotency (§3), which is the standard, simpler pattern.

## 2. Duplication

Every consumer must tolerate redelivery of the same event (same `eventId`) without duplicating its effect. Redelivery can occur from: consumer-group rebalance, consumer crash-and-restart before offset commit, or producer retry after an ambiguous publish acknowledgment.

## 3. Consumer Idempotency

Achieved via one of: (a) natural upsert keyed by the event's target entity id (e.g., "ensure a ledger entry exists for this `tripId`" rather than "insert a ledger entry"), or (b) an explicit processed-event-id ledger (`(consumer_name, event_id)` unique constraint) checked before applying effects, for consumers whose effect isn't naturally idempotent (e.g., "send exactly one push notification" — Notifications uses the processed-event-id ledger pattern, §[18-notification-contract](./18-notification-contract.md) §6).

## 4. Ordering

Ordering is guaranteed only within a Kafka partition, and only when events sharing an ordering requirement share the same partition key. **Ordering-required event families and their partition key:**

| Event family | Partition key | Why ordering matters |
|---|---|---|
| `trip.*` (lifecycle events for one trip) | `tripId` | Consumers building trip-state read models must not apply `trip.cancelled` before `trip.assigned` |
| `payment.*` (per payment intent) | `paymentIntentId` | Authorize→capture→refund sequence must be applied in order for ledger correctness |
| `driver.availability.changed` | `driverId` | Applying an out-of-order availability change would show a stale status |

Event families without a listed ordering requirement (e.g., `notification.requested`) may be processed in any order relative to each other.

## 5. Partitioning

Partition count per topic is set with future consumer parallelism in mind (§[16-scalability-architecture.md](../16-scalability-architecture.md) §9); the partition key is always the aggregate id relevant to the ordering requirement above, never a round-robin/random key for topics with an ordering requirement.

## 6. Retries

Consumer-side processing failures (e.g., transient DB unavailability while applying an effect) are retried with exponential backoff and jitter (§[26-reliability-failure-contract](./26-reliability-failure-contract.md)) before the consumer commits its offset; a bounded number of retries (e.g., 5, configurable per consumer) precedes dead-lettering (§7).

## 7. Dead-Letter Handling

Events that exhaust retries are published to a `<topic>.dlq` topic with the original envelope plus a `failureReason` and `attemptCount` field; dead-lettered events do not block the main topic's consumer from proceeding to subsequent offsets (consumer commits past the poison message after moving it to the DLQ). DLQ contents are reviewed by the owning domain's on-call/operational process; replay (§9) is the recovery mechanism.

## 8. Poison-Message Behavior

A message that fails deserialization/schema-validation entirely (not merely a transient processing error) is dead-lettered immediately without retry (retrying a malformed message cannot succeed) and raises an immediate alert, since it usually indicates a producer/consumer schema-compatibility violation (§[27-schema-evolution-contract](./27-schema-evolution-contract.md)).

## 9. Replay / Backfill

Kafka/Redpanda's log-retention window (§10) allows a consumer group to reset its offset and reprocess historical events for recovery or backfilling a new consumer (e.g., a newly added Search Indexing consumer backfilling from topic history); replay always re-exercises the same idempotency guarantees in §3, so replay is safe by construction rather than requiring a special "replay mode."

## 10. Event Retention

Topic retention is set per the domain's replay/audit needs: trip-lifecycle and payment topics retain a minimum of 30 days (supporting reasonable operational replay/debugging windows) independent of the underlying entities' long-term retention in PostgreSQL (§[23-retention-deletion-contract](./23-retention-deletion-contract.md)), which remains the true long-term source of truth — Kafka retention is an operational/replay convenience, not the authoritative historical record.

## 11. Lag Monitoring

Per-consumer-group lag (offset behind latest) is a required observability signal (§[21](../21-web-admin-analytics-data-observability.md) Part E §7); alerting thresholds are set relative to each consumer's acceptable propagation-delay SLA (§[15-cross-domain-integration.md](../15-cross-domain-integration.md) §7).

## 12. Schema Compatibility

Per [27-schema-evolution-contract](./27-schema-evolution-contract.md): consumers must tolerate unknown additional fields (forward compatibility) and treat unrecognized enum values as unknown-but-valid rather than erroring (§[06](../06-identifier-time-data-contract.md) §10), since producers may deploy additive changes ahead of all consumers being updated.
