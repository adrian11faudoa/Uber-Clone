# Contract 04 — Concurrency and State-Transition Contract

Extends [08-trip-lifecycle-contract.md](../08-trip-lifecycle-contract.md) §3 and [12-payment-financial-architecture.md](../12-payment-financial-architecture.md) with a cross-workflow concurrency mechanism catalog. **Default mechanism is optimistic concurrency; distributed locking is never the default and requires explicit justification per workflow below.**

## 1. Mechanism Catalog

| Workflow | Mechanism | Rationale |
|---|---|---|
| Trip creation | Unique constraint on `(rider_id, idempotency_key)` | Simple insert-uniqueness suffices; no read-modify-write race exists |
| Driver assignment / offer acceptance | Optimistic concurrency (row version) + unique constraint "one active assignment per trip request" | Multiple simultaneous acceptances are the primary race; version check + uniqueness resolves without locking |
| Cancellation races (rider cancels while driver acts) | Optimistic concurrency on Trip's `version`/`updatedAt` | First committed write wins; loser retries against fresh state |
| Trip start | Optimistic concurrency on Trip `version`, entry-condition check (`DRIVER_ARRIVED`) enforced in the same transaction | No true concurrent-actor race expected (only the assigned driver can start), but the check-then-transition must still be atomic |
| Trip completion | Optimistic concurrency on Trip `version`; fare finalization and payment capture initiation happen in the same transaction as the state write (outbox pattern for the async parts) | Prevents double-completion under client retry |
| Payment capture | Idempotency key (§[03-idempotency-contract](./03-idempotency-contract.md)), not optimistic concurrency — capture is a single terminal transition per Payment Intent | A version check is redundant once idempotency guarantees single execution |
| Refunds | Idempotency key + append-only ledger (no update to the original Charge) | Refunds are new records, not mutations, so no update-race exists on the Charge itself |
| Payout transitions | Optimistic concurrency on Payout `version`; queue-level single-consumer-per-payout guarantee (BullMQ job keyed by `payout_id`) | Avoids two workers processing the same payout concurrently |
| Driver availability transitions | Last-write-wins on the Redis key, with a monotonic `updatedAt` guard (a stale-timestamped update is dropped) | High-frequency, low-consequence-per-individual-update state; optimistic-concurrency-with-retry would add latency disproportionate to the risk |

No workflow above requires a distributed lock (e.g., Redis `SETNX`-based mutex spanning multiple operations); each race is resolved by a single atomic database operation (unique constraint, version-checked update, or natural last-write-wins) scoped to a single resource.

## 2. Authoritative Version / State

Every optimistically-concurrent entity carries a `version` integer (incremented on every write) or uses `updatedAt` as the compare-and-swap value (implementation's choice, applied consistently per entity type); the API layer exposes it and accepts it back via `If-Match` (§[01-api-contract](./01-api-contract.md) §10).

## 3. Transaction Boundaries

Restated from [21-web-admin-analytics-data-observability.md](../21-web-admin-analytics-data-observability.md) Part D.2: every state transition is one local database transaction; cross-domain consequences are outbox-published from within that same transaction, never awaited synchronously as part of it (except where the consequence — e.g., dispatch's assignment claim into Trip Management — is itself the transaction being described).

## 4. Locking Strategy

Row-level locking (`SELECT ... FOR UPDATE`) is permitted only as an implementation detail *within* a single transaction to serialize the read-check-write sequence against concurrent transactions on the *same row* (e.g., reading a Trip row for update before writing its next state) — this is not "distributed locking" in the cross-service sense the Master Prompt cautions against, and remains scoped to standard ACID transaction behavior.

## 5. Duplicate Command Handling

Per [08](../08-trip-lifecycle-contract.md) §4–5: idempotency-key-guarded commands replay their original result; state-transition commands without a supplied idempotency key that target an already-satisfied state (e.g., "start trip" on an already-`IN_PROGRESS` trip by the same actor) are treated as a no-op success, not an error, provided the requesting actor matches the one who already caused that state.

## 6. Stale Command Handling

A command carrying an `If-Match` version older than current state is rejected `409` (§[01](./01-api-contract.md) §10); a command with no `If-Match` supplied on an endpoint that requires it is rejected `400` with canonical error `code: MISSING_PRECONDITION`.

## 7. Conflict Responses

Canonical shape per [01-api-contract](./01-api-contract.md) §8, with `code` values specific to the workflow: `OPTIMISTIC_CONCURRENCY_CONFLICT` (generic), `OFFER_NO_LONGER_VALID` (dispatch-specific), `TRIP_INVALID_TRANSITION` (lifecycle-specific), `PAYOUT_ALREADY_PROCESSING` (payout-specific).

## 8. Reconciliation

Where optimistic-concurrency losers represent a business event worth recording (e.g., a losing driver's declined/expired offer), the loser's rejected attempt is itself recorded (Driver Offer's terminal state, §[09-dispatch-matching.md](../09-dispatch-matching.md) §7) rather than discarded silently, supporting later dispute/analytics needs.
