# Contract 26 — Reliability and Failure Contract

Extends [19-failure-model.md](../19-failure-model.md) with a cross-system retry/timeout/circuit-breaking policy catalog.

## 1. Timeout Budgets

| Call class | Timeout budget | Rationale |
|---|---|---|
| Internal synchronous call, hot dispatch path (Dispatch→Trip Management claim) | 50–100ms | Sub-second offer/accept UX depends on this |
| Internal synchronous call, general (Trip Management→Pricing finalize) | 500ms–1s | Bounded but allows for a real calculation |
| External provider call, maps/routing | 1–2s, single retry then fail | Avoids stacking latency into the rider-facing estimate flow |
| External provider call, payment authorize/capture | 3–5s, per provider SLA | Financial correctness favors patience over premature failure |
| Realtime message delivery | Best-effort, no blocking timeout (fire-and-forget from the publisher's perspective) | Per [13-realtime-architecture.md](../13-realtime-architecture.md), publisher never blocks on fan-out completion |
| Background job processing | Per job type (§[11-job-contract §4](./11-job-contract.md)) | Varies by nature of work |

## 2. Retry Classes

| Class | Definition | Examples |
|---|---|---|
| Safe to retry (idempotent by construction) | `GET` requests; any command carrying a supplied idempotency key (§[03-idempotency-contract](./03-idempotency-contract.md)) | Fetching trip state; retried trip creation with same key |
| Conditionally retryable | Retryable only if the caller can guarantee the same idempotency key/natural-key is reused, or if the operation is a pure read-then-decide with no side effect on the failed attempt | A dispatch candidate-search retry (no side effect from a failed search) |
| Not automatically retryable | Any command without an idempotency key whose side effect is not naturally idempotent | A raw "adjust ledger balance by X" without a natural upsert key — this pattern is disallowed entirely by design (§[17-earnings-payout-contract](./17-earnings-payout-contract.md) requires natural keys/idempotency everywhere financial) |

No operation in this platform's documented command catalog (§[07-domain-command-contract](./07-domain-command-contract.md)) falls into "not automatically retryable" as designed — every mutating command either carries an idempotency key or is naturally idempotent/duplicate-safe (§[04-concurrency-state-contract §5](./04-concurrency-state-contract.md)), which is a deliberate design invariant, not a coincidence.

## 3. Exponential Backoff and Jitter

Standard formula: `delay = min(cap, base * 2^attempt) * random(0.5, 1.5)` (full jitter variant), applied uniformly across internal call retries, event-consumer retries (§[09-event-delivery-contract §6](./09-event-delivery-contract.md)), and job retries (§[11-job-contract §5](./11-job-contract.md)) — `base` and `cap` are tuned per call class (§1) but the jitter formula itself is shared platform-wide to avoid synchronized retry storms across many instances failing simultaneously.

## 4. Circuit Breaking

Applied to external provider calls (maps, payment, notification providers) and to internal synchronous calls whose callee has a materially different failure-isolation boundary (Dispatch → Trip Management): after a documented consecutive-failure or error-rate threshold, the circuit opens (fails fast without attempting the call) for a cool-down window, then half-opens to test recovery. Circuit breaking is **not** applied to calls within a single transaction/module boundary (no benefit, adds complexity) — consistent with "use the simplest correct mechanism" (§[04-concurrency-state-contract §1](./04-concurrency-state-contract.md) principle, applied here to reliability tooling).

## 5. Idempotency (Cross-Reference)

Every retryable operation's safety depends on the idempotency guarantees in [03-idempotency-contract](./03-idempotency-contract.md) and [04-concurrency-state-contract](./04-concurrency-state-contract.md) — this document does not redefine idempotency, only when to apply retries given it.

## 6. Dependency Failure Handling

Per the exhaustive table in [19-failure-model.md](../19-failure-model.md); this document's addition is the *policy* (timeout/retry/circuit-breaker parameters) that makes each row's "retryable? / fallback" column concretely implementable.

## 7. Graceful Degradation

A caller whose dependency's circuit is open degrades per the documented fallback for that dependency (§[19](../19-failure-model.md) table) — e.g., Dispatch with an open circuit to the maps provider falls back to raw-geodesic-distance-based candidate ranking (less accurate ETA, still functional) rather than failing dispatch entirely.

## 8. Backpressure

Producers (API layer accepting requests, event producers) apply backpressure by rejecting new work (`429`/`503`) rather than unboundedly queuing when downstream capacity (worker pool, database connection pool, Kafka producer buffer) is saturated — an unbounded queue is never used as a substitute for capacity planning or circuit breaking.

## 9. Reconciliation

Per [15-cross-domain-integration.md](../15-cross-domain-integration.md) §8 and [16-payment-contract §11](./16-payment-contract.md): the explicit, scheduled mechanism for detecting (not silently auto-correcting) drift that retries/circuit-breaking/backpressure cannot fully prevent (e.g., a provider-side state change that occurred during an outage window the platform missed entirely).

## 10. Dead-Letter Handling / Stale-State Handling / Recovery

Cross-referenced to [09-event-delivery-contract §7–8](./09-event-delivery-contract.md) (events) and [11-job-contract §7](./11-job-contract.md) (jobs); stale-state handling for realtime/mobile clients is defined in [12-realtime-contract §12](./12-realtime-contract.md) and [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §9–10.

## 11. Global Retry Settings Are Explicitly Rejected

Per the Master Prompt's explicit instruction: there is no single global retry-count/backoff constant applied blindly to every call; §1–2 above require every call site to be classified into a call class and retry class before its specific parameters are chosen.
