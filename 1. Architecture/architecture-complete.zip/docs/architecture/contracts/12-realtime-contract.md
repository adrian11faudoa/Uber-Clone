# Contract 12 — Realtime Message Contract

Extends [13-realtime-architecture.md](../13-realtime-architecture.md) with concrete message shapes.

## 1. Connection Authentication / Authorization / Identity

Per [13](../13-realtime-architecture.md) §2–4: WS upgrade requires a valid access token; connection identity is `(userId, sessionId)`.

## 2. Channel / Topic Naming

`trip:{tripId}`, `driver_offers:{driverId}`, `driver_location_feed:{tripId}`, `availability_ops:{regionId}` (ops dashboards), `notifications:{userId}`, `support_incident:{incidentId}` (safety/support monitoring, scoped access).

## 3. Subscription Model

Client-to-server: explicit `subscribe`/`unsubscribe` commands per channel; server validates authorization at subscribe time (§[07](../07-authentication-authorization.md) §3) and rejects with a `subscription_denied` message (never silently ignores) if unauthorized.

## 4. Message Envelope

```json
{
  "messageType": "trip.state_changed",
  "messageVersion": 1,
  "channel": "trip:018f0b30-...",
  "sentAt": "2026-09-17T14:22:03.104Z",
  "correlationId": "018f0a1e-...",
  "payload": { "tripId": "018f0b30-...", "state": "IN_PROGRESS" }
}
```

Client-to-server command envelope:
```json
{ "command": "subscribe", "channel": "trip:018f0b30-...", "requestId": "3fae..." }
```
Server acknowledgment:
```json
{ "command": "subscribe", "channel": "trip:018f0b30-...", "requestId": "3fae...", "status": "ok" }
```

## 5. Message Version

`messageVersion` follows the same additive-evolution rule as events (§[08-event-contract §4](./08-event-contract.md)); clients ignore unrecognized fields and unrecognized `messageType` values gracefully rather than erroring, to tolerate rolling deploys where the gateway ships new message types ahead of all clients.

## 6. Server-to-Client Message Categories

| `messageType` | Channel | Purpose |
|---|---|---|
| `trip.state_changed` | `trip:{tripId}` | Lifecycle transition (§[08](../08-trip-lifecycle-contract.md)) |
| `driver.location_update` | `driver_location_feed:{tripId}` | Best-effort position fan-out (§[10](../10-location-architecture.md)) |
| `driver.offer_created` | `driver_offers:{driverId}` | New offer, primary delivery path (§[09](../09-dispatch-matching.md) §5) |
| `driver.offer_expired` | `driver_offers:{driverId}` | Offer TTL elapsed |
| `driver.availability_summary` | `availability_ops:{regionId}` | Aggregate ops-dashboard signal |
| `notification.delivered` | `notifications:{userId}` | In-app notification push |
| `safety.incident_update` | `support_incident:{incidentId}` | Scoped, audited operational monitoring |
| `subscription_denied` | any | Authorization rejection on subscribe attempt |
| `heartbeat` | connection-level, no channel | Ping/pong keepalive |

## 7. Client-to-Server Commands

`subscribe`, `unsubscribe`, `heartbeat_ack`. **No business-mutating commands are accepted over the realtime channel** — accepting an offer, starting a trip, etc. always go through the synchronous API (§[01-api-contract](./01-api-contract.md)), never the WebSocket, so that idempotency, authorization, and transactional guarantees (§[04](./04-concurrency-state-contract.md)) apply uniformly regardless of transport. The realtime channel is receive-and-subscribe only for state-changing intent.

## 8. Heartbeats

20-second server-initiated ping; client must respond within 10 seconds or is considered stale (§[13](../13-realtime-architecture.md) §9); client may also send its own `heartbeat_ack` proactively on foreground/resume to accelerate liveness confirmation after backgrounding.

## 9. Reconnect Behavior / Synchronization After Reconnect

Per [13](../13-realtime-architecture.md) §7 and [20-mobile-architecture-contracts §12](../20-mobile-architecture-contracts.md): reconnect → re-subscribe → mandatory authoritative API resync before trusting new messages.

## 10. Duplicate Messages

Clients treat all `trip.state_changed` messages as idempotent renders of a state snapshot (apply-if-newer using an embedded `version`/`updatedAt` field in the payload) rather than as incremental deltas, so a duplicate or out-of-order-delivered message never corrupts displayed state — this is the client-side mirror of the server's own idempotent/replay-safe design.

## 11. Ordering

Not guaranteed across messages on different channels; within a single channel, best-effort ordering matches publish order but is not contractually guaranteed for the pub/sub-backed channels (location, offers) — per §10, clients render by version/timestamp comparison, not blind sequential trust. Durable-event-backed channels (trip lifecycle) preserve the ordering guarantee from [09-event-delivery-contract §4](./09-event-delivery-contract.md).

## 12. Stale-State Handling

A client that detects a gap (missed heartbeat, reconnect, or a received message whose embedded version is unexpectedly far ahead of its last-known state) always resyncs via API before continuing to trust the realtime stream (§9).

## 13. Rate Limits / Backpressure

Per [13](../13-realtime-architecture.md) §10–11: inbound command rate-limited per connection; outbound per-connection queue bounded, with location-channel messages coalesced to latest-value-only under backpressure.
