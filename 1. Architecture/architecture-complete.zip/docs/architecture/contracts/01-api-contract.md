# Contract 01 — Canonical API Contract

Extends [../14-api-architecture.md](../14-api-architecture.md) with concrete, implementation-ready rules. Where this document and Volume 1 §14 overlap, this document is the more specific, binding version.

## 1. Base URL / Environment Conventions

`https://api.<env>.<platform-domain>/v1/...` where `<env>` ∈ `{dev, test, staging}` and is omitted for production (`https://api.<platform-domain>/v1/...`). Admin/Ops surface uses a distinct host (`https://ops.<platform-domain>/v1/...`) so network-level controls (WAF rules, IP allowlists) can differ (§[02](../02-system-context.md)).

## 2. Resource Naming, Methods, Path/Query Parameters

Per [Volume 1 §14](../14-api-architecture.md) §1–2, §8. Path parameters are always the resource's canonical identifier (§[06](../06-identifier-time-data-contract.md) §1); query parameters for filtering/sorting/pagination are documented per-endpoint at implementation time against an explicit allow-list.

## 3. Headers

| Header | Direction | Purpose |
|---|---|---|
| `Authorization: Bearer <access_token>` | Request | Authentication (§[05-auth-session-device-contract](./05-auth-session-device-contract.md)) |
| `Idempotency-Key` | Request | Required on non-idempotent mutating endpoints (§[03-idempotency-contract](./03-idempotency-contract.md)) |
| `X-Correlation-Id` | Request (optional) / Response (always) | Client may supply; server always echoes/generates (§[06](../06-identifier-time-data-contract.md) §4) |
| `traceparent` | Request/Response | W3C Trace Context propagation |
| `If-Match` | Request | Optimistic concurrency precondition (§[04-concurrency-state-contract](./04-concurrency-state-contract.md)) |
| `Content-Type` / `Accept` | Both | `application/json` exclusively; no other content negotiation is supported at this stage |
| `Deprecation` / `Sunset` | Response | Deprecation signaling (§13 below) |
| `Retry-After` | Response | Present on `429`/`503` |

## 4. Authentication and Authorization

Per [05-auth-session-device-contract](./05-auth-session-device-contract.md) and [06-authorization-contract](./06-authorization-contract.md). Every endpoint declares required auth category and permission scope; absence of a declaration is an implementation-time lint error, not an implicit allow.

## 5. Idempotency Headers

Required on: trip request creation, offer acceptance, cancellation, payment intent creation/capture, refund creation, payout initiation, promotion redemption. See [03-idempotency-contract](./03-idempotency-contract.md) for full behavior.

## 6. Request Identifiers

Every request is assigned a `correlationId` (client-supplied via `X-Correlation-Id` or server-generated) per [06](../06-identifier-time-data-contract.md) §4; returned in every response, success or error.

## 7. Response Conventions

Single-resource: the resource object directly. Collections: the envelope defined in [Volume 1 §14](../14-api-architecture.md) §5. Every resource response includes `id`, `createdAt`, `updatedAt` (or `occurredAt`/`recordedAt` for immutable entities per §[05](../05-domain-entity-inventory.md)), and a `version` field for optimistically-concurrent resources.

## 8. Canonical Error Structure

```json
{
  "error": {
    "code": "TRIP_INVALID_TRANSITION",
    "message": "Trip cannot transition from COMPLETED to CANCELLED.",
    "correlationId": "018f0a1e-2b3c-7d4e-9f5a-1234567890ab",
    "retryable": false,
    "details": [
      { "field": "state", "issue": "invalid_transition", "currentValue": "COMPLETED" }
    ],
    "docsUrl": "https://docs.<platform-domain>/errors/TRIP_INVALID_TRANSITION"
  }
}
```

- `code`: stable, machine-readable, `UPPER_SNAKE_CASE`, unique per condition, namespaced by domain prefix where useful (`TRIP_`, `PAYMENT_`, `AUTH_`).
- `message`: safe for display/logging; never includes stack traces, SQL, internal file paths, or provider raw error text.
- `retryable`: boolean hint so clients/SDKs can apply the correct retry class (§[26-reliability-failure-contract](./26-reliability-failure-contract.md)).
- `details`: optional, field-level, structured; omitted when not applicable.
- `docsUrl`: optional, omitted for internal-only errors.

Never expose: stack traces, secrets, raw SQL, provider credentials, internal hostnames/IPs.

## 9. Pagination, Sorting, Filtering

Per [02-query-pagination-contract](./02-query-pagination-contract.md).

## 10. Optimistic Concurrency

`If-Match: "<version>"` on mutating requests to resources with meaningful concurrent-modification risk; mismatch returns `409` with the canonical error `code: OPTIMISTIC_CONCURRENCY_CONFLICT` and the current resource state embedded in `details` so the client can reconcile without a second round-trip.

## 11. Retry Behavior

Clients retry only `retryable: true` errors and only for methods documented as safe-to-retry (§[26](./26-reliability-failure-contract.md)); `GET` is always safe; mutating endpoints are safe only when called with the same `Idempotency-Key`.

## 12. API Versioning

Path-prefixed major version (`/v1`); breaking changes require `/v2`+, never an in-place breaking change (Volume 1 §14 §13). Two major versions are supported concurrently during a documented migration window (§[27-schema-evolution-contract](./27-schema-evolution-contract.md)).

## 13. Deprecation Policy

`Deprecation: true` and `Sunset: <RFC-1123 date>` response headers on any endpoint/field scheduled for removal; minimum deprecation window is documented per-change (never less than one full mobile-app-store release cycle, per [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §14).

## 14. Rate Limiting Behavior

`429` with `Retry-After` (seconds) and canonical error `code: RATE_LIMITED`. Limits are tiered: stricter for auth/OTP and payment-mutating endpoints, looser for reference-data reads; internal service-to-service calls use a separate, higher limit keyed by service identity, not end-user identity.

## 15. Example — Request/Response/Error

**Request** — `POST /v1/trips` :
```json
{ "pickup": { "lat": 28.63500, "lng": -106.06900 }, "destination": { "lat": 28.65900, "lng": -106.08800 }, "vehicleCategoryId": "018f0b2a-...", "fareEstimateId": "018f0b2c-..." }
```
Headers: `Idempotency-Key: 3fae9d2e-...`

**Response 201**:
```json
{ "id": "018f0b30-...", "status": "SEARCHING", "riderId": "018f0a1e-...", "fareEstimateId": "018f0b2c-...", "version": 1, "createdAt": "2026-09-17T14:03:21.482Z", "updatedAt": "2026-09-17T14:03:21.482Z" }
```

**Error 409** (duplicate acceptance race):
```json
{ "error": { "code": "OFFER_NO_LONGER_VALID", "message": "This offer has already been claimed by another driver.", "correlationId": "018f0b31-...", "retryable": false } }
```
