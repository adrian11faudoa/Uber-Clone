# Contract 22 — Environment and Secret Contract

Implementation-ready extension of [18-privacy-and-security.md](../18-privacy-and-security.md) §4. No actual secret values appear anywhere in this document.

## 1. Environment Variable Naming

`<SERVICE>_<CATEGORY>_<NAME>` uppercase, e.g., `TRIP_SERVICE_DB_HOST`, `PAYMENTS_STRIPE_WEBHOOK_SECRET_ARN` (note: the variable holds a *reference* to the secret's location in the secret manager, not the secret value itself, per §4). Non-secret config values (timeouts, feature-flag-service URL) may hold their literal value directly in the environment variable; anything classified as a secret (§3) never does.

## 2. Categories of Environment-Configured Values

Database connection parameters (host, port, database name, pool size — credentials excluded, see §3), Redis connection parameters, Kafka broker list and topic-prefix, S3 bucket names and region, observability collector endpoints, and per-service feature toggles that are deployment-time (not runtime-dynamic, distinguishing from [21-configuration-contract](./21-configuration-contract.md) §2 dynamic config).

## 3. Secrets (Never in Environment Variables Directly)

Database credentials, Redis auth token, Kafka SASL credentials, payment-provider API keys and webhook signing secrets, maps/routing provider API keys, push/SMS/email provider credentials, JWT signing keys, S3 access credentials (where not using workload-identity/IAM-role-based access, which is preferred over static credentials entirely). Each of these is retrieved by the workload at startup/runtime from AWS Secrets Manager (or the Kubernetes-secret-integrated equivalent), referenced only by ARN/path in environment/config, never by literal value.

## 4. Secret-Manager Integration Requirement

Every service's deployment manifest declares which secrets it needs by reference; the runtime fetches actual values via the platform's IAM-authenticated secret-manager client at startup (and on rotation, §7) — no secret value is ever baked into a container image, Helm chart, or committed configuration file.

## 5. No Committed Credentials

Enforced structurally (no secret-shaped value is a valid input to source control per repository tooling/linting introduced at implementation time) and procedurally (code review); this architecture volume itself contains zero real secret values, only naming conventions and reference patterns.

## 6. No Secrets in Browser/Mobile Bundles

Client-side code (web bundle, mobile app binary) never embeds a provider secret key — only public/publishable keys where a provider's SDK requires one client-side (e.g., a payment provider's publishable key for hosted-field tokenization, which is safe-by-design to expose per that provider's own security model, distinct from the corresponding secret key used server-side).

## 7. Environment-Specific Configuration

Each environment (local, dev, test, staging, production, per [17-infrastructure-and-multiregion.md](../17-infrastructure-and-multiregion.md) §2) has its own isolated secret namespace/path prefix (e.g., `prod/payments/stripe-secret-key` vs. `staging/payments/stripe-secret-key`) — no environment ever reads another environment's secrets, preventing a staging misconfiguration from touching production credentials or vice versa.

## 8. Secret Rotation Support

Every secret reference supports rotation without a code deployment: the workload re-fetches from the secret manager on a documented refresh interval or in response to a rotation-triggered restart/reload signal; database and provider credentials are rotated on a documented cadence (e.g., quarterly, or immediately upon suspected compromise) as an operational (not architectural) process this contract enables but does not schedule.

## 9. Least Privilege

Each service's IAM role/identity is scoped to read only the specific secrets it needs (e.g., the Notifications service cannot read the payment-provider secret key) — enforced via the cloud IAM policy attached to each deployable's workload identity, mirroring the least-privilege service-to-service authorization matrix in [06-authorization-contract §5](./06-authorization-contract.md).

## 10. Explicit Non-Content

This document defines naming conventions, storage location patterns, and access rules only; it contains no actual connection strings, keys, tokens, or credential values for any environment.
