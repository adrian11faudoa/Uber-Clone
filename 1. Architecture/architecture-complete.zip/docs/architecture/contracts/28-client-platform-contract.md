# Contract 28 — Client Contract Package (Web and Mobile)

Consolidates and makes concrete the shared contract between [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) and [21-web-admin-analytics-data-observability.md](../21-web-admin-analytics-data-observability.md) Part A, for whichever client (web or mobile) is consuming the backend.

## 1. Authentication

Both clients use the access/refresh token model (§[05-auth-session-device-contract](./05-auth-session-device-contract.md)); mobile holds tokens in secure device storage, web holds the refresh token in an httpOnly cookie and proxies authenticated calls server-side where the framework allows (§[21](../21-web-admin-analytics-data-observability.md) Part A §1, §9) — the underlying token semantics (expiry, rotation, revocation) are identical across both.

## 2. API Consumption

Both clients consume the same `/v1` REST API under the same conventions (§[01-api-contract](./01-api-contract.md)); no client-specific API variant exists — mobile and web are peer consumers of one contract, differing only in transport-layer token handling (§1).

## 3. Error Handling

Both render the canonical error envelope (§[01](./01-api-contract.md) §8) via a shared error-code-to-user-message mapping table (maintained once, consumed by both client codebases via a shared package where the tooling allows, e.g., a shared TypeScript types/constants package) — never duplicated, divergent per-client error copy for the same `code`.

## 4. Retries

Both apply the same retry classification (§[26-reliability-failure-contract §2](./26-reliability-failure-contract.md)): safe automatic retry only for `GET` and idempotency-key-bearing requests, using the same backoff formula (§[26](./26-reliability-failure-contract.md) §3).

## 5. Offline State

Mobile: per [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §9 — non-critical reads cached, trip-lifecycle actions never queued offline. Web: no offline mode is required (browser tabs are assumed connected; a disconnected web session simply shows a connectivity error and disables mutating actions until reconnected) — this is a deliberate scope reduction for web relative to mobile, since web ride-hailing usage is a secondary surface to the mobile apps for actual trip-taking.

## 6. Optimistic State

Both follow the state-authority classification in [20-mobile-architecture-contracts.md](../20-mobile-architecture-contracts.md) §13: trip lifecycle/fare/payment always server-authoritative; button-press actions optimistic-with-confirmation; draft form fields locally authoritative until submission.

## 7. Realtime Synchronization

Both use the identical WebSocket contract (§[12-realtime-contract](./12-realtime-contract.md)) and the identical mandatory-resync-on-reconnect rule (§[12](./12-realtime-contract.md) §9, §[20](../20-mobile-architecture-contracts.md) §12).

## 8. Notification Handling

Mobile: push notifications via device tokens (§[18-notification-contract](./18-notification-contract.md), §[20](../20-mobile-architecture-contracts.md) §6). Web: in-app notification channel (§[18](./18-notification-contract.md) §2 `in_app`) delivered via the realtime `notifications:{userId}` channel (§[12](./12-realtime-contract.md) §2) since browser push requires separate, optional service-worker registration not assumed as a baseline capability at this architecture stage.

## 9. Secure Storage

Mobile: Keychain/Keystore (§[20](../20-mobile-architecture-contracts.md) §2). Web: httpOnly cookies for the refresh token; no equivalent of "secure storage" is needed for access tokens on web since they are proxied server-side rather than held client-side JS-accessible (§[21](../21-web-admin-analytics-data-observability.md) Part A §9).

## 10. Deep Links

Mobile: OS-level deep links (§[20](../20-mobile-architecture-contracts.md) §8). Web: equivalent standard URL routing to the same logical destinations (e.g., `/trips/{tripId}`), with the same authorization-before-navigate rule (§[06-authorization-contract §3](./06-authorization-contract.md)).

## 11. Localization

Both consume the same server-maintained localization catalog referenced by `localizationKey` (§[18-notification-contract §5](./18-notification-contract.md) pattern, extended to general UI copy where the platform adopts a shared translation-management system) — no client independently invents translations for shared concepts (trip states, error messages).

## 12. Feature Flags

Both evaluate flags via the same targeting-context shape (§[21-configuration-contract §4](./21-configuration-contract.md)); a flag's rollout behaves identically regardless of client platform unless the flag is explicitly platform-scoped (e.g., a mobile-only feature flag, which is itself a documented, explicit targeting-context field, not an implicit client-side branch).

## 13. Telemetry

Both emit client-side telemetry (screen views, error occurrences, performance timing) tagged with `correlationId` where a telemetry event correlates to a specific API call, feeding the same observability fabric (§[21](../21-web-admin-analytics-data-observability.md) Part E) — client telemetry never includes the sensitive-data exclusions in [18-privacy-and-security.md](../18-privacy-and-security.md) §14 (no tokens, no precise unnecessary location, no message content).

## 14. State Authority Classification (Restated, Applies to Both Clients)

| State | Classification |
|---|---|
| Trip lifecycle, fare, payment | Server-authoritative |
| In-flight action confirmation (accept/start/end) | Optimistic UI, server-confirmed |
| Own current location (mobile only) | Locally authoritative for self-display |
| Draft form input | Locally authoritative until submit |
| Notification read/unread | Locally optimistic, eventually synced |
