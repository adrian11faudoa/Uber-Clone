# 14 — API Architecture and Contract Conventions

Binding project-wide conventions for every REST API surface (consumer, internal, admin). Individual endpoint catalogs are an implementation-phase concern; this document establishes what every endpoint must conform to.

## 1. REST Conventions and Resource Naming

- Resources are plural nouns: `/trips`, `/drivers`, `/payment-methods`. Nested resources reflect true ownership, not arbitrary convenience: `/trips/{tripId}/ratings`, not a flat `/ratings?tripId=`.
- Actions that are not pure CRUD are modeled as sub-resource POSTs on the resource, not verbs in the path where avoidable: `POST /trips/{tripId}/cancel`, `POST /offers/{offerId}/accept`.

## 2. HTTP Methods

Standard semantics: `GET` (safe, cacheable, no side effects), `POST` (create or non-idempotent action, unless paired with an idempotency key per §[06](./06-identifier-time-data-contract.md) §3, in which case it is safely retryable), `PATCH` (partial update), `PUT` reserved for full-resource replacement where genuinely applicable, `DELETE` (removal/deactivation, which for most domain entities means a soft-delete/status change, not physical deletion, per retention rules in §[05](./05-domain-entity-inventory.md)).

## 3. Status Codes

`200`/`201`/`202`/`204` for success variants (`202` for accepted-async operations); `400` malformed request; `401` unauthenticated; `403` authenticated but unauthorized; `404` not found (or not visible to this principal — never distinguish "doesn't exist" from "you can't see it" in the response to avoid enumeration); `409` conflict (concurrency/state-machine violation, §[08](./08-trip-lifecycle-contract.md) §3); `422` semantically invalid though well-formed; `429` rate-limited; `5xx` server-side failure classes.

## 4. Request Validation

All inbound payloads are validated server-side against a Zod (or equivalent) schema at the API boundary before reaching domain logic, regardless of any client-side validation; validation errors return a structured `400`/`422` with per-field detail (§7).

## 5. Response Envelope

Successful responses return the resource(s) directly (no unnecessary wrapper) for single-resource endpoints; collection endpoints use a consistent envelope:

```json
{
  "data": [ /* resource objects */ ],
  "page": { "nextCursor": "opaque-string-or-null", "limit": 25 }
}
```

## 6. Pagination

Cursor-based pagination only for any collection that can grow unbounded (trips, ledger entries, notifications, audit events) — never offset-based for these, to avoid the well-known performance and consistency pitfalls of offset pagination at scale. Cursors are opaque, server-generated tokens; clients must not construct or parse them.

## 7. Error Format

Canonical error envelope, identical shape across every domain:

```json
{
  "error": {
    "code": "TRIP_INVALID_TRANSITION",
    "message": "Trip cannot transition from COMPLETED to CANCELLED.",
    "correlationId": "018f0a1e-...",
    "details": [ { "field": "state", "issue": "invalid_transition" } ]
  }
}
```

`code` is a stable, machine-readable, `UPPER_SNAKE_CASE` identifier unique per error condition (documented per domain as it is introduced); `message` is human-readable and safe to display or log without leaking internals; `correlationId` always matches the request's tracing correlation id (§[06](./06-identifier-time-data-contract.md) §4) to support support-case lookup; `details` is optional, structured, field-level information — never a stack trace or internal exception message.

## 8. Filtering and Sorting

Query-parameter based (`?status=ACTIVE&sort=-createdAt`), with an explicit, per-endpoint allow-list of filterable/sortable fields — never arbitrary free-form query pass-through to the database layer.

## 9. Idempotency

Per §[06](./06-identifier-time-data-contract.md) §3: `Idempotency-Key` header required on documented non-idempotent-by-nature mutating endpoints; servers persist and replay responses for duplicate keys within the retention window.

## 10. Optimistic Concurrency

Endpoints that update a resource with meaningful concurrent-modification risk (trip state, payment state) support an `If-Match`-style precondition using the resource's current version/`updatedAt`; a mismatch returns `409` with current resource state included so the client can reconcile rather than blindly overwrite.

## 11. Authentication and Authorization

Every endpoint declares its required authentication category and permission scope explicitly (§[07](./07-authentication-authorization.md)); there is no "implicitly public" endpoint by omission — absence of an explicit auth declaration is a build-time/lint-time error in the implementation phase.

## 12. Rate Limiting

Per-endpoint-class rate limits (stricter for auth/OTP endpoints, looser for read-heavy reference-data endpoints), enforced at the edge with a `429` + `Retry-After` response; internal service-to-service calls have separate, higher, per-service-identity limits.

## 13. Versioning

APIs are versioned at the path prefix (`/v1/...`); a breaking change requires a new version prefix, never an in-place breaking change to `/v1`. Non-breaking additions (new optional fields, new enum values per §[06](./06-identifier-time-data-contract.md) §10) do not require a version bump.

## 14. Deprecation

Deprecated endpoints/fields are marked via a `Deprecation` response header with a sunset date; removal only occurs after the documented sunset window and only in a new major version.

## 15. Non-Goals of This Document

This document does not enumerate the actual endpoint catalog for any domain — that is produced during backend implementation prompts, constrained to these conventions.
