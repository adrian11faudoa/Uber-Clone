# 10 — Location Architecture

Owned by the Location domain (§[03](./03-domain-decomposition.md)), hosted in the Location Ingestion Service (§[04](./04-service-module-boundaries.md)).

## 1. Storage Categories and Authoritative Purpose

| Category | Store | Authoritative for | Retention |
|---|---|---|---|
| Ephemeral operational location state | Redis (geo-indexed, `GEOADD`/`GEOSEARCH`) | "Where is this driver/rider right now" for Dispatch, Realtime fan-out | Overwritten on every update; TTL'd (e.g., 60–120s) so a disconnected client's last known position expires rather than being treated as current forever |
| Trip-associated historical location | PostGIS (`Location Sample` rows scoped to a `trip_id`) | Route reconstruction, fare/dispute resolution, safety investigation, receipts | Retained per trip-history policy (aligned with Trip retention, §[05](./05-domain-entity-inventory.md)), then eligible for aggregation/purge per [18](./18-privacy-and-security.md) |
| Analytics-oriented location data | Derived, aggregated/anonymized exports consumed by Analytics | Demand heatmaps, regional analytics — never operational decisions | Aggregated; raw precise points not retained in the analytics store beyond a short processing window |

Ephemeral state is never treated as historically authoritative; trip-history is never used for live dispatch decisions (it lags reality); analytics never feeds back into operational decisions synchronously.

## 2. Driver Location Ingestion

- Driver apps push location updates at an adaptive frequency (higher during active trip/dispatch-eligible online state, lower or paused when offline/backgrounded per platform lifecycle constraints) to a dedicated ingestion endpoint (HTTP or WS), separate from general API traffic.
- Each update: `{ driver_id, lat, lng, accuracy, heading, speed, recorded_at (client), received_at (server) }`. Server clock (`received_at`) is authoritative for freshness/staleness decisions; client `recorded_at` is retained for diagnostic/dispute purposes only (§[06](./06-identifier-time-data-contract.md) — never trust client time for business logic).

## 3. Rider Location Updates

Rider location is captured at trip-request time (pickup selection) and, when a trip is active, optionally at a lower frequency for "share my trip" / driver-approach display — always explicit and consent-scoped, never continuous background tracking of riders outside an active request/trip context.

## 4. Location Freshness and Stale-Location Detection

A staleness threshold (e.g., 15–30 seconds, configurable per region) determines whether a driver's last-known position is usable for dispatch matching (§[09](./09-dispatch-matching.md) §3). A background sweep marks drivers whose last update exceeds a longer threshold (e.g., 2 minutes) as `offline` in Driver Availability via a heartbeat-timeout mechanism, correcting for apps that crash without emitting an explicit offline signal.

## 5. Geospatial Indexing

- Redis geospatial commands for the hot ephemeral layer (sub-millisecond candidate lookups).
- PostGIS `geography` columns with GiST indexes for historical/route queries and any query requiring polygon containment (e.g., "is this point inside Service Area X").

## 6. Realtime Propagation

Location updates relevant to an active trip (driver position visible to the rider, and vice versa where applicable) are fanned out via the Realtime Gateway as a best-effort, high-frequency, non-guaranteed channel (§[13](./13-realtime-architecture.md)); the client always has a fallback synchronous "get current driver location" API call for reconciliation after gaps.

## 7. Geographic Partitioning Considerations

The architecture anticipates regional partitioning of the ephemeral Redis layer (e.g., sharded by geohash prefix or region) so that no single Redis node must hold global driver location state; this is a scaling boundary to be implemented when regional volume justifies it (§[16](./16-scalability-architecture.md)), not required from day one.

## 8. Authorization

- Only Dispatch, Realtime (for authorized active-trip subscriptions), and the owning driver/rider may read precise location for a given subject.
- Support/Safety access to historical trip-route location requires the scoped, audited access pattern defined in [07](./07-authentication-authorization.md) §9, tied to a case/incident ID.

## 9. Privacy

- Precise (5-decimal) location is never exposed to a rider beyond what is necessary for the active trip (approaching driver, live position); once a trip completes, only the completed route (not live tracking) remains queryable, and only to authorized parties.
- Rider location is never shared with a driver beyond pickup/destination and any active-trip position needed for navigation.
- See [18](./18-privacy-and-security.md) for coarsening/rounding rules applied to any location surfaced outside its minimal necessary audience.

## 10. Rate Control

Ingestion endpoints enforce per-driver rate limits (reject/drop-oldest on excessive update frequency) to bound both cost and potential abuse (e.g., a compromised client flooding updates).

## 11. Mobile Background-Location Considerations

- iOS/Android background location permissions are requested with a clear, minimal-scope justification (active-trip and online-for-dispatch states only).
- Update frequency and accuracy mode adapt to device battery state and app foreground/background status; the architecture requires the mobile client to reduce frequency significantly when backgrounded and idle (not on a trip, not searching), consistent with platform battery guidelines (§[20](./20-mobile-architecture-contracts.md)).

## 12. Failure Behavior

- Ingestion service outage: driver apps buffer a small number of recent samples client-side and flush on reconnect (bounded buffer, not unbounded offline queueing); Dispatch treats drivers with no fresh location as ineligible rather than guessing.
- Redis outage for the ephemeral layer: dispatch degrades to "no eligible candidates found" rather than falling back to stale/historical data, surfaced as an observable degradation (§[19](./19-failure-model.md)).
