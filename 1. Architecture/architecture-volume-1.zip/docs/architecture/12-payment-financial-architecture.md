# 12 — Payment and Financial Architecture

Owned by Payments and Driver Earnings & Payouts domains (§[03](./03-domain-decomposition.md)), implemented as isolated modules within the API/Backend Application (§[04](./04-service-module-boundaries.md)).

## 1. Boundaries Between Concepts

| Concept | Owner | Represents |
|---|---|---|
| Payment Method Reference | Payments | A tokenized reference to a rider/driver's payment instrument at the provider — never raw card/bank data |
| Payment Authorization | Payments | A provider-side hold against a Payment Method for an estimated/final amount |
| Capture | Payments | Converting an authorization into an actual charge |
| Refund | Payments | A compensating reversal against a Charge |
| Dispute | Payments | A provider-reported chargeback/dispute against a Charge, tracked for reconciliation |
| Rider Charge | Payments | The rider-facing financial outcome of a trip |
| Driver Earnings | Driver Earnings & Payouts | The platform's internal ledger of amounts owed to a driver, derived from completed trips/tips, independent of when the rider's charge settles |
| Payout | Driver Earnings & Payouts | The actual transfer of accumulated earnings to a driver's bank/provider account |
| Tips | Driver Earnings & Payouts (initiated via Payments capture) | A rider-initiated additional amount, captured like a charge but ledgered separately from base fare |
| Receipts | Payments | A generated, immutable record of a finalized trip's financial breakdown |
| Reconciliation | Payments (process owned jointly with Finance role, §[07](./07-authentication-authorization.md)) | Periodic matching of provider-reported settlement data against internal ledger state |

## 2. Provider Integration Boundary

All provider calls go through a `PaymentProviderPort` abstraction (authorize, capture, refund, create payout, verify webhook) implemented initially against a Stripe-compatible provider. Domain logic (Trip Management, Pricing interaction, Earnings calculation) never references provider-specific types or error codes directly — provider errors are translated into a small, stable internal error taxonomy at the port boundary.

## 3. Idempotency

Every provider-mutating call (authorize, capture, refund, payout) is issued with a stable idempotency key derived from the internal entity id (e.g., `payment_intent_id`) so that network retries against the provider never double-charge or double-refund. The internal Payment Intent record's state transition is itself guarded the same way trip-lifecycle transitions are (§[08](./08-trip-lifecycle-contract.md) §3–4): optimistic concurrency + idempotent commands.

## 4. Provider References

Every internal financial record that corresponds to a provider-side object stores the provider's reference id (e.g., `provider_charge_id`) for traceability and reconciliation, without ever storing the provider's raw secret/credential material.

## 5. State Ownership

Payments owns Payment Intent/Charge/Refund state exclusively; Driver Earnings & Payouts owns Ledger Entry/Payout state exclusively. Earnings is created from a completed, captured Charge via an asynchronous, idempotent event consumer (`payment.captured` → ledger entry), never by Payments writing directly into Earnings' schema.

## 6. Immutable Financial Records

Charges, Refunds, and Ledger Entries are append-only/immutable once terminal (§[05](./05-domain-entity-inventory.md)); corrections are always compensating entries (a new Refund, a new adjusting Ledger Entry), never in-place mutation of a historical financial fact.

## 7. Failure Handling

- Authorization failure at trip request time blocks dispatch initiation with a clear rider-facing reason (see [19](./19-failure-model.md)); it does not silently proceed and risk an uncollectable fare.
- Capture failure at trip completion triggers a retry/backoff sequence and, if exhausted, transitions the Payment Intent to a `requires_attention` state surfaced to Finance/Support for manual resolution — the trip itself still completes from Trip Management's perspective (service was rendered), decoupling trip completion from payment settlement completion.
- Webhook delivery failures from the provider are the provider's responsibility to retry; the platform's webhook handler is idempotent (dedup by provider event id) so redelivery is always safe.

## 8. Reconciliation

A scheduled worker job (§[04](./04-service-module-boundaries.md) background tier) periodically compares provider-reported settlement/payout data against internal ledger state, flagging discrepancies as Fraud Signal-adjacent or Finance-review items rather than auto-correcting silently.

## 9. Webhook Trust Model

Inbound provider webhooks are accepted only at a dedicated, unauthenticated-by-token but **cryptographically signature-verified** endpoint (provider's signing secret, held in the secrets boundary, §[18](./18-privacy-and-security.md)); unverified or replayed (by provider event id, deduplicated) webhook payloads are rejected/discarded without processing.

## 10. Audit Requirements

Every financial state transition (authorize, capture, refund, payout initiated/completed/failed) emits an Audit Event (§[03](./03-domain-decomposition.md) domain 19) and a domain event for downstream consumers (Notifications, Analytics); Finance-role access to raw financial detail follows the scoped/audited access pattern in [07](./07-authentication-authorization.md).

## 11. Distinguishing Payment-Provider State from Platform Business State

The provider is the source of truth for whether money actually moved (settlement, payout arrival, dispute outcome); the platform is the source of truth for what the platform believes it is owed/owes and why (trip-linked business context). Reconciliation (§8) is the explicit, observable process that keeps these two eventually consistent — the architecture never assumes they are always in sync.

## 12. No Raw Payment Credentials

The platform never receives, stores, transmits, or logs raw card numbers, CVVs, or full bank account numbers; all sensitive payment collection happens client-side via the provider's SDK/hosted fields, with only a provider token ever reaching platform infrastructure.
