# 08 — Core Trip Lifecycle Contract

Authoritative for backend, mobile, web, QA, and operational work. Owned exclusively by Trip Management (§[03](./03-domain-decomposition.md)). This state machine, not any client's local state, is the source of truth.

## 1. States

| State | Meaning | Valid entry conditions | Authoritative actor |
|---|---|---|---|
| `REQUESTED` | Rider has submitted a trip request | Rider authenticated, valid pickup, valid payment method on file | Rider Management (Trip Management on rider's behalf) |
| `SEARCHING` | Dispatch is actively seeking a driver | From `REQUESTED`, after fare estimate accepted/implicit and dispatch initiated | Dispatch |
| `OFFERED` | A candidate driver has an outstanding offer | From `SEARCHING`, when Dispatch sends an offer | Dispatch |
| `ACCEPTED` | A driver has accepted; trip is assigned | From `OFFERED`, on driver acceptance (first valid acceptance wins) | Dispatch → Trip Management |
| `DRIVER_EN_ROUTE` | Assigned driver is traveling to pickup | From `ACCEPTED` | Driver (client-reported, server-validated against location) |
| `DRIVER_ARRIVED` | Driver has reached pickup location | From `DRIVER_EN_ROUTE`, validated against Location proximity threshold | Driver, server-validated |
| `IN_PROGRESS` | Trip is underway | From `DRIVER_ARRIVED`, on driver "start trip" action | Driver |
| `COMPLETED` | Trip finished successfully | From `IN_PROGRESS`, on driver "end trip" action, fare finalized | Driver → Trip Management (Pricing/Payments finalize) |
| `CANCELLED` | Trip terminated before completion by rider/driver/system | From `REQUESTED`, `SEARCHING`, `OFFERED`, `ACCEPTED`, `DRIVER_EN_ROUTE`, `DRIVER_ARRIVED` | Rider, Driver, or System (policy-driven) |
| `EXPIRED` | No driver found / offer window elapsed with no resolution | From `SEARCHING` or `OFFERED` (offer-level expiry escalates to request-level `EXPIRED` if no further candidates) | System |
| `FAILED` | Unrecoverable system-side failure (e.g., payment pre-auth failure blocking dispatch) | From `REQUESTED`, `SEARCHING` | System |

Terminal states: `COMPLETED`, `CANCELLED`, `EXPIRED`, `FAILED`. No transitions are valid out of a terminal state.

## 2. State Diagram

```mermaid
stateDiagram-v2
    [*] --> REQUESTED
    REQUESTED --> SEARCHING
    REQUESTED --> CANCELLED
    REQUESTED --> FAILED
    SEARCHING --> OFFERED
    SEARCHING --> EXPIRED
    SEARCHING --> CANCELLED
    SEARCHING --> FAILED
    OFFERED --> ACCEPTED
    OFFERED --> SEARCHING: offer declined/expired, retry
    OFFERED --> EXPIRED: no more candidates
    OFFERED --> CANCELLED
    ACCEPTED --> DRIVER_EN_ROUTE
    ACCEPTED --> CANCELLED
    DRIVER_EN_ROUTE --> DRIVER_ARRIVED
    DRIVER_EN_ROUTE --> CANCELLED
    DRIVER_ARRIVED --> IN_PROGRESS
    DRIVER_ARRIVED --> CANCELLED
    IN_PROGRESS --> COMPLETED
    IN_PROGRESS --> CANCELLED: rare/exception path, policy-gated
    COMPLETED --> [*]
    CANCELLED --> [*]
    EXPIRED --> [*]
    FAILED --> [*]
```

## 3. Valid Transitions and Concurrency Considerations

- Every transition is executed as a single authoritative database transaction guarded by an **optimistic concurrency check** (row version / `updated_at` compare-and-swap) so that two concurrent transition attempts (e.g., rider cancels while driver arrives) resolve deterministically: the first committed write wins, the second is rejected with a `409 Conflict`-style domain error and the caller re-reads current state.
- `OFFERED → ACCEPTED` is the most concurrency-sensitive transition (multiple simultaneous offers must never both succeed for the same Trip Request): enforced via a unique constraint on "one active assignment per Trip Request" plus the optimistic check above.
- Cancellation is valid from any non-terminal, pre-`IN_PROGRESS` state unconditionally by the rider (subject to cancellation-fee policy owned by Pricing), and from `IN_PROGRESS` only via an explicit exception/incident-driven policy path (e.g., safety event), not as a normal user action.

## 4. Idempotent Transition Handling

- Every transition-triggering command (accept offer, start trip, end trip, cancel) is idempotent given the same `(trip_id, target_state, idempotency_key)`: replays return the current authoritative state rather than erroring or double-applying side effects.
- Side effects of a transition (e.g., emitting `trip.completed`, triggering Fare finalization) are performed via a transactional outbox pattern so the state transition and its downstream effects are not duplicated on retry (see [15](./15-cross-domain-integration.md)).

## 5. Duplicate Command Behavior

A duplicate "driver accepted" message arriving after the trip is already `ACCEPTED` by that same driver is a no-op returning current state; arriving after a **different** driver was assigned is rejected with an explicit "offer no longer valid" error, never silently ignored, so the losing driver's client can react (e.g., return to search).

## 6. Retry Behavior

Client and internal retries of the same command with the same idempotency key are safe by construction (§4). Retries with a new idempotency key but same intent (e.g., user taps "cancel" twice) must still resolve to the same terminal outcome because the underlying state machine only allows one valid path forward from any given state.

## 7. Reconnect / Stale-Client Behavior

Clients never assume their locally cached trip state is current after any reconnect (app resume, network recovery, WebSocket reconnect): on reconnect, the client fetches authoritative state via the synchronous Trip Management read API before resuming realtime subscription, and reconciles any realtime messages received in the interim against that authoritative snapshot (see [13](./13-realtime-architecture.md)).

## 8. Invalid-Transition Behavior

Any command requesting a transition not listed as valid from the trip's current state is rejected with a structured domain error (see [14](./14-api-architecture.md) error format) identifying the current state and the attempted transition; it is never silently accepted or coerced into a "closest valid" transition.

## 9. Emitted Integration Consequences (Representative, Not Exhaustive)

| Transition | Downstream consequence (async unless noted) |
|---|---|
| → `SEARCHING` | Dispatch candidate search initiated (sync command) |
| → `ACCEPTED` | `trip.assigned` event; Realtime push to rider/driver |
| → `DRIVER_ARRIVED` | Realtime push to rider; Notification |
| → `IN_PROGRESS` | Location begins trip-scoped route retention |
| → `COMPLETED` | Pricing finalize-fare (sync), Payments capture (sync), `trip.completed` event → Notifications, Ratings prompt, Earnings ledger, Analytics |
| → `CANCELLED` | Pricing cancellation-fee evaluation (sync, conditional), `trip.cancelled` event → Notifications, Dispatch offer cleanup |
| → `EXPIRED`/`FAILED` | `trip.failed` event → Notifications, Analytics |

This table is illustrative of the integration pattern (§[15](./15-cross-domain-integration.md)); the exhaustive event catalog is an implementation-phase artifact, not part of this volume.
