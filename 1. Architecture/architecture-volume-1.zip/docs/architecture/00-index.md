# Architecture Volume 1 — Index

Foundational architecture package for the Uber-style ride-hailing and mobility platform. No repository existed at execution time (`/mnt/user-data/uploads` was empty), so this package is delivered as a self-contained documentation set under `docs/architecture/`, ready to be copied into the project repository by the first implementation prompt.

## Reading Order

1. [01-architecture-overview.md](./01-architecture-overview.md)
2. [02-system-context.md](./02-system-context.md)
3. [03-domain-decomposition.md](./03-domain-decomposition.md)
4. [04-service-module-boundaries.md](./04-service-module-boundaries.md)
5. [05-domain-entity-inventory.md](./05-domain-entity-inventory.md)
6. [06-identifier-time-data-contract.md](./06-identifier-time-data-contract.md)
7. [07-authentication-authorization.md](./07-authentication-authorization.md)
8. [08-trip-lifecycle-contract.md](./08-trip-lifecycle-contract.md)
9. [09-dispatch-matching.md](./09-dispatch-matching.md)
10. [10-location-architecture.md](./10-location-architecture.md)
11. [11-pricing-architecture.md](./11-pricing-architecture.md)
12. [12-payment-financial-architecture.md](./12-payment-financial-architecture.md)
13. [13-realtime-architecture.md](./13-realtime-architecture.md)
14. [14-api-architecture.md](./14-api-architecture.md)
15. [15-cross-domain-integration.md](./15-cross-domain-integration.md)
16. [16-scalability-architecture.md](./16-scalability-architecture.md)
17. [17-infrastructure-and-multiregion.md](./17-infrastructure-and-multiregion.md)
18. [18-privacy-and-security.md](./18-privacy-and-security.md)
19. [19-failure-model.md](./19-failure-model.md)
20. [20-mobile-architecture-contracts.md](./20-mobile-architecture-contracts.md)
21. [21-web-admin-analytics-data-observability.md](./21-web-admin-analytics-data-observability.md)
22. [adr/](./adr/) — ADR-0001 through ADR-0005

Documents 16–21 extend beyond the Master Prompt's explicit 1–15 filename list to cover the remaining required subject areas (scalability, multi-region/infrastructure, privacy/security, failure model, mobile contracts, and the combined web/admin/analytics/data-storage/transactions/observability material) without inflating documents 1–15 beyond their stated foundational scope.
