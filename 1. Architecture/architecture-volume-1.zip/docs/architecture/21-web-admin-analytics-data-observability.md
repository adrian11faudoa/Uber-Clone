# 21 — Web, Administration, Analytics, Data Storage, Transactions, and Observability

Consolidates remaining architecture requirements not warranting a standalone numbered volume-1 file.

## Part A — Web Architecture Contracts

1. **Authenticated API access**: Next.js server components/route handlers proxy authenticated calls using an httpOnly, secure session cookie (not localStorage-held tokens) for the rider/admin web surface, mitigating XSS-based token theft; the same backend access/refresh model (§[07](./07-authentication-authorization.md)) underlies it.
2. **Authorization-aware navigation**: route access is checked server-side (middleware) before rendering, not just hidden client-side, consistent with §[07](./07-authentication-authorization.md) §8.
3. **Server/client state separation**: server components fetch authoritative data per request; client components hold only ephemeral UI state (form input, optimistic toggles) — never a duplicated, independently-mutated copy of server state.
4. **Realtime subscriptions**: web client uses the same WebSocket contract as mobile (§[13](./13-realtime-architecture.md)), subject to the same resync-on-reconnect rule.
5. **Caching**: TanStack Query (or Next.js data cache) with explicit invalidation tied to mutation success — no stale-financial-or-lifecycle-data risk left to default cache TTLs alone.
6. **Error contracts**: the canonical error envelope (§[14](./14-api-architecture.md) §7) is rendered via a consistent UI error-handling pattern, surfacing `message` and `correlationId` to the user for support purposes, never raw internals.
7. **Pagination**: cursor-based (§[14](./14-api-architecture.md) §6) reflected in "load more"/infinite-scroll UI patterns, not page-number UI for unbounded collections.
8. **Administrative access**: the Admin/Ops web surface is a logically and, per §[04](./04-service-module-boundaries.md), physically separate application from the consumer rider web app, with its own stricter session/MFA requirements (§[07](./07-authentication-authorization.md)).
9. **Secure token handling**: refresh tokens for the web surface are httpOnly/secure/sameSite cookies; access tokens are never exposed to client-side JS where avoidable.

## Part B — Administration and Operations Architecture

1. **Boundaries**: Support, Operations, Safety, and Finance each get scoped internal APIs (§[07](./07-authentication-authorization.md) §7) exposed through the Admin/Ops Application; none accesses another domain's database directly (§[15](./15-cross-domain-integration.md) §3).
2. **Configuration management**: Geographic Configuration and Pricing Rule authoring happen through Administration-audited workflows that create new versions (§[11](./11-pricing-architecture.md) §4), never in-place edits to active configuration.
3. **Audit investigation**: Administration provides read access to the Audit Event stream, filterable by actor/target/time, itself access-controlled and further audited (meta-audit of who viewed audit logs, for the highest-sensitivity investigations).
4. **No authorization bypass**: every Admin/Ops action executes through the same backend authorization boundary as any other client (§[07](./07-authentication-authorization.md) §8); the Admin/Ops app has broader granted permissions, not a different enforcement path.

## Part C — Analytics Boundaries

1. **Transactional vs. analytical data**: Analytics never reads from or writes to any domain's transactional PostgreSQL schema; it consumes the Kafka/Redpanda event stream asynchronously (§[03](./03-domain-decomposition.md) domain 21, §[15](./15-cross-domain-integration.md) §2).
2. **Operational telemetry vs. product/business analytics**: OpenTelemetry/Prometheus data (§Part E below) serves operational health monitoring; Analytics serves business/product reporting — distinct systems, distinct audiences, not conflated.
3. **Audit records vs. analytics**: Audit Events (compliance-grade, immutable, access-controlled) are never repurposed as a general analytics source; Analytics derives its own aggregates from domain events.
4. **Non-blocking**: analytics ingestion failure or backlog never blocks or slows any operational transaction (§[15](./15-cross-domain-integration.md) §9).
5. **No full warehouse implementation**: this volume does not design a data-warehouse schema or ETL pipeline in detail; it establishes only that Analytics is event-sourced, derived, and decoupled — sufficient for foundational architecture.

## Part D — Data Storage Strategy and Transaction Boundaries

### D.1 Storage Role Summary

| Technology | Authoritative/Derived | Durability | Consistency | Retention | Access Pattern | Failure Behavior |
|---|---|---|---|---|---|---|
| PostgreSQL/PostGIS | Authoritative | High (managed, backed up) | Strong (ACID transactions) | Per-entity policy (§[05](./05-domain-entity-inventory.md)) | Transactional CRUD, spatial queries | Write-path fails fast on outage (§[19](./19-failure-model.md)) |
| Redis | Derived/ephemeral (mostly) | Low-to-none by design for ephemeral keys | Best-effort/eventual for presence-like data | Short TTLs for ephemeral state; longer for cache | High-frequency read/write, geospatial, pub/sub | Degrades dependent features explicitly, never silently stales (§[19](./19-failure-model.md)) |
| Kafka/Redpanda | Authoritative log of facts-that-happened (not current state) | High (replicated log) | At-least-once delivery, ordered per partition key | Configurable topic retention | Append/consume | Producers buffer via outbox; consumers catch up (§[19](./19-failure-model.md)) |
| BullMQ (Redis-backed) | Operational (job state), not business-authoritative | Persisted in Redis, bounded durability | At-least-once job execution | Job-history retention short/medium | Enqueue/consume with retry/backoff | Jobs resume after Redis recovery |
| OpenSearch/Elasticsearch | Fully derived | None (rebuildable) | Eventual | Matches source retention or shorter | Search/filter queries | Outage never blocks writes (§[04](./04-service-module-boundaries.md) §10) |
| S3 | Authoritative for binary content (documents, receipts) | Very high (object storage durability) | Strong read-after-write (standard S3 semantics) | Per-document-type policy | Object read/write via signed URLs | Isolated from transactional-path failures |

Not every technology is used for every domain merely because it exists in the stack (per Master Prompt); the table above is the binding role for each technology used, and any domain proposing an additional technology must justify it via ADR.

### D.2 Transaction Boundaries

| Operation | Atomicity requirement | Pattern |
|---|---|---|
| Account creation | Single PostgreSQL transaction (User + initial profile row) | Direct transaction |
| Driver onboarding state change | Single transaction per state transition; document upload is a separate, eventually-linked S3 write | Direct transaction + async link |
| Trip creation | Single transaction (Trip Request row) | Direct transaction |
| Driver assignment | Single transaction with optimistic concurrency guard (§[08](./08-trip-lifecycle-contract.md) §3) | Direct transaction + outbox event |
| Trip state transitions | Single transaction per transition + outbox event for downstream effects | Transactional outbox |
| Payment state transitions | Single transaction per internal state change; provider call is external and idempotency-key-guarded, not part of the DB transaction | Idempotent external call + local transaction |
| Earnings ledger creation | Single transaction, triggered by idempotent event consumption from `payment.captured` | Idempotent consumer + direct transaction |
| Payout state transitions | Single transaction per state change; provider payout call idempotency-key-guarded | Idempotent external call + local transaction |

No distributed (multi-database) transactions are used anywhere; cross-system consistency uses the transactional-outbox + idempotent-consumer pattern exclusively (§[15](./15-cross-domain-integration.md) §6), which is sufficient for every identified cross-domain consistency need in this volume — no saga/workflow-orchestration engine is required at this architectural stage, though the pattern list in the Master Prompt (outbox, idempotent consumers, saga, reconciliation) remains available if a future domain's requirements exceed simple outbox+idempotent-consumer sufficiency.

## Part E — Observability Architecture

1. **Structured logging**: JSON structured logs, one schema across all services, always including `correlationId`, `traceId`, `service`, `domain` (where applicable), `severity`.
2. **Correlation IDs / trace propagation**: per §[06](./06-identifier-time-data-contract.md) §4, propagated across HTTP, WebSocket upgrade, and Kafka event headers uniformly.
3. **Service metrics**: request rate/latency/error-rate (RED metrics) per endpoint, exported via Prometheus-compatible instrumentation.
4. **Business metrics**: trip funnel conversion (requested→completed), dispatch acceptance rate, payment success rate, payout success rate — each domain publishes its own business metrics, not solely inferred from generic HTTP metrics.
5. **Audit events**: as defined in [18](./18-privacy-and-security.md) §6, distinct from operational logs/metrics.
6. **Health signals**: liveness (process is running) and readiness (dependencies reachable) probes per deployable (§[04](./04-service-module-boundaries.md)), used by Kubernetes for traffic admission and restart decisions.
7. **Critical signals by area** (non-exhaustive, expands on Master Prompt list): trip dispatch (§[09](./09-dispatch-matching.md) §10), trip lifecycle (state-transition counts/latencies per §[08](./08-trip-lifecycle-contract.md)), realtime location (§[13](./13-realtime-architecture.md) §13, §[10](./10-location-architecture.md)), payments/payouts (§[12](./12-payment-financial-architecture.md) §10), event processing/queues (§[19](./19-failure-model.md) lag/backlog metrics), external dependencies (per-provider latency/error-rate).
8. **Sensitive-data exclusion**: per [18](./18-privacy-and-security.md) §14, no credentials, tokens, precise unnecessary location, or free-text sensitive content in any log/metric/trace.
9. **Dashboards and alerting**: Grafana dashboards per domain/deployable; alert thresholds tied to the specific failure-mode table in [19](./19-failure-model.md) (e.g., dispatch degradation alert, provider retry-exhaustion alert, event-lag alert).
