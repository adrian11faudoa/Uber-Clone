# 09 — Dispatch and Matching Architecture

Owned by the Dispatch domain (§[03](./03-domain-decomposition.md)), hosted in the Dispatch & Availability Service (§[04](./04-service-module-boundaries.md)).

## 1. Driver Eligibility

A driver is a dispatch candidate only if all hold simultaneously: `Driver.status = active`, current `Driver Availability = online` (not `on_trip`), assigned `Vehicle.status = active` and category-compatible with the Trip Request, no active blocking Fraud Signal or Safety restriction, and Location freshness within the staleness threshold (§3).

## 2. Availability

Driver Availability (Redis-backed, §[03](./03-domain-decomposition.md) domain 5) is the single source for online/offline/on-trip state. Dispatch reads it directly from the shared Redis keyspace it owns read access to (never duplicates or shadow-writes it) with a bounded read latency budget.

## 3. Location Freshness vs. Availability Freshness vs. Dispatch Eligibility

These are three distinct, independently-tracked freshness concepts:

- **Location freshness**: how recently a location sample was received for a driver (owned by Location domain). Threshold (e.g., 15–30 seconds) beyond which a driver is treated as "stale" for matching purposes even if marked online.
- **Availability freshness**: how recently the driver's online/offline/on-trip flag was updated (owned by Driver Availability). A driver whose app crashed without emitting "offline" is detected via a heartbeat timeout, not inferred from location alone.
- **Dispatch eligibility**: the derived, momentary boolean Dispatch computes at match time by combining current availability state + location freshness + compliance/fraud/vehicle checks. Eligibility is never persisted as a standalone durable flag — it is always recomputed at match time from its inputs, to avoid a fourth, potentially inconsistent source of truth.

## 4. Geographic Candidate Discovery

- Candidate search uses a **bounded radius, bounded result-count, geo-indexed query** (PostGIS `ST_DWithin` over a geography index or Redis geospatial commands `GEOSEARCH`) against the Location domain's current-position keyspace — never an unbounded scan of all drivers.
- Search expands radius in fixed increments (e.g., 1km → 3km → 6km, capped) only if insufficient eligible candidates are found within the current radius and the Trip Request has not exceeded its overall search time budget.
- Vehicle-category compatibility and eligibility (§1) are applied as filters at query time, not post-hoc over the full candidate set, to keep the candidate set small.

## 5. Driver Offer Lifecycle

1. Candidate ranked list produced (by ETA-to-pickup primarily; tie-broken by policy, e.g., driver idle time for fairness).
2. Offer sent to the top candidate with a bounded acceptance TTL (e.g., 10–15 seconds), delivered via Realtime push with a synchronous fallback poll available to the client.
3. On accept: transactional, idempotent "claim" — first accepting driver wins (§[08](./08-trip-lifecycle-contract.md) §3); Trip Management transitions to `ACCEPTED`.
4. On decline or TTL expiry: offer marked terminal, next candidate is offered (bounded retry count), or request returns to `SEARCHING` for a fresh candidate pass if the ranked list is exhausted.
5. If no candidate accepts within the Trip Request's overall search time budget, the Trip Request transitions to `EXPIRED`.

## 6. Offer Timeout, Reassignment, Cancellation

- Offer TTL is enforced server-side via a scheduled expiry check (Redis TTL + reconciling sweep job), not solely client-reported timeout, to tolerate disconnected/backgrounded driver apps.
- Reassignment (driver cancels after acceptance, before pickup) re-enters the dispatch offer lifecycle from a fresh candidate search, preserving the original Trip Request's fare estimate context unless pricing policy requires re-quoting.
- Rider-initiated cancellation at any point clears any outstanding/active offer immediately (idempotent cleanup).

## 7. Duplicate Suppression

Every offer decision (accept/decline) carries an idempotency key scoped to `(offer_id, driver_id)`; duplicate network retries of the same decision are no-ops against already-resolved offers. Duplicate simultaneous offers for the same `(trip_request_id, driver_id)` pair are prevented by a uniqueness constraint at offer-creation time.

## 8. Retry Behavior

Transient failures in the synchronous calls Dispatch makes (Vehicle Management, Pricing, Trip Management) are retried with bounded attempts and exponential backoff within the overall search time budget; exhausting retries surfaces as a `FAILED` or `EXPIRED` trip outcome rather than an indefinite hang (see [19](./19-failure-model.md)).

## 9. Load Management

- Candidate-search and offer-issuance rates are bounded per region/time-window to avoid overwhelming Realtime fan-out during demand spikes; when load exceeds capacity, the system degrades by increasing offer batching/radius-expansion thresholds rather than failing requests outright, with the degradation itself observable (§10).
- Fairness/operational policy controls (e.g., idle-time-weighted ranking, category-priority) are pluggable policy inputs to the ranking step, not hardcoded into the core matching loop, so operational policy can evolve without re-architecting dispatch.

## 10. Dispatch Observability

Required signals: candidate-search latency, candidates-found count per search, offer-acceptance rate, offer time-to-accept, radius-expansion frequency, search-to-expiry rate, dispatch-to-Trip-Management call latency/error rate. All correlated by `trip_request_id`/`correlation_id` (§[06](./06-identifier-time-data-contract.md)).

## 11. Interaction Summary

```mermaid
sequenceDiagram
    participant TM as Trip Management
    participant D as Dispatch
    participant L as Location
    participant A as Driver Availability
    participant P as Pricing
    participant RT as Realtime Gateway
    participant Drv as Driver Client

    TM->>D: initiate dispatch(trip_request_id)
    D->>A: read eligible online drivers (bounded)
    D->>L: geo candidate search (bounded radius)
    D->>P: read fare-relevant category constraints (if needed)
    D->>RT: push offer to top candidate
    RT->>Drv: offer notification
    Drv->>RT: accept (bounded TTL)
    RT->>D: relay decision
    D->>TM: claim assignment (idempotent, transactional)
    TM-->>D: assignment result
    D->>RT: notify rider + losing candidates (if any)
```

Dispatch never commits the platform to an unbounded query model; every candidate search is radius- and result-count-bounded, and every offer has an enforced server-side TTL.
