# 02 — System Context

## 1. Actors

| Actor | Type | Responsibility | Trust Level |
|---|---|---|---|
| Rider | Human, mobile/web client | Requests trips, pays, rates | Untrusted client; authenticated end user |
| Driver-partner | Human, mobile client | Accepts offers, drives trips, earns | Untrusted client; authenticated end user |
| Support personnel | Internal human, web/admin | Handles rider/driver support cases | Privileged internal, scoped |
| Operations personnel | Internal human, web/admin | Manages service areas, dispatch policy, incidents | Privileged internal, scoped |
| Safety personnel | Internal human, web/admin | Investigates safety incidents | Privileged internal, high sensitivity |
| Finance personnel | Internal human, web/admin | Reconciliation, payouts, disputes | Privileged internal, high sensitivity |
| Administrator | Internal human, web/admin | Platform configuration, RBAC, fraud actions | Highest privilege, fully audited |
| Internal services | Service identities | Domain-to-domain calls, workers, gateways | Trusted within VPC, mutually authenticated |
| Map/routing provider | External system | Geocoding, routing, ETA | Untrusted third party, outbound-only trust |
| Payment provider | External system | Auth/capture/refund/payout rails | Untrusted third party, webhook-verified |
| Notification providers (push/SMS/email) | External system | Message delivery | Untrusted third party, outbound |
| Identity/compliance providers | External system (optional, later phase) | Document/background verification | Untrusted third party, contractually scoped |
| Cloud infrastructure (AWS) | Platform | Compute, network, storage, secrets | Trusted infrastructure boundary |
| Observability systems | Platform | Logs/metrics/traces/alerts | Trusted, read-mostly internal |

## 2. Trust Boundaries

- **Public internet boundary**: rider/driver clients and external providers cross this boundary via the API gateway/edge and webhooks only. Nothing inside the VPC is directly reachable from the internet except the gateway and realtime edge.
- **Client boundary**: mobile/web clients are always untrusted; every request is re-authenticated and re-authorized server-side regardless of client-side UI restrictions.
- **Internal service boundary**: backend domain modules and workers share a trusted network but still enforce service-identity authentication and least-privilege data access — trust is bounded by domain ownership, not network location.
- **Administrative boundary**: support/ops/safety/finance/admin actors sit inside a separate, more heavily audited authorization boundary from ordinary riders/drivers, described in [07](./07-authentication-authorization.md).
- **External provider boundary**: payment, maps, and notification providers are treated as untrusted outside the boundary; inbound webhooks are cryptographically verified before being trusted.

## 3. System Context Diagram

```mermaid
flowchart LR
    Rider["Rider (mobile/web)"]
    Driver["Driver-partner (mobile)"]
    SupportOps["Support / Ops / Safety / Finance / Admin (web)"]

    subgraph Platform["Ride-Hailing Platform (trust boundary)"]
        Edge["API Gateway / Edge"]
        RT["Realtime Gateway (WebSocket)"]
        Backend["Backend Domain Modules (modular monolith)"]
        Workers["Background Workers / Jobs"]
        DB[(PostgreSQL + PostGIS)]
        Cache[(Redis)]
        Bus[(Kafka / Redpanda)]
        Search[(OpenSearch)]
        Obj[(S3 Object Storage)]
    end

    Maps["Map / Routing Provider"]
    Pay["Payment Provider"]
    Notif["Push / SMS / Email Providers"]
    Obs["Observability (OTel/Prometheus/Grafana/Loki/Tempo)"]

    Rider -->|HTTPS/WSS| Edge
    Rider -->|WSS| RT
    Driver -->|HTTPS/WSS| Edge
    Driver -->|WSS| RT
    SupportOps -->|HTTPS| Edge

    Edge --> Backend
    RT --> Backend
    Backend --> DB
    Backend --> Cache
    Backend --> Bus
    Backend --> Obj
    Backend -.->|derived| Search
    Bus --> Workers
    Workers --> DB
    Workers --> Notif

    Backend -->|outbound, abstracted| Maps
    Backend -->|outbound, abstracted| Pay
    Pay -.->|verified webhook| Edge

    Backend -.telemetry.-> Obs
    Workers -.telemetry.-> Obs
    RT -.telemetry.-> Obs
```

## 4. Responsibilities Summary

- **Edge/Gateway**: TLS termination, rate limiting, authentication token validation, request routing, WAF.
- **Realtime gateway**: authenticated WebSocket connections, subscription management, fan-out of trip/location/notification events.
- **Backend domain modules**: all authoritative business logic (§[03](./03-domain-decomposition.md), §[04](./04-service-module-boundaries.md)).
- **Workers**: asynchronous, retryable, idempotent processing of events/jobs (payouts, notifications, reconciliation, analytics export).
- **PostgreSQL/PostGIS**: authoritative transactional and spatial data.
- **Redis**: ephemeral/derived state — presence, cache, rate limits, idempotency keys, short-lived location.
- **Kafka/Redpanda**: durable, versioned inter-domain event contracts.
- **S3**: documents, receipts, attachments.
- **OpenSearch**: derived operational/support search indexes only.
- **External providers**: isolated behind explicit abstraction boundaries (§[10](./10-location-architecture.md), §[12](./12-payment-financial-architecture.md), notification boundary in §[15](./15-cross-domain-integration.md)).
