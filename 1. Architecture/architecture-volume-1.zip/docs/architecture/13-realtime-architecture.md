# 13 — Realtime Architecture

Owned by the Realtime Gateway deployable (§[04](./04-service-module-boundaries.md)); channel contracts are defined jointly with the domains that publish into it (Dispatch, Location, Trip Management, Notifications).

## 1. WebSocket Gateway

A dedicated, horizontally scalable WebSocket tier, separate from the stateless HTTP API, fronted by the same edge for TLS/auth pre-check but maintaining its own connection registry (backed by Redis pub/sub or a Kafka-backed fan-out layer for cross-instance delivery).

## 2. Authentication

WS upgrade requires a valid access token (§[07](./07-authentication-authorization.md)) presented at connection time; the gateway validates it identically to the HTTP path (same signature/claims check) before accepting the upgrade. Token expiry mid-connection triggers a required silent re-auth (token refresh over the existing connection or forced reconnect) — the gateway does not keep serving an authenticated session past token expiry indefinitely.

## 3. Authorization

Per-subscription authorization is enforced at subscribe time and re-checked periodically for long-lived subscriptions (e.g., an active trip room): a rider may subscribe only to their own active Trip Request/Trip channel and the driver currently assigned to it; a driver may subscribe only to their own offer/trip channels. Support/Safety/Ops subscriptions to a rider/driver's channel (e.g., live incident monitoring) follow the scoped, audited access pattern (§[07](./07-authentication-authorization.md) §9).

## 4. Connection Identity and Subscriptions

Each connection is associated with `(user_id, session_id)` and a dynamic set of subscribed channels: `trip:{trip_id}`, `driver_offers:{driver_id}`, `driver_location_feed:{trip_id}` (rider viewing assigned driver), `notifications:{user_id}`. Channels are joined/left explicitly by client message, not inferred implicitly, so authorization can be checked per join.

## 5. Fan-Out Strategy

Domain events destined for realtime delivery are published to a Redis pub/sub channel (low-latency, at-most-once, suitable for high-frequency location) or, for events requiring durability/replay (trip state changes), consumed from Kafka by the gateway tier and fanned out to matching connections. High-frequency location uses the pub/sub path; trip-lifecycle and dispatch-offer events use the durable-event path so a momentarily-disconnected gateway instance does not silently drop a critical state change (the client's post-reconnect API resync, §[08](./08-trip-lifecycle-contract.md) §7, is the ultimate backstop regardless).

## 6. What Is Delivered Realtime vs. What Must Be API-Synchronized

| Data | Realtime channel | Always-available synchronous source of truth |
|---|---|---|
| Driver location during active trip | Yes, best-effort, high-frequency | `GET /trips/{id}/driver-location` |
| Trip lifecycle state changes | Yes | `GET /trips/{id}` |
| Dispatch offer to driver | Yes (primary delivery mechanism, short TTL) | `GET /drivers/{id}/offers/current` (fallback poll) |
| Driver availability aggregate (ops dashboards) | Optional, lower priority | `GET /ops/availability-summary` |
| Notifications requiring immediate visibility (safety alert) | Yes | Notification history API |

**Clients must never treat realtime delivery as guaranteed.** Every realtime-delivered fact has a corresponding authoritative synchronous read API, and clients are required to reconcile against it after any reconnect, app-resume, or detected gap (e.g., missed heartbeat).

## 7. Reconnect Behavior

On reconnect: client re-authenticates the WS upgrade, re-joins previously-subscribed channels, and immediately calls the relevant synchronous read APIs to resynchronize state before trusting new realtime messages (§[08](./08-trip-lifecycle-contract.md) §7). The gateway does not attempt to replay a full backlog of missed pub/sub messages (inherently lossy channel); for the durable-event-backed channels (trip lifecycle), a bounded replay-since-last-seen-offset is supported where the underlying Kafka consumer group offset allows it.

## 8. Event Replay / Resynchronization

Trip-lifecycle and dispatch-offer channels support resynchronization via "give me current state + events since sequence N" where feasible; location and pure-presence channels do not support replay by design (they are inherently "current value" channels — see [10](./10-location-architecture.md) §1).

## 9. Stale Connection Handling

Heartbeat ping/pong on a fixed interval (e.g., 20–30s); a connection missing N consecutive heartbeats is closed server-side and its subscriptions torn down, freeing gateway resources and ensuring Location/Dispatch treat that driver/rider as disconnected promptly rather than continuing to target a dead socket.

## 10. Backpressure

Per-connection outbound queues are bounded; if a slow client cannot keep up with its subscribed channels' message rate (most likely on high-frequency location channels), the gateway drops intermediate location updates and delivers only the latest position, never blocking the publisher or growing memory unboundedly.

## 11. Rate Limiting

Inbound client messages (e.g., location pushes if sent over the same WS, subscription join/leave spam) are rate-limited per connection at the gateway to prevent a single misbehaving client from degrading fan-out for others.

## 12. Fan-Out Strategy for Geographic Scale

Gateway instances are horizontally scaled behind the edge; cross-instance message delivery relies on the shared Redis/Kafka fan-out layer (§5) rather than any assumption that a publisher and subscriber share a gateway process — this is required for correctness once more than one gateway instance is running, which is the expected baseline, not an future optimization.

## 13. Observability

Required signals: concurrent connection count, connection churn rate, per-channel fan-out latency, dropped-message count (backpressure), heartbeat-timeout disconnect rate, authorization-rejection rate on subscribe attempts.
