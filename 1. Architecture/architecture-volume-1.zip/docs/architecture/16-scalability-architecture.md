# 16 — Scalability Architecture

Explains how the foundational architecture accommodates the target scale (§[01](./01-architecture-overview.md) §3) without forcing every subsystem to maximum scale immediately.

## 1. Horizontal API Scaling

The API/Backend Application is stateless (session state in Redis/JWT, not in-process); it scales horizontally behind a load balancer with no code change required. This is the default, always-on scaling mechanism and requires no future architectural work to activate.

## 2. Realtime Connection Scaling

The Realtime Gateway scales horizontally with cross-instance fan-out via the shared Redis/Kafka layer (§[13](./13-realtime-architecture.md) §5/§12) — this cross-instance capability is required from the first multi-instance deployment, not deferred, since a single-instance assumption would be an immediate correctness bug, not just a scaling gap.

## 3. Dispatch Scaling

Dispatch scales by geographic partitioning of candidate search (§[09](./09-dispatch-matching.md) §4, §[10](./10-location-architecture.md) §7): each region's active-trip-request volume and driver density can be handled by independently scaled Dispatch instances once regional partitioning is introduced. Initial deployment may run a single logical Dispatch tier globally; regional partitioning is an intentional, well-defined future evolution point, not a redesign.

## 4. Location-Ingestion Scaling

The highest-throughput subsystem; scales by (a) isolating ingestion from transactional API capacity (§[04](./04-service-module-boundaries.md) §1) and (b) geographic sharding of the Redis geo-index (§[10](./10-location-architecture.md) §7) as regional driver density grows.

## 5. Asynchronous Workload Scaling

Kafka/Redpanda consumer groups and BullMQ workers scale by adding consumer instances within a partition/queue-concurrency model; partition count for high-volume topics (location-derived analytics, trip lifecycle events) is chosen with future consumer parallelism in mind, documented per-topic at implementation time.

## 6. Database Read Scaling

PostgreSQL scales reads via read replicas for reporting/support-tool queries that can tolerate slight replication lag; the authoritative transactional path (trip lifecycle, payments) always reads/writes the primary to avoid stale-read correctness bugs in financial/lifecycle logic.

## 7. Cache Scaling

Redis scales via managed clustering (e.g., ElastiCache cluster mode) once single-node capacity is insufficient; key design (§[10](./10-location-architecture.md), Driver Availability) anticipates cluster-mode-compatible key patterns (avoiding cross-slot multi-key operations) from the start to avoid a later breaking migration.

## 8. Search Scaling

OpenSearch scales via standard shard/replica configuration; since it is fully derived (§[04](./04-service-module-boundaries.md) §10), it can be rebuilt from the event log/database at any time, which also means scaling mistakes are recoverable without data loss risk.

## 9. Event Streaming Scaling

Kafka/Redpanda scales via partition count and broker count; event keys are chosen (typically the relevant aggregate id — `trip_id`, `driver_id`) to preserve necessary per-entity ordering while allowing parallelism across entities.

## 10. Background-Job Scaling

BullMQ queue concurrency is tuned per queue based on downstream dependency capacity (e.g., payout queue concurrency bounded by payment-provider rate limits), not maximized blindly.

## 11. Intentional Non-Maximal Scaling at This Stage

The modular monolith (ADR-0001), single logical Dispatch tier, and single-region assumption (§[17](./17-infrastructure-and-multiregion.md)) are all deliberate, documented starting points — each has an explicit extraction/partitioning path defined above and in the relevant domain document, so scaling is evolutionary, not a future redesign.
