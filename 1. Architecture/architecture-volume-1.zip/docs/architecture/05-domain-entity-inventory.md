# 05 — Domain Entity Inventory

Conceptual entities only; physical schema (columns, indexes) is left to backend implementation prompts, constrained by [06](./06-identifier-time-data-contract.md). Privacy classification: L/M/H/C as in [03](./03-domain-decomposition.md).

| Entity | Owner Domain | Identifier | Lifecycle | Key Relationships | Privacy | Mutability | Retention |
|---|---|---|---|---|---|---|---|
| User | Identity & Accounts | `user_id` (UUID) | created → active → suspended/deleted | Root reference for Rider Profile, Driver, staff roles | H | Mutable (status), immutable core (created_at) | Retained per account lifecycle + legal hold rules |
| Rider Profile | Rider Profile | `rider_profile_id` | active → deactivated | 1:1 User | M | Mutable | Tied to User retention |
| Driver | Driver Onboarding & Compliance | `driver_id` | applied → under_review → approved/rejected → active → deactivated | 1:1 User; 1:N Vehicle | C | Mutable (status) | Regulatory minimums may exceed account deletion |
| Driver Verification | Driver Onboarding & Compliance | `verification_id` | submitted → reviewed → approved/expired | N:1 Driver | C | Append-heavy, status mutable | Document retention per compliance policy, not indefinite |
| Vehicle | Vehicle Management | `vehicle_id` | registered → approved → active → retired | N:1 Driver; N:1 Vehicle Category | M | Mutable | Retained while driver active + audit window |
| Vehicle Category | Vehicle Management | `vehicle_category_id` | static reference | N:1 Service Area (regional availability) | L | Rarely mutated | Indefinite (reference data) |
| Service Area | Geographic Configuration | `service_area_id` | draft → active → retired | Referenced by Pricing, Dispatch, Location | L | Mutable (config) | Indefinite (config) |
| Driver Availability | Driver Availability | `driver_id` (current state, not row history) | offline → online → en_route/on_trip → offline | 1:1 Driver (current), event history append-only | M | Highly mutable (state), immutable event log | Current state ephemeral (Redis); event history bounded (e.g., 90 days) |
| Location Sample | Location | `sample_id` | ephemeral point-in-time | N:1 Driver or Rider; N:1 Trip (when trip-scoped) | C | Immutable once written | Ephemeral raw samples short-lived (minutes–hours); trip-scoped route retained per trip-history policy; then aggregated/purged |
| Trip Request | Trip Management | `trip_request_id` | requested → searching → offered/expired/failed | 1:1 Rider; 1:1 resulting Trip (if successful) | H | Mutable until terminal, then immutable | Retained with Trip history |
| Trip | Trip Management | `trip_id` | see [08](./08-trip-lifecycle-contract.md) state machine | 1:1 Trip Request; 1:1 Driver Assignment; 1:1 Fare; 1:1 Payment Intent | H | Mutable until COMPLETED/CANCELLED/FAILED, then immutable | Long-term (ride history, legal/financial requirements) |
| Trip Assignment | Trip Management | `assignment_id` | created → active → completed/reassigned | N:1 Trip; N:1 Driver Offer | H | Mutable until terminal | With Trip |
| Driver Offer | Dispatch | `offer_id` | sent → accepted/declined/expired | N:1 Trip Request; N:1 Driver | H | Mutable until terminal, then immutable audit record | Operational: short TTL; audit copy retained for dispute/ops window |
| Route | Trip Management (reference, sourced via Location/provider) | `route_id` | computed → superseded | N:1 Trip | M | Immutable once associated with a completed leg | With Trip |
| Fare Estimate | Pricing | `fare_estimate_id` | generated → expired/consumed | N:1 Trip Request; references Pricing Rule version | H | Immutable once generated | Short (quote validity window) then archival with Trip if consumed |
| Fare | Pricing | `fare_id` | calculated → finalized | 1:1 Trip; references Pricing Rule version, Promotion | H | Immutable once finalized | With Trip |
| Pricing Rule | Pricing | `pricing_rule_id`, versioned | draft → active → superseded | N:1 Service Area, N:1 Vehicle Category | M | Immutable per version (new version on change) | Indefinite (auditability) |
| Promotion | Promotions | `promotion_id` | active → expired/exhausted | N:1 Rider Profile (redemptions) | M | Mutable (status/usage count) | Retained for fraud/audit window |
| Payment Method Reference | Payments | `payment_method_id` | added → active → removed | N:1 Rider Profile/Driver; references provider token, not raw card data | C | Mutable (default flag), immutable token reference | Retained while active; provider token revoked on removal |
| Payment Intent | Payments | `payment_intent_id` | created → authorized → captured/failed/cancelled | 1:1 Trip (typical) | C | Mutable until terminal, then immutable | Long-term (financial record) |
| Charge | Payments | `charge_id` | created → succeeded/failed | N:1 Payment Intent | C | Immutable once terminal | Long-term |
| Refund | Payments | `refund_id` | requested → processed/failed | N:1 Charge | C | Immutable once terminal | Long-term |
| Driver Earnings Ledger Entry | Driver Earnings & Payouts | `ledger_entry_id` | posted (append-only) | N:1 Driver; N:1 Trip (typical) | C | Immutable (append-only ledger) | Long-term (financial record) |
| Payout | Driver Earnings & Payouts | `payout_id` | scheduled → processing → paid/failed | N:1 Driver; aggregates N Ledger Entries | C | Mutable until terminal, then immutable | Long-term |
| Tip | Driver Earnings & Payouts | `tip_id` | created → captured | 1:1 Trip; 1:1 resulting Ledger Entry | C | Immutable once captured | With Trip |
| Rating | Ratings & Reviews | `rating_id` | submitted (immutable) | N:1 Trip; directional (rider→driver or driver→rider) | M | Immutable | Long-term (aggregate scoring) |
| Review | Ratings & Reviews | `review_id` | submitted → (optionally moderated) | N:1 Trip | M | Mutable only via moderation action (audited) | Long-term, moderation-window mutable |
| Notification | Notifications | `notification_id` | queued → sent/failed | N:1 User | M | Immutable once sent | Short-to-medium (delivery/debug window) |
| Conversation | Messaging | `conversation_id` | opened → closed (trip-scoped) | 1:1 Trip (typical) | M-H | Mutable (status) | Retained per trip-history/privacy policy, then purged/redacted |
| Message | Messaging | `message_id` | sent (immutable) | N:1 Conversation | M-H | Immutable | With Conversation retention policy |
| Support Case | Support | `support_case_id` | opened → in_progress → resolved/closed | N:1 User; may reference Trip/Payment | H | Mutable until closed | Retained per support/audit policy |
| Safety Incident | Safety | `safety_incident_id` | reported → investigating → resolved | N:1 Trip (typical); N:1 User(s) | C | Mutable during investigation, then locked | Long-term, legally-driven retention |
| Fraud Signal | Fraud & Risk | `fraud_signal_id` | detected → reviewed → actioned/dismissed | N:1 User/Trip/Payment | H | Mutable (review status) | Retained per risk-policy window |
| Administrative Action | Administration | `admin_action_id` | executed (immutable) | N:1 Administrator; N:1 target entity | C | Immutable | Long-term (audit) |
| Audit Event | Administration (shared infra) | `audit_event_id` | recorded (immutable) | Polymorphic reference to any entity | C | Immutable, append-only | Long-term (compliance) |

## Notes

- Every entity above carries `created_at`/`updated_at` (UTC) per [06](./06-identifier-time-data-contract.md); not restated per row.
- "Immutable once terminal" entities must be updated only by inserting a new versioned record or a compensating entry (e.g., Refund compensates Charge), never by mutating history.
- Physical field-level schemas, additional indexes, and exact foreign-key cascade behavior are implementation-prompt concerns, not this volume's.
