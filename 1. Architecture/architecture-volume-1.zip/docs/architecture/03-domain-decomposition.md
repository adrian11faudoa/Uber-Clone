# 03 — Domain Decomposition

Domains are conceptual ownership boundaries, not deployment units. Multiple domains may be co-hosted in the same deployable (see [04](./04-service-module-boundaries.md)). Every domain has exactly one authoritative data owner; other domains read via API/event, never via direct storage access.

Legend — Sync: synchronous API/RPC interface exposed. Async: events published/consumed. Sensitivity: L=low, M=medium, H=high, C=critical (financial/safety/PII).

## 1. Identity & Accounts
- **Responsibility**: authentication, credentials, account status, session/device management, base profile identity shared by rider/driver/staff.
- **Owned entities**: User, Credential, Session/Device, Role assignment.
- **Authoritative data**: identity records, auth tokens' issuance state.
- **Inbound deps**: none (root domain).
- **Outbound deps**: none required; Notifications (async) for security emails.
- **Sync**: login, token refresh, profile read/update, RBAC lookups (internal).
- **Async**: `identity.user.created`, `identity.user.suspended`.
- **Sensitivity**: H (PII, credentials).
- **Scaling**: read-heavy, cache-friendly (Redis session cache); horizontally scalable stateless auth.
- **Failure isolation**: must degrade gracefully — auth outage blocks nearly everything, so it requires the highest availability target and aggressive caching of valid tokens.

## 2. Driver Onboarding & Compliance
- **Responsibility**: driver application, document upload/verification, approval workflow, expiration tracking.
- **Owned entities**: Driver, Driver Verification.
- **Authoritative data**: onboarding/approval status, document metadata (files in S3).
- **Inbound**: Identity (user reference).
- **Outbound**: Notifications (status updates), optional external compliance/identity-verification provider.
- **Sync**: submit application, admin review actions.
- **Async**: `driver.approved`, `driver.rejected`, `driver.document_expiring`.
- **Sensitivity**: C (identity documents, background-check-adjacent data).
- **Scaling**: low-to-moderate volume, not latency-critical.
- **Failure isolation**: independent from trip-taking path; an outage here blocks new driver activation only.

## 3. Vehicle Management
- **Responsibility**: vehicle records, category assignment, inspection/eligibility.
- **Owned entities**: Vehicle, Vehicle Category.
- **Inbound**: Driver Onboarding.
- **Outbound**: Dispatch (category compatibility), Pricing (category rates).
- **Sync**: CRUD, eligibility check.
- **Async**: `vehicle.approved`, `vehicle.deactivated`.
- **Sensitivity**: M.
- **Scaling**: low volume.

## 4. Rider Profile
- **Responsibility**: rider-specific profile data (payment defaults reference, saved places, preferences).
- **Owned entities**: Rider Profile.
- **Inbound**: Identity.
- **Outbound**: Payments (payment method reference only), Notifications.
- **Sensitivity**: M.
- **Scaling**: read-heavy, cacheable.

## 5. Driver Availability
- **Responsibility**: real-time online/offline/on-trip state and eligibility-to-receive-offers flag.
- **Owned entities**: Driver Availability (state, not history).
- **Inbound**: Identity, Vehicle Management, Location (freshness signal).
- **Outbound**: Dispatch (primary consumer).
- **Sync**: set status.
- **Async**: `driver.availability.changed`.
- **Sensitivity**: M (operational, not PII beyond driver linkage).
- **Scaling**: very high write volume; Redis-backed with periodic durable snapshot.
- **Failure isolation**: must not block trip completion if availability service degrades — dispatch falls back to last-known-good state within a bounded staleness window.

## 6. Location
- **Responsibility**: ingestion, freshness, and fan-out of driver/rider geolocation.
- **Owned entities**: Location Sample (ephemeral) and derived Trip Route history.
- **Inbound**: mobile clients (via edge/realtime).
- **Outbound**: Dispatch, Realtime, Trip Management (route history), Analytics (derived, delayed).
- **Sensitivity**: C (precise location is highly sensitive PII).
- **Scaling**: highest write throughput in the system; Redis + PostGIS partitioned by geography (see [10](./10-location-architecture.md)).
- **Failure isolation**: isolated ingestion tier so location spikes cannot starve transactional API capacity.

## 7. Trip Management
- **Responsibility**: canonical trip/trip-request lifecycle and state machine.
- **Owned entities**: Trip Request, Trip, Trip Assignment, Route (reference).
- **Inbound**: Rider Profile, Pricing (fare estimate), Dispatch (assignment).
- **Outbound**: Payments, Notifications, Ratings, Realtime, Analytics.
- **Sensitivity**: H (financial + PII linkage).
- **Scaling**: strongly consistent, PostgreSQL-transactional; horizontally scalable stateless API layer in front of it.
- **Failure isolation**: the single most protected synchronous path in the platform (see [08](./08-trip-lifecycle-contract.md)).

## 8. Dispatch
- **Responsibility**: matching trip requests to eligible drivers, offer lifecycle.
- **Owned entities**: Driver Offer (ephemeral + audit record).
- **Inbound**: Trip Management, Driver Availability, Location, Vehicle Management, Pricing.
- **Outbound**: Trip Management (assignment result), Realtime (offer push), Notifications.
- **Sensitivity**: H (operational + indirectly financial).
- **Scaling**: geo-partitioned candidate search, bounded by radius/time windows — never unbounded scans (see [09](./09-dispatch-matching.md)).

## 9. Pricing
- **Responsibility**: fare estimation and final fare calculation, surge/dynamic pricing.
- **Owned entities**: Fare Estimate, Fare, Pricing Rule.
- **Inbound**: Trip Management, Vehicle Management, Geographic Configuration, Promotions.
- **Outbound**: Trip Management, Payments.
- **Sensitivity**: H (financial).
- **Scaling**: read-heavy estimate path must be low-latency; versioned, deterministic, auditable (see [11](./11-pricing-architecture.md)).

## 10. Promotions
- **Responsibility**: promo code issuance, eligibility, discount application.
- **Owned entities**: Promotion.
- **Inbound**: Rider Profile.
- **Outbound**: Pricing.
- **Sensitivity**: M (fraud-adjacent).

## 11. Payments
- **Responsibility**: payment method reference, authorization, capture, refunds, receipts.
- **Owned entities**: Payment Method Reference, Payment Intent, Charge, Refund, Receipt.
- **Inbound**: Trip Management, Pricing, Rider Profile.
- **Outbound**: Notifications, Driver Earnings, Analytics (derived).
- **Sensitivity**: C (financial, PCI-adjacent — no raw card data stored).
- **Scaling**: strongly consistent, idempotent, provider-abstracted (see [12](./12-payment-financial-architecture.md)).

## 12. Driver Earnings & Payouts
- **Responsibility**: earnings ledger, payout scheduling/execution, tips.
- **Owned entities**: Driver Earnings Ledger Entry, Payout, Tip.
- **Inbound**: Payments, Trip Management.
- **Outbound**: Notifications, external payout rail (via Payments' provider abstraction).
- **Sensitivity**: C (financial).
- **Scaling**: batch-oriented, transactional, fully auditable/immutable ledger.

## 13. Ratings & Reviews
- **Responsibility**: post-trip rating/review capture and aggregate scoring.
- **Owned entities**: Rating, Review.
- **Inbound**: Trip Management.
- **Outbound**: Driver Availability/Onboarding (score-based eligibility), Fraud & Risk.
- **Sensitivity**: M.

## 14. Notifications
- **Responsibility**: push/SMS/email/in-app delivery, preferences, retries/dedup.
- **Owned entities**: Notification.
- **Inbound**: nearly all domains (async event consumers).
- **Outbound**: external push/SMS/email providers.
- **Sensitivity**: M (content may carry PII; must not leak sensitive detail into provider logs).
- **Scaling**: queue-based, horizontally scalable consumers.

## 15. Messaging
- **Responsibility**: in-trip rider↔driver communication (masked contact or in-app chat).
- **Owned entities**: Conversation, Message.
- **Inbound**: Trip Management (scoping to active trip).
- **Outbound**: Realtime, Notifications.
- **Sensitivity**: M-H (content privacy, retention-limited).

## 16. Safety
- **Responsibility**: emergency actions, trip sharing, incident intake/escalation.
- **Owned entities**: Safety Incident.
- **Inbound**: Trip Management, Location, Messaging.
- **Outbound**: Support, Administration, external emergency integrations (future).
- **Sensitivity**: C (highest — safety and legal implications).
- **Failure isolation**: must remain available even under broader platform degradation; minimal dependency chain.

## 17. Fraud & Risk
- **Responsibility**: signal collection, scoring, rules, blocking recommendations.
- **Owned entities**: Fraud Signal.
- **Inbound**: Payments, Promotions, Ratings, Location, Identity.
- **Outbound**: Administration, Payments (hold recommendations), Trip Management (block recommendations).
- **Sensitivity**: H.
- **Scaling**: primarily async/batch scoring; synchronous fast-path checks bounded and cached.

## 18. Support
- **Responsibility**: support case management, agent tooling.
- **Owned entities**: Support Case.
- **Inbound**: read access (scoped) to Trip, Payment, Driver, Rider data via internal APIs — never direct storage.
- **Outbound**: Notifications, Administration (escalation).
- **Sensitivity**: H (broad read access requires strict scoping and audit).

## 19. Administration
- **Responsibility**: platform configuration, RBAC management, privileged actions, audit review.
- **Owned entities**: Administrative Action, Audit Event (audit event storage may be shared infra owned by this domain).
- **Inbound**: all domains emit audit events here (async).
- **Outbound**: none (terminal sink) except configuration pushed back to Geographic Configuration, Pricing, etc.
- **Sensitivity**: C.

## 20. Geographic Configuration
- **Responsibility**: service areas, regional policy, localization parameters.
- **Owned entities**: Service Area.
- **Inbound**: Administration.
- **Outbound**: Dispatch, Pricing, Location, Trip Management (all read this as reference/config data).
- **Sensitivity**: L-M.

## 21. Analytics
- **Responsibility**: derived reporting/analytics datasets built from operational events, never authoritative for any operational decision.
- **Owned entities**: derived-only (no canonical entities listed in §05).
- **Inbound**: async consumption of all domain events.
- **Outbound**: dashboards/reporting only.
- **Sensitivity**: M (aggregate; must not re-expose raw PII beyond policy).
- **Scaling**: fully decoupled, batch/stream processing, never blocks operational transactions.

## Domain Ownership Summary Table

| Domain | Authoritative Store | Sensitivity | Deployable (see 04) |
|---|---|---|---|
| Identity & Accounts | PostgreSQL | H | Backend core |
| Driver Onboarding & Compliance | PostgreSQL + S3 | C | Backend core |
| Vehicle Management | PostgreSQL | M | Backend core |
| Rider Profile | PostgreSQL | M | Backend core |
| Driver Availability | Redis (+ periodic PG snapshot) | M | Dispatch/Location tier |
| Location | Redis + PostGIS | C | Location ingestion tier |
| Trip Management | PostgreSQL | H | Backend core |
| Dispatch | Redis + PostgreSQL (audit) | H | Dispatch tier |
| Pricing | PostgreSQL | H | Backend core |
| Promotions | PostgreSQL | M | Backend core |
| Payments | PostgreSQL | C | Backend core (isolated module) |
| Driver Earnings & Payouts | PostgreSQL | C | Backend core (isolated module) |
| Ratings & Reviews | PostgreSQL | M | Backend core |
| Notifications | PostgreSQL (prefs) + queue | M | Worker tier |
| Messaging | PostgreSQL | M-H | Backend core + Realtime |
| Safety | PostgreSQL | C | Backend core |
| Fraud & Risk | PostgreSQL | H | Backend core + Worker tier |
| Support | PostgreSQL | H | Admin/Ops tier |
| Administration | PostgreSQL | C | Admin/Ops tier |
| Geographic Configuration | PostgreSQL | L-M | Backend core |
| Analytics | OpenSearch/warehouse (derived) | M | Worker/analytics tier |
