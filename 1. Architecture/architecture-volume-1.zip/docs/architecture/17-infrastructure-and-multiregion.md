# 17 — Infrastructure and Multi-Region Architecture

## 1. Baseline Infrastructure Model (Target, Not Yet Provisioned)

AWS, single primary region initially, with the following logical layout: VPC with public subnets (load balancers, NAT) and private subnets (application workloads, databases); Kubernetes (EKS) hosting the API/Backend Application, Dispatch & Availability Service, Location Ingestion Service, Realtime Gateway, Background Worker Tier, Admin/Ops Application, and Search Indexing Service as separate deployments; managed PostgreSQL (RDS/Aurora with PostGIS extension), managed Redis (ElastiCache), managed Kafka/Redpanda (self-managed on EKS or a managed offering), managed OpenSearch, S3 for object storage, CloudFront (or equivalent) as CDN for static web assets. Terraform defines all of the above declaratively; GitHub Actions drives CI/CD. **None of this infrastructure has been provisioned by this architecture prompt** — this section is the target for later infrastructure implementation prompts.

## 2. Environments

Local development (docker-compose equivalents of PostgreSQL/PostGIS, Redis, Kafka/Redpanda for developer machines), Development, Test, Staging, Production, and a Disaster Recovery posture (cross-region backups/restore capability, not necessarily a hot standby region initially). Configuration is externalized per environment via environment variables/secret references, never hardcoded or baked into images.

## 3. Region-Aware Routing

The edge/API gateway is region-aware: clients are routed to the nearest healthy regional deployment once multi-region is active; until then, a single region serves all traffic and this concern is dormant but the routing layer is designed to add it without a client-facing contract change (region selection is transparent to clients via DNS/latency-based routing).

## 4. Geographic Configuration vs. Regional Service Availability

Geographic Configuration (§[03](./03-domain-decomposition.md) domain 20) is centrally stored (single source of truth for Service Area definitions, regional policy) even in a multi-region deployment; regional application instances read this centrally-owned configuration, they do not each own a divergent local copy, to avoid configuration drift across regions.

## 5. Data Residency Considerations

Where a jurisdiction requires in-region data residency for rider/driver PII, the architecture anticipates region-scoped database instances for that jurisdiction's users, with cross-region aggregation (for global reporting) happening only over de-identified/aggregated data — this is a documented future requirement, not resolved with a specific jurisdictional implementation in this volume (see [18](./18-privacy-and-security.md) §6).

## 6. Region-Local Realtime Traffic

Realtime Gateway and Location Ingestion instances are region-local (a driver's location/realtime session is served by the nearest region) to minimize latency; cross-region communication for these subsystems is avoided by design, not merely optimized.

## 7. Cross-Region Asynchronous Communication

Where cross-region consistency is genuinely required (e.g., a rider traveling and requesting trips in a different region than their home region's data resides), the pattern is asynchronous replication/lookup via a global Identity index, not synchronous cross-region calls in the hot path.

## 8. Regional Failure Isolation

A regional outage degrades service only within that region; the architecture explicitly avoids any single global synchronous dependency that would make one region's outage a global outage (e.g., no single-region-only Redis/Kafka that all regions synchronously depend on for trip-critical paths).

## 9. Centralized vs. Regional Configuration

Centralized: Geographic Configuration, Pricing Rule definitions (versioned, but authored centrally), RBAC/Administration. Regional: live operational state (Location, Driver Availability, active Dispatch, Realtime connections).

## 10. Explicit Non-Claims

No specific cloud resources, regions, account structures, or DR failover procedures have been provisioned or tested as part of this architecture prompt; this document defines the target shape for infrastructure implementation prompts to execute against.
