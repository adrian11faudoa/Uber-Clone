# 15 — Cross-Domain Integration Principles

## 1. Choosing an Integration Mechanism

| Mechanism | Use when | Do not use when |
|---|---|---|
| Synchronous API call | Caller needs the result to proceed within the current request, latency is bounded and low (e.g., dispatch claiming an assignment, pricing finalize-fare) | The caller doesn't need to wait for the effect to be visible immediately, or the callee's availability shouldn't gate the caller's success |
| Domain command (internal, synchronous, transactional) | A cross-module but co-deployed call that must participate in the same logical unit of work conceptually (e.g., Trip Management invoking Pricing's finalize-fare) | Crossing a true service-process boundary where a network call is already required — then it's just a synchronous API call with the same rules |
| Asynchronous event (Kafka/Redpanda) | Other domains need to react to something that happened, but the originating domain's success must not depend on those reactions (Notifications, Analytics, Search indexing, Earnings ledger creation from Payments) | The consumer's processing must complete before the producer's operation can be considered successful |
| Queue/job (BullMQ) | Discrete, retryable unit of work with clear ownership and completion semantics (payout batch run, document-expiry sweep, reconciliation) | The work is really a reaction to a domain event stream — model it as an event consumer instead, not a bespoke poll |
| Realtime message | Low-latency, best-effort delivery to a connected client of something already authoritative elsewhere (§[13](./13-realtime-architecture.md)) | The message itself is the only record of the fact — realtime is never the source of truth |

## 2. Ownership

Every piece of authoritative data has exactly one owning domain (§[03](./03-domain-decomposition.md)). Other domains obtain it via the owner's synchronous API (for point-in-time reads) or by consuming the owner's published events (to build a local, explicitly-derived, non-authoritative read model, e.g., Search indexes, Analytics aggregates).

## 3. Coupling Rules

- A domain may depend synchronously on another domain's API, but the dependency graph must remain acyclic within a single request path (no synchronous call cycles). Where two domains have mutual runtime needs, one direction is synchronous and the other is event-driven.
- No domain queries another domain's database schema directly, under any circumstance, including "just for a report" — reporting/analytics needs are served via events into Analytics (§[03](./03-domain-decomposition.md) domain 21) or a documented internal read API, never a cross-schema join.

## 4. Timeout Expectations

Every synchronous cross-domain call declares an explicit timeout appropriate to its position in a user-facing request path (e.g., Dispatch → Trip Management assignment claim: low tens of milliseconds budget; Pricing → maps provider: bounded, in the hundreds of milliseconds with a documented fallback). Timeouts are enforced by the caller, not left to the callee's default behavior.

## 5. Retry Expectations

Synchronous calls that are safely idempotent (per §[06](./06-identifier-time-data-contract.md) §3 and the calling domain's command design) may be retried a bounded number of times with exponential backoff and jitter; non-idempotent calls (e.g., a raw "capture payment" without an idempotency key — which should never exist per [12](./12-payment-financial-architecture.md) §3) are never blindly retried.

## 6. Idempotency

Every event consumer is required to be idempotent with respect to redelivery (at-least-once delivery is the assumed Kafka/Redpanda guarantee): consumers track processed event ids (or use natural upserts keyed by the event's target entity id) so replay/redelivery never double-applies an effect (e.g., crediting a driver's earnings ledger twice for one `payment.captured` event).

## 7. Eventual Consistency

Cross-domain effects delivered via events are eventually consistent by design; the architecture explicitly accepts a bounded propagation delay (e.g., a completed trip's earnings ledger entry appearing a few seconds after trip completion) as correct behavior, not a defect, provided it is observable and bounded (§[19](./19-failure-model.md) covers what happens when it is not bounded, i.e., broker outage).

## 8. Reconciliation

Where eventual consistency creates a risk of silent divergence (financial state, per [12](./12-payment-financial-architecture.md) §8), a scheduled reconciliation job is the explicit, required mechanism for detecting and surfacing (not silently auto-correcting) drift.

## 9. Failure Isolation

A synchronous dependency's failure must produce a bounded, well-defined caller outcome (fail the specific operation, do not cascade to unrelated concurrent operations) — see [19](./19-failure-model.md) for per-boundary behavior. An asynchronous dependency's failure (consumer down, broker unavailable) must never block the producing domain's own transaction; events are durably queued/buffered (transactional outbox pattern, §[08](./08-trip-lifecycle-contract.md) §4) for later delivery.

## 10. Event Contract Discipline

Every event has: `eventId`, `eventType` (e.g., `trip.completed`), `eventVersion`, `aggregateId`, `occurredAt` (UTC), `producer`, `correlationId`, trace context (propagated per §[06](./06-identifier-time-data-contract.md) §4), and `payload`. Event schemas evolve additively within a version (new optional fields, new enum values); breaking payload changes require a new `eventType` version suffix (e.g., `trip.completed.v2`) with both versions published during a documented migration window, mirroring the API versioning rule in [14](./14-api-architecture.md) §13.

## 11. Explicit Exception Documentation

Any case where a domain appears to write into another domain's conceptual data (e.g., Dispatch writing an `assignment_id` reference onto a Trip via Trip Management's own API, which is the correct pattern — the write still happens through the owner's API, not directly into its schema) is documented at the point of use as compliant with, not an exception to, this rule. A true schema-level exception has not been identified as necessary anywhere in this architecture; none is authorized without a dedicated ADR.
