# 18 — Security and Privacy Architecture

Consolidates the security and privacy requirements referenced throughout the volume.

## 1. Trust Zones (Summary)

Public internet → Edge/Gateway (TLS termination, WAF) → Internal VPC (mTLS between services) → Data stores (private subnets, no public endpoints). See [02](./02-system-context.md) §2 for the full trust-boundary description.

## 2. Privileged Operations

Any operation that mutates RBAC, financial configuration, pricing rules, safety-incident disposition, or account status of another user is privileged and requires: staff-category authentication with MFA (§[07](./07-authentication-authorization.md)), an explicit permission grant (not just role membership), and synchronous Audit Event emission.

## 3. Sensitive Data Classification

| Class | Examples | Handling |
|---|---|---|
| C (critical) | Precise location, payment credentials/tokens, identity documents, safety incident content | Strictest access scoping, audited access, minimal retention, never logged |
| H (high) | Trip records, financial ledger entries, driver compliance status, fraud signals | Scoped role access, audited for cross-user access, long retention where legally required |
| M (medium) | Profile data, ratings, notifications, promotions | Standard authenticated access, normal retention |
| L (low) | Vehicle categories, service area config | Broadly readable reference data |

## 4. Secret Boundaries

Secrets (provider API keys, signing keys, database credentials, webhook signing secrets) live exclusively in AWS Secrets Manager or Kubernetes secrets integrated with a secure secret-management workflow, injected into workloads at runtime — never committed to source control, never present in mobile app bundles or browser JS, never logged. Service identities (§[07](./07-authentication-authorization.md) §10) use short-lived credentials issued via the platform's identity/mTLS infrastructure rather than long-lived static secrets where feasible.

## 5. Authorization Enforcement

Restated from [07](./07-authentication-authorization.md) §8: backend authorization is authoritative everywhere; no client (including the Admin/Ops web application) bypasses backend checks.

## 6. Audit Requirements

Every privileged action, every cross-user data access by staff, every authentication event, and every financial state transition produces an immutable Audit Event (§[03](./03-domain-decomposition.md) domain 19), stored append-only, queryable by Administration/Compliance without being editable by any role.

## 7. Upload Security

Document/media uploads (driver compliance documents, support attachments) are validated for type/size at the API boundary, scanned for malware where the environment provides that capability, stored in S3 with private ACLs and access via short-lived signed URLs only — never public bucket access.

## 8. API Security

Input validation (§[14](./14-api-architecture.md) §4), parameterized queries only (no dynamic SQL construction from user input), output encoding appropriate to context (web XSS prevention), CSRF protection for any cookie-based session use on the web surface, SSRF protection on any server-side outbound fetch driven by user-supplied input (e.g., avoid building provider requests from unvalidated user URLs).

## 9. Realtime Security

Per [13](./13-realtime-architecture.md) §2–3: authenticated, per-subscription authorized, rate-limited.

## 10. Webhook Security

Per [12](./12-payment-financial-architecture.md) §9: signature-verified, deduplicated by provider event id.

## 11. Privacy — Data Minimization and Purpose Limitation

Each domain collects only the data it needs for its documented responsibility (§[03](./03-domain-decomposition.md)); cross-domain access is always through an explicit API/event, never ambient database access, which itself enforces purpose limitation structurally.

## 12. Retention and Deletion

Retention expectations per entity are documented in [05](./05-domain-entity-inventory.md); a platform-wide deletion workflow (triggered by account deletion requests or regulatory erasure requests) must be able to identify and purge/anonymize every domain's records referencing a given `user_id`, which is why every entity's foreign-key relationship to Identity is explicit and never buried in a derived-only store without traceability.

## 13. Location Privacy Specifics

Per [10](./10-location-architecture.md) §9: precise location shared only with the minimal necessary audience; any display of a data subject's location to a party who is not that subject and not actively engaged in the relevant trip is coarsened (reduced precision) or withheld entirely.

## 14. Logging Restrictions

Structured logs, metrics, and traces never contain: passwords, tokens, secrets, full payment credentials, precise location history beyond what's operationally necessary for the log's purpose, or free-text message/support-content bodies — content fields are redacted or referenced by id, with the actual content fetched only through an authorized API call when genuinely needed for debugging.

## 15. Regional Legal Requirements

This document does not resolve region-specific legal/regulatory requirements (e.g., specific data-protection regimes' exact obligations); it establishes the structural capability (data minimization, deletion workflows, residency-ready partitioning per [17](./17-infrastructure-and-multiregion.md) §5) that later, region-specific policy work will configure against. No compliance certification is claimed by this document.

## 16. No Custom Cryptography

All cryptographic operations (token signing, password hashing, TLS, provider webhook verification) use established, maintained libraries/protocols; no custom cryptographic algorithm is designed or implemented anywhere in this architecture.
