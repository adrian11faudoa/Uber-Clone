# 11 — Pricing Architecture

Owned by the Pricing domain (§[03](./03-domain-decomposition.md)). This document defines architectural behavior, not the pricing algorithm itself.

## 1. Conceptual Model

A **Fare Estimate** is a non-binding, time-boxed quote generated at request time from: base fare, estimated distance/time (from the maps/routing provider abstraction), minimum fare floor, service/booking fees, vehicle category multiplier, active Pricing Rule (including any dynamic/surge multiplier) for the relevant Service Area, and any applicable Promotion. A **Fare** is the binding, final calculation produced at trip completion from the same rule version referenced by the estimate plus actual trip distance/time, tolls (where applicable), taxes, and any post-trip adjustment within documented bounds.

## 2. Authoritative Inputs

Pricing is a pure function of explicitly versioned inputs: `(Pricing Rule version, Service Area, Vehicle Category, distance, duration, time-of-request, applicable Promotion, tax configuration version)`. No hidden global mutable state may influence a calculation; anything that affects price is one of these versioned inputs.

## 3. Calculation Ownership

Pricing is the only domain permitted to compute or persist a Fare Estimate or Fare. Trip Management requests a calculation via a synchronous API call at request time (estimate) and at completion time (finalize); it never re-derives or overrides pricing output.

## 4. Versioning

Every Pricing Rule change creates a new immutable version (§[05](./05-domain-entity-inventory.md)); Fare Estimates and Fares store the exact rule version used. Rule versions are activated with an explicit effective-from timestamp (UTC) so a rule change never retroactively alters an in-flight trip's already-generated estimate.

## 5. Reproducibility and Auditability

Given a stored Fare's referenced rule version and inputs, the exact amount must be independently recomputable for audit/dispute purposes — pricing logic must be deterministic (no unlogged randomness) and every input value used in a real calculation is persisted alongside the result, not just the final amount.

## 6. Rounding

All monetary rounding follows the round-half-up-to-minor-unit rule defined in [06](./06-identifier-time-data-contract.md) §7, applied once at final amount computation; intermediate multipliers (e.g., surge factor) may retain higher precision internally but the persisted, user-facing amount is always rounded once, consistently, at the boundary.

## 7. Monetary Representation

Integer minor units + explicit currency per [06](./06-identifier-time-data-contract.md) §7; no floating-point arithmetic anywhere in the pricing calculation path.

## 8. Quote Expiration

A Fare Estimate carries an explicit `expires_at` (short window, e.g., 2–5 minutes); Trip Management must re-request an estimate (or accept a policy-defined tolerance for slight staleness) if a Trip Request is created after expiration, rather than silently reusing a stale quote.

## 9. Post-Trip Adjustment Boundaries

Final Fare may differ from the Estimate only within variance attributable to actual vs. estimated route/time/tolls and any surge change applied at request-lock time per policy (e.g., surge is generally locked at request time, not re-evaluated at completion, unless explicitly configured otherwise for a region). Any adjustment beyond documented bounds requires a distinct, auditable "Fare Adjustment" action (support/finance-initiated), never a silent recalculation.

## 10. Dynamic/Surge Pricing

Surge multipliers are themselves a time-boxed, versioned Pricing Rule attribute per Service Area, computed by a process outside this document's scope (demand/supply signal ingestion is a later implementation concern) but architecturally required to: publish multiplier changes as new rule-version activations (never mutate an in-force rule), and be capped by documented min/max bounds enforced at the architecture level to prevent runaway pricing.

## 11. Promotions Interaction

Promotions (§[03](./03-domain-decomposition.md) domain 10) are applied as a discrete, itemized discount against the calculated fare, evaluated by Pricing at estimate/finalize time via a synchronous read of applicable, unexpired, eligible promotions for the rider — Promotions never mutates the Fare directly.

## 12. Failure Behavior

If the maps/routing provider (distance/time input) is unavailable, Pricing cannot generate a new estimate; Trip Management surfaces this as a clear "unable to estimate fare" outcome rather than fabricating a fare from stale or default values (see [19](./19-failure-model.md)).
