# 04 — Service and Module Boundary Model

See ADR-0001 for the modular-monolith decision. This document defines the logical/deployable architecture that later implementation prompts must target.

## 1. Deployable Units

| Deployable | Contains (domains/modules) | Why separated | Scaling driver | Failure boundary |
|---|---|---|---|---|
| **API/Backend Application** (NestJS modular monolith) | Identity & Accounts, Driver Onboarding & Compliance, Vehicle Management, Rider Profile, Trip Management, Pricing, Promotions, Payments, Driver Earnings & Payouts, Ratings & Reviews, Messaging (control-plane), Safety, Fraud & Risk (sync fast-path), Geographic Configuration | Shared transactional consistency needs (PostgreSQL), most are low-to-moderate throughput and benefit from in-process calls and shared connection pooling | Standard horizontal API scaling behind a load balancer | Stateless; instance failure is transparent behind LB |
| **Dispatch & Availability Service** | Dispatch, Driver Availability | Needs sub-second geo-matching loops distinct from general CRUD traffic; heavy Redis usage; different latency SLOs | Scales with active-trip-request volume and driver density per region | Isolated so dispatch storms don't starve account/payment APIs |
| **Location Ingestion Service** | Location (ingestion + fan-out) | Highest write volume in the system; must never be coupled to slower transactional paths | Scales with concurrent connected drivers/riders and update frequency | Isolated ingestion tier; backpressure here must not propagate to Trip Management |
| **Realtime Gateway** | WebSocket connection management, subscription routing, fan-out (delivers Location, Dispatch offers, Trip state, Notifications-realtime) | Long-lived stateful connections need different scaling/operational model than stateless HTTP | Scales with concurrent connections | Isolated; gateway restarts must not lose authoritative state (clients resync via API) |
| **Background Worker Tier** | Notifications, Analytics ingestion, Fraud & Risk async scoring, Payout batch processing, reconciliation jobs | Asynchronous, retryable, decoupled from request/response latency | Scales with queue/event backlog | Isolated; worker failure triggers retry/backoff, not user-visible failure |
| **Admin/Ops Application** | Support, Administration (UI + scoped internal APIs) | Distinct authorization model and audience from consumer apps | Low, predictable internal load | Isolated so a compromised/overloaded admin surface cannot affect consumer-facing SLOs |
| **Search Indexing Service** | OpenSearch index builders (consume events, derived only) | Decoupled indexing pipeline | Scales with event volume | Isolated; search outage never blocks operational writes |

Payments and Driver Earnings & Payouts are modules within the API/Backend Application but are **isolated NestJS modules with their own database schema/connection boundary** and no cross-module direct entity access — this preserves extraction-readiness (ADR-0002) without paying microservice operational cost today.

## 2. Edge / API Gateway Responsibilities

- TLS termination, WAF, DDoS mitigation.
- Coarse-grained rate limiting (per IP, per account).
- Authentication token validation (JWT signature/expiry check) before routing.
- Routing to API/Backend Application or Realtime Gateway.
- Request/response size limits, basic schema validation at the edge (defense in depth; authoritative validation remains server-side).

## 3. Realtime Gateway Responsibilities

See [13](./13-realtime-architecture.md) for the full contract. Summary: authenticated WS upgrade, per-connection subscription state (trip room, driver-availability channel), fan-out from internal pub/sub (Redis or Kafka-backed), heartbeat/reconnect handling, backpressure and per-connection rate limiting.

## 4. Dispatch Processing Boundary

Owns the offer state machine and candidate search. Reads Driver Availability + Location (via internal API/shared Redis keyspace with clear ownership — Dispatch reads, Location/Availability write), reads Vehicle Management and Pricing via synchronous internal API calls bounded by a strict timeout (see [09](./09-dispatch-matching.md)). Writes assignment results to Trip Management via a synchronous, idempotent command.

## 5. Location Ingestion Boundary

Accepts high-frequency location updates from mobile clients (via edge or a dedicated ingestion endpoint), writes ephemeral state to Redis (geo-indexed), publishes fan-out events to the Realtime Gateway, and asynchronously persists trip-associated route samples to PostGIS for history/audit. Never sits in the synchronous path of Trip Management writes.

## 6. Pricing Boundary

Exposes a synchronous, low-latency "estimate fare" read API and a synchronous "finalize fare" call invoked by Trip Management at trip completion. Both are pure functions of versioned inputs (see [11](./11-pricing-architecture.md)) — no side effects beyond persisting the Fare/Fare Estimate record.

## 7. Payment Boundary

Exposes synchronous APIs for authorization/capture invoked by Trip Management/Payments module, and an isolated webhook ingress for the payment provider. All provider calls are wrapped in an internal abstraction (`PaymentProviderPort`) so provider swap does not ripple through domain logic.

## 8. Notification Boundary

Purely asynchronous: consumes domain events from Kafka/Redpanda, applies user preference/localization, and dispatches via provider abstractions. No domain ever calls Notifications synchronously.

## 9. Background-Worker Boundary

BullMQ-backed queues per concern (payouts, reconciliation, document-expiry sweeps, fraud batch scoring). Each queue has an explicit owner domain and documented retry/backoff/dead-letter policy (see [15](./15-cross-domain-integration.md)).

## 10. Search Boundary

Consumes domain events, builds read-only indexes for operational/support search (users, trips, drivers, support cases). Never authoritative; rebuildable from source-of-truth event log/database at any time.

## 11. Administration Boundary

Scoped internal APIs, never direct database access from the Admin/Ops Application to another domain's schema. All privileged actions produce an Audit Event synchronously as part of the same transaction where feasible, or via a guaranteed-delivery outbox otherwise.

## 12. Component Diagram

```mermaid
flowchart TB
    subgraph Clients
        RiderApp["Rider App (RN/Expo)"]
        DriverApp["Driver App (RN/Expo)"]
        WebApp["Rider/Admin Web (Next.js)"]
    end

    Edge["API Gateway / Edge"]
    RT["Realtime Gateway"]

    subgraph Backend["API/Backend Application (NestJS modular monolith)"]
        Identity
        Onboarding["Driver Onboarding"]
        Vehicles
        RiderProfile["Rider Profile"]
        TripMgmt["Trip Management"]
        Pricing
        Promotions
        Payments["Payments (isolated module)"]
        Earnings["Earnings & Payouts (isolated module)"]
        Ratings
        Messaging
        Safety
        FraudSync["Fraud & Risk (sync fast-path)"]
        GeoConfig["Geographic Configuration"]
    end

    Dispatch["Dispatch & Availability Service"]
    Location["Location Ingestion Service"]
    Workers["Background Worker Tier"]
    AdminApp["Admin/Ops Application"]
    SearchIdx["Search Indexing Service"]

    DB[(PostgreSQL/PostGIS)]
    Redis[(Redis)]
    Bus[(Kafka/Redpanda)]
    S3[(Object Storage)]
    OS[(OpenSearch)]

    RiderApp & DriverApp & WebApp --> Edge
    RiderApp & DriverApp --> RT

    Edge --> Backend
    Edge --> AdminApp
    RT <--> Dispatch
    RT <--> Location
    RT <--> Backend

    Backend --> DB
    Backend --> Redis
    Backend --> Bus
    Backend --> S3
    Dispatch --> Redis
    Dispatch --> DB
    Location --> Redis
    Location --> DB
    Bus --> Workers
    Workers --> DB
    Bus --> SearchIdx
    SearchIdx --> OS
    AdminApp --> Backend
```
