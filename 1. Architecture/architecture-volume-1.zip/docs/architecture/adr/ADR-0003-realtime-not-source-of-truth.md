# ADR-0003: Realtime Channels Are Never the Source of Truth

## Status
Accepted

## Context
WebSocket delivery is inherently best-effort for high-frequency channels (location) and cannot be assumed reliable across reconnects, backgrounding, or gateway instance failure.

## Decision
Every fact delivered over a realtime channel (§13) has a corresponding authoritative synchronous read API; clients are architecturally required to resync from that API after any reconnect/resume/detected gap, and are never permitted to treat "last realtime message received" as authoritative state.

## Alternatives Considered
- **Guaranteed-delivery realtime for everything (e.g., full Kafka-backed replay for location)**: rejected — location's volume and "only the latest value matters" semantics make guaranteed replay both wasteful and unnecessary; the correctness need is served by a synchronous fallback, not a delivery guarantee.

## Consequences
Slightly more client-side complexity (must implement resync logic), but eliminates an entire class of "client state silently diverged from server" bugs, especially critical for trip lifecycle and dispatch offers.
