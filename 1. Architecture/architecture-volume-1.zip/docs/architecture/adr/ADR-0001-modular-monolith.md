# ADR-0001: Modular Monolith Before Microservices

## Status
Accepted

## Context
The platform's ultimate scale targets (100M+ riders, 10M+ drivers) could tempt an immediate microservices-per-domain decomposition. The Master Prompt explicitly requires a deliberate decision, not a default.

## Decision
Start with a NestJS modular monolith (the "API/Backend Application," §04) hosting most domains as independently-boundaried modules with strict inter-module contracts (no cross-module entity access), while extracting only the subsystems with genuinely distinct scaling/latency/failure-isolation profiles from day one: Dispatch & Availability, Location Ingestion, and the Realtime Gateway, plus a separate Background Worker tier and Admin/Ops Application.

## Alternatives Considered
- **Full microservices per domain (21 services)**: rejected — imposes network-call latency, distributed-transaction complexity, and operational overhead on domains (e.g., Rider Profile, Vehicle Management) with no current scaling or team-ownership reason to be separate.
- **Single undifferentiated monolith (including Dispatch/Location/Realtime)**: rejected — these three have measurably different scaling and latency profiles (high-frequency writes, sub-second matching loops, long-lived stateful connections) that would force the whole monolith to scale/deploy around their needs.

## Consequences
- Lower initial operational complexity and cost.
- Domain modules are designed with explicit contracts (§03, §15) so extraction later (e.g., splitting Payments into its own service) is a mechanical, low-risk operation, not a rewrite.
- Requires discipline: module boundaries must be enforced (e.g., via lint rules/module dependency graphs in the backend implementation phase) to avoid the "distributed monolith becomes a big ball of mud" failure mode.

## Operational Implications
Backend implementation prompts must enforce module isolation (separate NestJS modules, no direct cross-module repository/entity imports) so the seams defined here remain real seams, not just documentation.
