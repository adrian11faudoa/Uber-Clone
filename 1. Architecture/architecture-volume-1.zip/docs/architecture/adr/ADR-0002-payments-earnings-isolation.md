# ADR-0002: Payments and Earnings as Isolated Modules Within the Monolith

## Status
Accepted

## Context
Financial correctness (§12) is the platform's highest-consequence failure domain. Even though Payments and Driver Earnings & Payouts are co-deployed with other domains in the API/Backend Application (ADR-0001), they carry materially higher security/audit/extraction-readiness requirements than, e.g., Rider Profile.

## Decision
Payments and Driver Earnings & Payouts are implemented as isolated NestJS modules with their own database schema boundary and no direct entity access from other modules — all interaction is via their own internal API/command surface and asynchronous events (§15), identical to how a genuinely separate service would be integrated.

## Alternatives Considered
- **Fully separate microservice from day one**: rejected for the same reasons as ADR-0001 generally — no current throughput/team reason forces it, and the isolation achieved by a strict in-process module boundary provides the same correctness/extraction benefits without the operational cost.
- **No special isolation (treat like any other module)**: rejected — the consequence of an accidental cross-module financial data leak or inconsistent write is high enough to justify the extra discipline now.

## Consequences
Extraction to a standalone Payments service, if ever needed for PCI-scope isolation or independent scaling, requires no schema/contract redesign — only a deployment change.
