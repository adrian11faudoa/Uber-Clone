# ADR-0005: UUIDv7 as the Universal Entity Identifier

## Status
Accepted

## Context
Entity identifiers must be safely generatable across distributed backend instances and, in some cases, clients (idempotency keys, draft ids), without central coordination, while remaining index-friendly at high write volume (Trip, Location Sample, Payment).

## Decision
Use UUIDv7 (time-ordered) for all primary entity identifiers, per §06 §1.

## Alternatives Considered
- **Auto-increment integers**: rejected — requires central sequence coordination, leaks approximate row counts/business volume, and complicates client-side/edge id generation for idempotency keys.
- **UUIDv4 (random)**: rejected in favor of UUIDv7 specifically for index locality on the highest-write-volume tables (Location Sample, Trip) — random UUIDs cause significant B-tree index fragmentation at this project's target write volumes.

## Consequences
Requires PostgreSQL/driver support for UUIDv7 generation (library-level, not a PostgreSQL built-in as of typical current versions) — an implementation-phase detail, not an architectural blocker.
