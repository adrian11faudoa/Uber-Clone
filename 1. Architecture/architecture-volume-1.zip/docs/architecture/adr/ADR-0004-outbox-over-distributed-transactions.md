# ADR-0004: Transactional Outbox + Idempotent Consumers Over Distributed Transactions

## Status
Accepted

## Context
Cross-domain consistency (e.g., trip completion triggering payment capture, earnings ledger creation, and notifications) could be pursued via two-phase-commit-style distributed transactions or via an eventual-consistency event-driven pattern.

## Decision
Use the transactional outbox pattern (write the state change and the to-be-published event in the same local database transaction, then relay to Kafka/Redpanda asynchronously) paired with idempotent event consumers everywhere cross-domain propagation is needed (§08 §4, §15 §6).

## Alternatives Considered
- **Distributed (two-phase-commit) transactions across domain databases**: rejected per the Master Prompt's explicit guidance and general distributed-systems practice — operationally fragile, poor availability characteristics, and unnecessary given the domains' actual consistency requirements tolerate bounded eventual consistency.
- **Saga/workflow orchestration engine**: not required for any currently-identified cross-domain workflow in this volume (all identified needs are satisfied by simple outbox + idempotent consumer); remains available as a future option per §21 Part D.2 if a more complex multi-step compensating workflow is identified later.

## Consequences
Slight, bounded propagation delay for downstream effects (acceptable per §15 §7); requires every consumer to be built idempotently from the start, which is mandated project-wide regardless (§15 §6), so this is not incremental cost specific to this decision.
