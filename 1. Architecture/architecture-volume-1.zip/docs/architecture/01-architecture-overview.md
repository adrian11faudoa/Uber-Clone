# 01 — Architecture Overview

Status: Foundational (Volume 1). Target architecture, not a description of an existing implementation. No application code exists yet; this package is the contract that later, independently executed implementation prompts (backend, web, mobile, infrastructure, QA) must conform to.

## 1. Project Identity

An original, global-scale ride-hailing and mobility platform (category-comparable to Uber/Lyft/Grab/Bolt) supporting rider and driver-partner mobile apps, a web presence, real-time dispatch and location, dynamic pricing, payments and driver payouts, safety, support, fraud/risk, and administration. Implementation must be original; no proprietary third-party code, credentials, or private APIs.

## 2. Product Scope (Target, Phased)

The full target product surface is enumerated in the Master Prompt. This volume does not implement any of it; it defines the boundaries and contracts so that later prompts (each independently executable, each without access to this conversation) build a coherent system.

## 3. Target Scale

Architectural headroom for ~100M+ riders, ~10M+ drivers, millions of trips/day, high-frequency location updates, hundreds of thousands of concurrent realtime connections, multi-region operation. These are targets that inform boundary placement (e.g., separating high-frequency location traffic from transactional paths) — they do not require every milestone to provision production-scale infrastructure immediately (see [16-scalability](./16-scalability-architecture.md)).

## 4. Architecture Goals

1. Explicit domain and data ownership everywhere.
2. Backend-authoritative security, financial, and lifecycle state — clients are never trusted.
3. Distributed-systems correctness by default: idempotency, retries, duplicate-tolerance, eventual consistency where appropriate.
4. A modular monolith first, with explicit seams that allow extraction into independently scalable services only where a concrete scaling or ownership reason exists (see ADR-0001).
5. Realtime state is always a convenience channel, never the sole source of truth.
6. Every cross-domain contract (API, event, queue) is versioned, documented, and portable — implementable by an agent with no memory of this conversation.
7. Security and privacy boundaries are explicit at every domain edge.
8. Observability is a first-class architectural concern, not an afterthought.

## 5. Major Technology Choices (Locked Direction)

| Layer | Technology | Notes |
|---|---|---|
| Web | Next.js, React, TypeScript, Tailwind, shadcn/ui, TanStack Query, React Hook Form, Zod | Rider web, account mgmt, admin/ops tooling |
| Mobile | React Native, Expo, TypeScript | Separate rider and driver experiences, shared packages |
| Backend | Node.js, TypeScript, NestJS | Modular monolith with domain modules (see ADR-0001) |
| Primary DB | PostgreSQL (+ PostGIS) | Authoritative transactional + spatial store |
| Cache/Ephemeral | Redis | Cache, rate limiting, presence, ephemeral location, idempotency keys |
| Eventing | Kafka or Redpanda | Durable, versioned domain events |
| Jobs | BullMQ | Redis-backed background work |
| Search | OpenSearch/Elasticsearch-compatible | Derived, not authoritative |
| Object storage | S3-compatible | Documents, receipts, attachments |
| Payments | Provider abstraction, Stripe-compatible initial impl | See [12](./12-payment-financial-architecture.md) |
| Maps/Routing | Provider abstraction, Google Maps Platform/Mapbox-compatible | See [10](./10-location-architecture.md) |
| Realtime | WebSockets | See [13](./13-realtime-architecture.md) |
| Infra | AWS, Docker, Kubernetes/EKS, Terraform, GitHub Actions | See [17](./17-infrastructure-and-multiregion.md) |
| Observability | OpenTelemetry, Prometheus, Grafana, Loki, Tempo | See [observability sections in 04, 13, 14] |

Technology substitutions require a documented ADR with concrete technical justification; casual replacement is disallowed.

## 6. System Decomposition (Summary)

The platform decomposes into 21 logical domains (§[03](./03-domain-decomposition.md)) hosted, at this stage, inside a small number of deployable units (§[04](./04-service-module-boundaries.md)): an API/backend application (modular monolith of NestJS domain modules), a realtime gateway, a dispatch/location processing tier, and a background-worker tier — all sharing the same domain module code where practical, differentiated primarily by scaling and failure-isolation needs rather than aesthetic microservice boundaries.

## 7. Key Quality Attributes (Ranked)

1. Correctness of financial and trip-lifecycle state (never client-authoritative).
2. Reliability under partial failure (retries, idempotency, degradation).
3. Security and privacy (backend-enforced authorization, data minimization).
4. Scalability of location/dispatch/realtime hot paths.
5. Observability (every domain boundary emits logs/metrics/traces).
6. Maintainability (explicit contracts over implicit convention).
7. Cost/operational realism (no gratuitous decomposition or always-on waste).

## 8. Primary Tradeoffs

- **Modular monolith vs. microservices**: chosen modular monolith for initial phases to avoid premature distributed-systems tax; explicit extraction seams are defined per domain (ADR-0001).
- **Strong consistency vs. availability**: trip lifecycle, payments, and driver assignment favor strong consistency (PostgreSQL transactions); location and presence favor availability/freshness over strict consistency (Redis).
- **Synchronous vs. asynchronous cross-domain calls**: synchronous only for bounded, latency-sensitive reads/writes within a request path; everything else (notifications, analytics, ledger propagation) is event-driven (§[15](./15-cross-domain-integration.md)).

## 9. Architectural Constraints

- No client (mobile/web) may be authoritative for trip lifecycle, pricing, or payment state.
- No domain may write directly into another domain's authoritative storage.
- No microservice may be created without a documented scaling or failure-isolation justification.
- No raw payment credentials are stored on platform infrastructure.
- No indefinite retention of high-frequency location data.

## 10. Major Dependencies

External: a maps/routing provider, a payment provider, push/SMS/email providers, cloud infrastructure (AWS), and a per-domain-review-list of regional legal/compliance requirements not resolved by this volume (see [18-privacy-and-security](./18-privacy-and-security.md)).

## 11. What This Volume Does Not Do

Does not implement backend, frontend, or mobile code; does not provision infrastructure; does not fabricate credentials or provider integrations; does not select the next implementation phase. See the completion report for the full list of artifacts produced and open items.
