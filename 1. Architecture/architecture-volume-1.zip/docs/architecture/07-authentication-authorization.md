# 07 — Authentication and Authorization Architecture

## 1. Account Categories

| Category | Examples | Auth surface |
|---|---|---|
| Consumer | Rider, Driver | Mobile-first auth (phone/email + password or OTP), social login optional |
| Internal staff | Support, Operations, Safety, Finance, Administrator | Web SSO-capable auth, mandatory MFA |
| Service identity | Backend services, workers, gateways | mTLS or signed service tokens, no human credential |

## 2. Authentication Flows

- **Consumer**: phone number or email + password, or OTP-based passwordless login; optional social login providers behind the same identity abstraction. On success, issue a short-lived access token (JWT, ~15 min) + a longer-lived refresh token (rotating, ~30 days, revocable).
- **Internal staff**: same access/refresh token model, but issuance requires MFA and is scoped to a much shorter refresh lifetime (e.g., 8–12 hours) with mandatory re-authentication for privileged actions.
- **Service-to-service**: mutual TLS within the cluster plus short-lived signed service tokens (JWT with service identity claims) for authorization decisions; no shared static API keys between internal services.

## 3. Session Model

- Access tokens are stateless JWTs, signed (asymmetric, e.g., ES256), containing subject (`user_id`), account category, role claims, and token version.
- Refresh tokens are opaque, stored hashed server-side (PostgreSQL/Redis), one row per device/session, enabling per-device revocation ("log out this device") without invalidating all sessions.
- A `token_version` claim per user allows global forced-logout (e.g., after password change or suspected compromise) by bumping the version and rejecting older access tokens at the gateway.

## 4. Access Token Behavior

- Validated at the edge (signature + expiry) for coarse routing, and re-validated with full claim/role checks inside the backend domain module handling the request — the edge check is a performance/DoS optimization, not the authorization boundary.
- Access tokens carry minimal claims; permission checks against current, possibly-changed account state (e.g., suspension) are done against the authoritative Identity store, not solely trusted from token claims, for security-sensitive operations (payments, trip actions).

## 5. Refresh Behavior

- Refresh is a one-time-use rotating token: each refresh call issues a new refresh token and invalidates the old one; reuse of an already-rotated refresh token is treated as a compromise signal and revokes the entire session family.

## 6. Device / Session Management

- Users can list and revoke active sessions/devices (staff and consumer).
- Driver and Rider apps register a device identifier at login for push-notification targeting, stored as part of the session record.

## 7. Role Model

| Role | Scope | Notes |
|---|---|---|
| `rider` | Own account and trips only | Default consumer role |
| `driver` | Own account, assigned trips, own earnings | Default consumer role |
| `support_agent` | Scoped read + limited write (case-linked) across Rider/Driver/Trip/Payment domains | No direct financial mutation beyond documented support actions |
| `ops_agent` | Service area, dispatch policy, incident visibility | No financial or identity-document access beyond what ops requires |
| `safety_agent` | Safety Incident domain, trip/location read access scoped to active investigations | Highest confidentiality; access itself is audited and rate-limited |
| `finance_agent` | Payments, Earnings & Payouts read/write within finance workflows | No trip-dispatch or safety access |
| `administrator` | Full configuration, RBAC management, cross-domain override | Requires MFA + step-up auth for destructive/privileged actions; every action audited |
| `service` | Domain-to-domain internal calls | Scoped per declared service identity, least privilege per callee |

Permissions are expressed as domain-scoped capability grants (e.g., `trip:read:own`, `trip:read:any`, `payment:refund:execute`), not just role names, so that RBAC can be composed and audited precisely (see ADR-0006 direction, if later formalized).

## 8. Authorization Enforcement Principle

**Backend authorization is authoritative.** Clients (mobile, web, admin UI) may hide or disable UI affordances for UX purposes only; every domain module independently re-checks that the authenticated principal is permitted to perform the requested action against the requested resource, on every request. No domain trusts another domain's prior authorization check as sufficient without its own scoped verification for high-sensitivity operations (payments, safety, admin actions).

## 9. Support / Safety / Finance / Admin Authorization Specifics

- All internal-staff access to individual rider/driver PII (support, safety) requires a documented business justification captured at access time (e.g., linked support case ID or incident ID) and is itself an audited event.
- Safety and Finance roles are mutually exclusive by default (separation of duties) unless an explicit administrator override is granted and logged.
- Administrative actions that change RBAC, financial configuration, or pricing rules require a second-actor or approval-workflow pattern where the business risk warrants it (documented per action type; not universally mandated at this architecture stage).

## 10. Service-to-Service Identity

- Each deployable unit (§[04](./04-service-module-boundaries.md)) has a distinct service identity used for mTLS and for internal JWT issuance; internal calls are authorized against a least-privilege matrix (e.g., Dispatch may call Trip Management's "assign driver" command, but not Payments' "capture charge").

## 11. Audit Requirements

Every authentication event (login, logout, token refresh, revocation), every privileged authorization decision (staff access to sensitive data), and every administrative action produces an immutable Audit Event (owned by Administration, §[03](./03-domain-decomposition.md)) containing actor, action, target, timestamp, and correlation ID — never the credential/token value itself.

## 12. Explicit Non-Goals of This Document

No credentials, secrets, signing keys, or provider-specific SSO configuration are defined or fabricated here; those are environment/deployment-time concerns handled via the secrets boundary in [18](./18-privacy-and-security.md).
