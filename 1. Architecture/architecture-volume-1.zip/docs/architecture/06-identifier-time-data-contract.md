# 06 — Identifier, Time, and Data Representation Contract

Binding for every domain, API, event, and queue payload in the project.

## 1. Entity Identifiers

- All primary entity identifiers are **UUIDv7** (time-ordered UUIDs) stored as PostgreSQL `uuid`. UUIDv7 is chosen over UUIDv4 for index locality on high-write tables (Location, Trip, Payment) and over auto-increment integers to avoid cross-domain sequence coupling and to allow safe client-side/edge generation where required (e.g., idempotency keys, offline-created draft IDs).
- Format in APIs/events: lowercase, hyphenated string, e.g. `018f0a1e-...`.
- Field naming: `<entity>_id` (e.g., `trip_id`, `driver_id`). Foreign keys use the referenced entity's id name.

## 2. Public vs. Internal Identifiers

- Internal identifiers (UUIDs above) are used in all backend-to-backend and backend-to-client contracts.
- Where a short, human-shareable reference is needed (e.g., a trip receipt number, a support case number), define a separate **Public Reference Code**: a short, non-guessable, checksummed string (e.g., `TRP-7F3K9Q`) generated at creation and stored alongside the UUID. Public reference codes are never used as foreign keys internally.

## 3. Idempotency Keys

- Every state-mutating client-initiated API call that is not naturally idempotent (trip request creation, payment capture, driver offer acceptance) must accept a client-supplied `Idempotency-Key` header (UUID, client-generated).
- Servers persist `(idempotency_key, endpoint, request_hash) → response` for a bounded window (minimum 24h) in Redis or a dedicated table, and replay the original response on duplicate submission rather than re-executing side effects.

## 4. Correlation and Trace IDs

- Every inbound request is assigned a `correlation_id` (UUID) at the edge if not already present, propagated through all internal calls, events, and logs.
- Distributed tracing uses OpenTelemetry `trace_id`/`span_id`, propagated via W3C Trace Context headers across HTTP and injected into Kafka event headers.
- `correlation_id` is returned to clients in error responses (see [14](./14-api-architecture.md)) to support support-case lookups without exposing internal trace infrastructure.

## 5. Timestamps

- All timestamps are stored and transmitted in **UTC**, ISO-8601 with millisecond precision and explicit `Z` suffix (e.g., `2026-09-17T14:03:21.482Z`).
- Local/display time is a client-side presentation concern only; the backend never stores or reasons about local time except when a business rule is explicitly regional (e.g., "night surge 22:00–05:00 local"), in which case the domain configuration explicitly stores the IANA timezone (e.g., `America/Chihuahua`) alongside the rule and computes local time at evaluation time — never stores a naive local timestamp.
- Every mutable entity carries `created_at` (immutable) and `updated_at` (bumped on every mutation) at minimum; append-only/immutable entities carry `occurred_at` or `recorded_at` as their single authoritative timestamp.

## 6. Date-Only Values

- Date-only business values (e.g., a document expiration date) use `YYYY-MM-DD` with an explicit associated timezone/region context documented at the field level by the owning domain — never bare dates with implied timezone.

## 7. Monetary Values

- All authoritative monetary amounts are stored as **integer minor units** (e.g., cents) in PostgreSQL `bigint`, never floating point.
- Every monetary field is paired with an explicit ISO-4217 currency code field; there is no implicit "platform default currency."
- API/event payloads represent money as `{ "amount_minor_units": 1250, "currency": "USD" }`. Display formatting is a client concern.
- Arithmetic on money (splits, taxes, surge multipliers) is performed with fixed-point/decimal-safe libraries server-side and rounded using a documented, consistent rounding rule (round-half-up to the currency's minor unit) applied at the point of finalization only — intermediate calculations retain higher precision where the Pricing domain's versioned rule requires it.

## 8. Geographic Coordinates

- Latitude/longitude stored as `double precision` (PostGIS `geography(Point, 4326)`), WGS84.
- API/event representation: `{ "lat": 28.632, "lng": -106.069 }`, decimal degrees, minimum 5 decimal places of precision (~1.1m), never truncated to fewer than 5 without explicit privacy-driven rounding (see [10](./10-location-architecture.md), [18](./18-privacy-and-security.md) for coarsening rules on rider-facing driver-location display).

## 9. Distance and Duration

- Distance: meters (integer or float, domain's choice, but always meters — never mixed units in one payload).
- Duration: seconds (integer). Display formatting (minutes, hours) is a client concern.
- ETA is always represented as an absolute UTC timestamp (`eta_at`), not a relative "in N minutes" string, to avoid clock-skew ambiguity between services and clients.

## 10. Enums / Status Values

- All enum values are `UPPER_SNAKE_CASE` strings in APIs/events/DB (not raw integers), to keep contracts self-describing and safely extensible.
- Enums are additive-only in a given major API/event version: new values may be added; existing values are never renamed or removed within a version (see [15](./15-cross-domain-integration.md) for evolution rules). Consumers must treat unrecognized enum values as "unknown/ignore-safely," not as an error, wherever forward-compatibility is required.

## 11. Nullable Values

- A field is nullable only when "absent" is a meaningful, documented business state (e.g., `driver_id` on a `Trip Request` before assignment). Optional-but-usually-present fields use an explicit default rather than null.
- APIs omit null optional fields from responses rather than emitting `null` where practical, except where the client contract explicitly needs to distinguish "not yet set" from "field omitted for other reasons."

## 12. Serialization

- All API and event payloads are JSON, UTF-8, `camelCase` at the wire level for APIs (JS/TS client ecosystems), while internal database columns use `snake_case`; the API layer is responsible for the mapping. Event payloads (Kafka) also use `camelCase` JSON for consistency with API consumers that may replay events.
- Every event envelope and API error envelope is defined once, centrally (see [14](./14-api-architecture.md), [15](./15-cross-domain-integration.md)) and reused verbatim by every domain — no per-domain bespoke envelope shapes.
