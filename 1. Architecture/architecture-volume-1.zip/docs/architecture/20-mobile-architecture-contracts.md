# 20 — Mobile Architecture Contracts

Applies to both Rider and Driver React Native/Expo applications.

## 1. Authentication

Access/refresh tokens (§[07](./07-authentication-authorization.md)) stored in platform secure storage (iOS Keychain / Android Keystore via Expo SecureStore or equivalent) — never in plain AsyncStorage. Silent refresh on app foreground/token-near-expiry; forced re-login on refresh-token invalidation (revocation, reuse-detected compromise per §[07](./07-authentication-authorization.md) §5).

## 2. Secure Credential Storage

Only tokens and minimal session metadata are stored on-device; no payment credentials are ever stored on-device (payment collection is provider-SDK-hosted per §[12](./12-payment-financial-architecture.md) §12).

## 3. Realtime

Apps maintain a single WebSocket connection (§[13](./13-realtime-architecture.md)), re-established on foreground/network-recovery, always followed by a synchronous resync call (§[13](./13-realtime-architecture.md) §7) before trusting subsequent realtime messages.

## 4. Location

Driver app: adaptive-frequency background location per §[10](./10-location-architecture.md) §11, requested with minimal-scope permission justification, active only while online/dispatch-eligible or on an active trip. Rider app: foreground location for pickup selection; background location only during an active trip if "share my trip" is enabled, explicitly consented.

## 5. Background Execution

Platform-specific background task APIs (iOS background modes for location; Android foreground service for continuous driver-online location) are required for the driver app's core online-availability feature to function correctly per platform constraints — this is a hard platform requirement, not an optimization.

## 6. Push Notifications

Device push tokens registered at login (§[07](./07-authentication-authorization.md) §6) associated with the session record; delivered via the Notifications domain's provider abstraction (FCM/APNs-compatible).

## 7. Permissions

Location, notifications, camera (document upload, driver onboarding), and microphone (if in-app voice features are ever added) are requested contextually (at the point of feature use), not all at first launch, and the app must function in a degraded but non-broken way if a non-essential permission is denied.

## 8. Deep Links

Used for: trip-status notifications opening directly to the relevant trip screen, driver-onboarding-status notifications opening to the relevant onboarding step, promotional links. Deep link handlers validate the referenced entity id against the authenticated user's authorization before navigating (never trust a deep-linked id blindly, consistent with §[07](./07-authentication-authorization.md) §8).

## 9. Offline Behavior

Per [19](./19-failure-model.md) "Mobile offline state": non-critical reads (cached profile, past trip history) may be served from local cache with a clear staleness indicator; trip-lifecycle-changing actions (accept offer, start/end trip, cancel) require live connectivity and are never silently queued for later delivery, since queuing a stale accept/cancel could contradict the authoritative state that has since moved on.

## 10. Synchronization

On app foreground/resume, the app always re-fetches authoritative state for anything currently displayed that could have changed while backgrounded (active trip, offer status) rather than trusting whatever was last rendered.

## 11. Client-Generated Request Identifiers

Idempotency keys (§[06](./06-identifier-time-data-contract.md) §3) for trip-request creation and other non-idempotent actions are generated client-side (UUID) at the moment the user initiates the action, and reused verbatim across retry attempts of that same logical action (e.g., due to a spinner-timeout-triggered client retry).

## 12. Reconnect Behavior

Restated from [13](./13-realtime-architecture.md) §7: reconnect always triggers subscription re-establishment plus an authoritative resync call before the UI trusts new realtime data.

## 13. State Authority Classification

| State | Classification |
|---|---|
| Trip lifecycle state, fare, payment status | Server-authoritative always; local copy is a cache, never edited optimistically for these |
| "Accept offer" / "Start trip" / "End trip" button press | Optimistic UI (immediate visual feedback) but the actual state transition is confirmed only on server response; a rejected transition (§[08](./08-trip-lifecycle-contract.md) §8) reverts the optimistic UI with an explicit message |
| Driver's own current location marker | Locally authoritative for immediate self-display; server-reported for anything shown to another party |
| Draft/unsent trip request form fields | Locally authoritative until submission |
| Notification read/unread status | Locally optimistic, synced to server, eventually consistent |

## 14. API Versioning

Mobile clients pin to a specific API major version (§[14](./14-api-architecture.md) §13) per app release; the backend supports the currently-shipped and immediately-prior major version simultaneously to accommodate the mobile app-store update rollout lag, per the deprecation policy in [14](./14-api-architecture.md) §14.
